StaffKit HR — Staff Letters & Onboarding Templates for Indian Small Businesses
=============================================================================

WHAT THIS IS
18 editable Word letters and forms that cover a person's whole time with you — the offer,
the appointment letter, probation, increment, promotion, warning, show cause, exit and the
full and final settlement — plus one Excel workbook that keeps the staff register, the leave
ledger, the leave balance and the settlement calculation in one place.

START HERE
Open 00-START-HERE.html in any browser. It explains every file, what to fill in, and the
order to use them in. No internet connection is needed.

FOLDERS
  templates\  18 Word (.docx) files, numbered in the order you will need them
  excel\      StaffKit-Staff-Register-and-Leave-Tracker.xlsx  (5 sheets)

QUICK START
1. Unzip the folder somewhere permanent, for example Documents\StaffKit.
2. Open 02-appointment-letter.docx and replace the [COMPANY NAME] block at the top with
   your business name, address, phone and email. Save it as your master copy.
3. Replace every field in [SQUARE BRACKETS]. They print bold and dark gold on purpose.
4. Save as PDF before you send it, and keep the Word file as your record.
5. Open the Excel workbook, delete the sample rows (S-001 to S-003 and the five sample
   leave entries), then add your own staff.

COMPATIBILITY
Microsoft Word 2013 or later, Microsoft 365, LibreOffice Writer, and Google Docs (upload
the .docx to Drive and open with Google Docs). The workbook opens in Excel 2016 or later,
Microsoft 365 and Google Sheets. A4 page size throughout; no macros, no add-ins, no fonts
to install.

A NOTE ON THE LAW
The letters are drafted around the way Indian small businesses hire and are aligned to the
50% wage rule under the Code on Wages, 2019 and the two-working-day settlement requirement
for wages. They are templates, not legal advice. Have your adviser check anything material
before you issue it, and check the figures with your accountant.

LICENCE
One business, unlimited employees, lifetime use, no resale. Full terms in LICENSE.txt.

Support: lonefaisal977@gmail.com
