# Printing and sharing — the one-page checklist

Keep this open while you publish.

## Before you download

- [ ] Both first names spelled correctly (check the spelling of every guest's name you mention in "Our story" too)
- [ ] Main date and time entered — this drives the countdown and the calendar file
- [ ] Every function has a venue; the venue text is what the Maps button searches for
- [ ] WhatsApp number entered as `91` + ten digits, no spaces, no `+`
- [ ] Hashtag written the way you want it shared
- [ ] Photos open as images on their own (paste the link in a new tab and check)

## Publish the invitation (5 minutes)

1. Rename your downloaded file to `index.html`, or to something readable like `aarav-weds-diya.html`.
2. Go to `app.netlify.com/drop` and drag the file in. No account needed for the first drop.
3. Copy the link it gives you. That is your invitation link.
4. Open the link on your own phone first — check the countdown, tap RSVP once, tap Add to calendar once.

## Share it

- WhatsApp: paste the link, then edit the auto-preview title and description if WhatsApp picked up the wrong ones (it reads the page title and description, which come from the couple names and the date).
- Instagram: put the link in your bio and in the story link sticker. Stories do not make links clickable on their own.
- Email or printed card: add the link under the QR code.

## Print the card (A5)

- [ ] Chrome → Ctrl+P / Cmd+P
- [ ] Paper: **A5**
- [ ] Margins: **Default**
- [ ] **Background graphics: ON** (the most common reason a card prints white)
- [ ] Scale: **100%**
- [ ] Preview shows one page — if it shows two, reduce the browser scale to 95%

## After the wedding

- [ ] Keep the link live for at least a month after the last function; guests check it for directions
- [ ] The `.ics` file already in your guests' calendars stays there even if you delete the page
- [ ] Turn the page into a thank-you note by editing "Our story" and downloading again — same link, new words

## Troubleshooting quick table

| Symptom | Fix |
| --- | --- |
| Photos do not appear | The link is a page, not an image. Use a direct `.jpg` / `.png` / `.webp` link. |
| RSVP opens WhatsApp with no message | You entered the number with spaces or a `+`. Use `919876543210`. |
| Countdown says the wrong time | It counts to the time you typed, in the guest's own clock. Re-check the time you entered. |
| Card prints white | Turn on Background graphics. |
| Fonts look different on a phone | Expected — the designs use the fonts already on the device. The layout is the same everywhere. |
| Downloaded file opens as code | You are opening it in a text editor. Right-click → Open with → your browser. |
