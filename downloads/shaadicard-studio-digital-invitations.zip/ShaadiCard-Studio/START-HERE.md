# ShaadiCard Studio — start here

A digital invitation maker that runs in your browser. No account, no internet, no Canva.

Open **`shaadicard-studio.html`** by double-clicking it. It opens in Chrome, Edge, Safari or Firefox on a laptop or desktop.

---

## 1. Make your invitation in five minutes

1. **Design** — pick Classic Gold, Midnight Bloom or Marigold.
2. **The couple** — type both first names, the host line ("Together with their families") and your hashtag.
3. **Main day** — date, time, venue. This drives the countdown and the calendar file.
4. **Functions** — press **+ Add** for each function: Mehndi, Haldi, Sangeet, Wedding, Reception. Leave it empty if you only want one day.
5. **Our story, Photos, RSVP** — optional. Fill what you have, skip the rest.
6. Press **Download invitation**. You get one `.html` file — your finished invitation.

The preview on the right is the real thing, not an approximation. What you see is exactly what downloads.

Your work is saved in this browser automatically, so you can close the tab and come back. To move your details to another computer, use **Save project** (a small `.json` file) and **Open project** on the other machine.

---

## 2. What your guests get

The downloaded file is a complete, self-contained invitation page:

- **Countdown** to the main day — days, hours, minutes, seconds.
- **Functions schedule** with a "Open in Maps" link for every venue.
- **RSVP on WhatsApp** — one tap opens WhatsApp with a message already written. Replies land in the number you entered.
- **Add to calendar** — downloads an `.ics` file that works with Google Calendar, Apple Calendar and Outlook, one entry per function.
- **Photo gallery** — if you add image links.
- **A printable card** — Ctrl+P / Cmd+P prints a clean A5 invitation card. The countdown, buttons and gallery are hidden automatically when printing.

Nothing is uploaded anywhere. There is no tracking, no analytics and no server call in the file you download.

---

## 3. Put it online (free)

You do not need a website or a developer. Any one of these works:

**Netlify Drop** — go to `app.netlify.com/drop`, drag your downloaded invitation file into the page, and you get a live link in seconds. Rename the file to `index.html` before dragging if you want the link to be short.

**GitHub Pages** — create a repository, upload the file as `index.html`, then Settings → Pages → deploy from `main`. The link looks like `yourname.github.io/invite`.

**Your existing domain** — upload the file to your hosting as `invite.html` (or `index.html` in a folder) and share that link.

**No hosting at all** — the file also opens straight from a phone if you send it on WhatsApp or email and your guest opens it in a browser. Hosting is better because links are clickable, previews show up, and the RSVP button works on every device.

> Tip: rename the file before uploading — `aarav-weds-diya.html` reads better than `invitation.html` when someone downloads it.

---

## 4. Printed cards

The invitation is also a card. Open your file in Chrome, press **Ctrl+P** (Windows) or **Cmd+P** (Mac), and choose:

- **Paper size:** A5
- **Margins:** Default
- **Background graphics:** ON (otherwise the colours drop out)
- **Scale:** Default (100%)

You get a single A5 card with the names, date, venue, function list and hashtag — no countdown, no buttons, no gallery.

For a QR code on the printed card that opens the digital invitation: upload the invitation first, then use any free QR generator (for example the QR option inside Chrome's share menu, or qr.io) and paste the QR image into your card design. Keep the QR at least 2 cm square so phone cameras read it easily.

---

## 5. Photos that show up

The gallery accepts **direct image links** — a link that opens the photo itself, ending in `.jpg`, `.png` or `.webp`.

- Good: `https://images.example.com/aarav-diya-1.jpg`
- Not good: a Google Photos album link, an Instagram post link, or a Drive share link. Those open a page, not an image, so the photo will not appear.

If you have no hosting for photos, upload them free to a service that gives direct links (Cloudinary, Imgur, or your Netlify site's own folder), then paste those links. Any photo that fails to load is hidden automatically, so the invitation never shows a broken image.

---

## 6. If something looks wrong

**The RSVP button does nothing.** Enter the WhatsApp number with the country code and no spaces or plus sign — for India that is `91` followed by the ten-digit number, like `919876543210`.

**The countdown shows the wrong time.** The countdown runs on each guest's own device clock. It counts to the date and time you entered in your own time zone, so enter Indian Standard Time if your guests are in India.

**My browser blocked the download.** Some browsers block downloads from a file opened directly from disk. Open the studio from your Downloads folder (not from inside a zip file — extract it first), or allow downloads for that page.

**Printing shows a blank or white card.** Turn on "Background graphics" in the print dialog. Without it, browsers print the text only.

**I want to change something after sharing.** Edit the studio, download again, and re-upload the new file to the same place — the link stays the same.

**Can I remove the "With love and blessings" line?** Yes. It is the last `<p class="credit">` in the downloaded file; delete that line in any text editor.

---

## What is in this folder

| File | What it is |
| --- | --- |
| `shaadicard-studio.html` | The maker. Open this first. |
| `example-invitation.html` | A finished invitation using example data, so you can see the output before you start. |
| `preview-three-designs.png` | The three designs side by side — handy when choosing. |
| `START-HERE.md` | This guide. |
| `printing-and-sharing-guide.md` | Printable checklist for hosting, QR codes and the print dialog. |
| `LICENSE.txt` | What you may and may not do with the files. |

Made by Digitalaikart · https://digitalkartai.shop · lonefaisal977@gmail.com
