/* =====================================================================
   SocialKit India — Post Maker engine
   48 ready-to-post social graphics (12 layouts x 4 themes)
   Pure SVG, no external assets, no fonts to download, works offline.
   © 2026 Digitalaikart. Licensed under the SocialKit India Licence
   (see LICENSE.txt). Do not resell the template files themselves.
   ===================================================================== */

(function (root) {
  'use strict';

  var SANS = "'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif";
  var SERIF = "Georgia, 'Times New Roman', serif";

  /* ---------- text helpers ---------- */
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function T(x, y, s, o) {
    o = o || {};
    var a = 'x="' + x + '" y="' + y + '"';
    a += ' fill="' + (o.fill || '#ffffff') + '"';
    a += ' font-family="' + (o.f || SANS) + '"';
    a += ' font-size="' + (o.s || 40) + '"';
    a += ' font-weight="' + (o.w || 400) + '"';
    if (o.ls) a += ' letter-spacing="' + o.ls + '"';
    if (o.a) a += ' text-anchor="' + o.a + '"';
    if (o.op != null) a += ' opacity="' + o.op + '"';
    return '<text ' + a + '>' + esc(s) + '</text>';
  }
  /* wrap a string into lines of at most `max` characters (word safe) */
  function wrap(str, max) {
    var words = String(str || '').replace(/\s+/g, ' ').trim().split(' ');
    var out = [], line = '';
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      if (!line) { line = w; }
      else if ((line + ' ' + w).length <= max) { line += ' ' + w; }
      else { out.push(line); line = w; }
    }
    if (line) out.push(line);
    return out;
  }
  /* multi-line text block; returns markup, advances nothing */
  function block(x, y, str, o) {
    o = o || {};
    var size = o.s || 56, lh = o.lh || size * 1.16;
    var ls = wrap(str, o.max || 22);
    var out = '';
    for (var i = 0; i < ls.length; i++) {
      out += T(x, y + i * lh, ls[i], { s: size, w: o.w, fill: o.fill, f: o.f, a: o.a, ls: o.ls, op: o.op });
    }
    return out;
  }
  function blockHeight(str, o) {
    o = o || {};
    var size = o.s || 56, lh = o.lh || size * 1.16;
    return wrap(str, o.max || 22).length * lh;
  }
  function rule(x1, y1, x2, y2, color, w, op, dash) {
    return '<line x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 + '" stroke="' +
      color + '" stroke-width="' + (w || 2) + '"' + (op ? ' opacity="' + op + '"' : '') +
      (dash ? ' stroke-dasharray="' + dash + '"' : '') + ' stroke-linecap="round"/>';
  }
  function pill(x, y, w, h, fill, stroke) {
    return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' +
      (h / 2) + '" fill="' + fill + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="2"' : '') + '/>';
  }
  function txtWidth(s, size) { return String(s).length * size * 0.56; }

  /* ---------- themes ---------- */
  var THEMES = [
    { id: 'midnight', name: 'Midnight Gold', bg1: '#0a1628', bg2: '#16294a', ink: '#ffffff',
      sub: '#c7d3e3', accent: '#f5c542', accent2: '#e8a82c', onAccent: '#0a1628', line: '#2a3f5f' },
    { id: 'mint', name: 'Fresh Mint', bg1: '#f4f8f5', bg2: '#dcebe2', ink: '#0c2b21',
      sub: '#3d5f51', accent: '#0f7a5a', accent2: '#0a5d45', onAccent: '#ffffff', line: '#b8d3c6' },
    { id: 'marigold', name: 'Marigold Festive', bg1: '#fff6e8', bg2: '#ffe2bf', ink: '#2a1705',
      sub: '#7a4a12', accent: '#c95a08', accent2: '#a34406', onAccent: '#fff6e8', line: '#e8c69b' },
    { id: 'ink', name: 'Bold Ink', bg1: '#111214', bg2: '#1e2024', ink: '#f7f7f7',
      sub: '#b0b4bb', accent: '#ff4d3d', accent2: '#e03a2b', onAccent: '#ffffff', line: '#33363c' }
  ];
  function themeById(id) {
    for (var i = 0; i < THEMES.length; i++) if (THEMES[i].id === id) return THEMES[i];
    return THEMES[0];
  }

  /* ---------- default copy ---------- */
  var DEFAULTS = {
    brand: 'Sharma Studio',
    tagline: 'Salon & Spa · Koramangala, Bengaluru',
    headline: 'Monsoon Glow Offer',
    subline: 'Hair spa, facial and cleanup — book this week',
    offer: '40% OFF',
    code: 'MONSOON40',
    validity: 'Valid till 30 November',
    phone: '+91 98765 43210',
    whatsapp: '+91 98765 43210',
    website: 'sharmastudio.in',
    address: '2nd Cross, 5th Block, Koramangala, Bengaluru 560095',
    hours: 'Mon–Sat 10am–8pm · Sun 11am–6pm',
    items: 'Hair Cut | 350\nHair Spa | 1,200\nFacial | 1,500\nCleanup | 800',
    body: 'Our team is away for a short break. All orders placed during this time will be handled the moment we are back.',
    role: 'Counter Sales Executive',
    bullets: '1–3 years retail experience\nFluent in Kannada and English\nComfortable with billing software',
    quote: 'A good haircut is not a luxury. It is the cheapest way to feel like yourself again.',
    attribution: '— Neha Sharma, Founder',
    footer: 'Walk in or WhatsApp us to book'
  };

  /* ---------- shared chrome ---------- */
  function bg(t, w, h) {
    return '<rect width="' + w + '" height="' + h + '" fill="url(#bg)"/>';
  }
  function defs(t, w, h, u) {
    u = u || '';
    return '<defs>' +
      '<linearGradient id="bg' + u + '" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0" stop-color="' + t.bg1 + '"/><stop offset="1" stop-color="' + t.bg2 + '"/></linearGradient>' +
      '<linearGradient id="ac' + u + '" x1="0" y1="0" x2="1" y2="0">' +
      '<stop offset="0" stop-color="' + t.accent + '"/><stop offset="1" stop-color="' + t.accent2 + '"/></linearGradient>' +
      '<radialGradient id="glow' + u + '" cx="0.5" cy="0.5" r="0.5">' +
      '<stop offset="0" stop-color="' + t.accent + '" stop-opacity="0.22"/>' +
      '<stop offset="1" stop-color="' + t.accent + '" stop-opacity="0"/></radialGradient>' +
      '</defs>';
  }
  function brandRow(d, t, x, y, size) {
    size = size || 26;
    var s = T(x, y, d.brand.toUpperCase(), { s: size, w: 700, ls: size * 0.22, fill: t.ink });
    if (d.tagline) s += T(x, y + size * 1.5, d.tagline, { s: size * 0.78, fill: t.sub, ls: 0.4 });
    return s;
  }
  function contactRow(d, t, x, y, w, size) {
    size = size || 26;
    var s = rule(x, y - size * 1.5, x + w, y - size * 1.5, t.line, 2);
    s += T(x, y, d.phone, { s: size, w: 700, fill: t.ink });
    s += T(x + w, y, d.website, { s: size, w: 400, fill: t.sub, a: 'end' });
    return s;
  }

  /* =====================  LAYOUTS  ===================== */
  var LAYOUTS = [

    /* 1 — Offer burst, square */
    {
      id: 'offer-burst', name: 'Flat Discount Burst', cat: 'Offers', w: 1080, h: 1080,
      dflt: { headline: 'Monsoon Glow Offer', offer: '40% OFF' },
      fields: ['brand', 'tagline', 'offer', 'headline', 'subline', 'code', 'validity', 'phone', 'website'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1080) +
          '<circle cx="980" cy="200" r="420" fill="url(#glow)"/>' +
          '<circle cx="60" cy="1010" r="300" fill="url(#glow)"/>';
        s += brandRow(d, t, 80, 120);
        s += rule(80, 190, 240, 190, t.accent, 4);
        s += T(80, 330, d.headline.toUpperCase(), { s: 34, w: 700, ls: 8, fill: t.sub });
        s += T(80, 560, d.offer, { s: 168, w: 700, fill: 'url(#ac)' });
        s += block(80, 690, d.subline, { s: 40, max: 30, fill: t.ink, lh: 54 });
        if (d.code) {
          var cw = Math.max(320, txtWidth('USE CODE  ' + d.code, 34) * 1.12 + 96);
          s += pill(80, 790, cw, 78, 'none', t.accent);
          s += T(80 + cw / 2, 841, 'USE CODE  ' + d.code, { s: 34, w: 700, a: 'middle', fill: t.accent, ls: 2 });
        }
        s += T(80, 930, d.validity, { s: 30, fill: t.sub });
        s += contactRow(d, t, 80, 1010, 920, 28);
        return s;
      }
    },

    /* 2 — Price list, square */
    {
      id: 'price-list', name: 'Rate Card', cat: 'Menu & Prices', w: 1080, h: 1080,
      dflt: { headline: 'Rate Card', items: 'Hair Cut | 350\nHair Spa | 1,200\nFacial | 1,500\nCleanup | 800\nBeard Trim | 200\nHead Massage | 400' },
      fields: ['brand', 'tagline', 'headline', 'items', 'phone', 'address'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1080) + '<circle cx="1080" cy="0" r="360" fill="url(#glow)"/>';
        s += brandRow(d, t, 80, 116, 24);
        s += T(80, 268, d.headline, { s: 72, w: 700, fill: t.ink });
        s += rule(80, 304, 260, 304, t.accent, 5);

        var rows = String(d.items || '').split('\n').filter(function (r) { return r.trim(); });
        var top = 400, bottom = 900;
        var step = rows.length > 1 ? Math.min(92, (bottom - top) / (rows.length - 1)) : 0;
        var y = top, i;
        for (i = 0; i < rows.length && i < 9; i++) {
          var parts = rows[i].split('|');
          var nm = (parts[0] || '').trim(), pr = (parts[1] || '').trim();
          var yy = top + i * step;
          s += T(80, yy, nm, { s: 38, w: 600, fill: t.ink });
          s += T(1000, yy, pr ? (/\u20b9|rs/i.test(pr) ? pr : '\u20b9' + pr) : '', { s: 38, w: 700, a: 'end', fill: t.accent });
          var wN = txtWidth(nm, 38), wP = txtWidth(pr, 38) + 30;
          if (1000 - wP > 80 + wN + 24) s += rule(80 + wN + 18, yy - 11, 1000 - wP, yy - 11, t.line, 3, 1, '2 12');
          if (i < rows.length - 1 && i < 8) s += rule(80, yy + step / 2 + 8, 1000, yy + step / 2 + 8, t.line, 1, 0.5);
          y = yy;
        }
        s += contactRow(d, t, 80, 990, 920, 28);
        if (d.address) s += T(80, 1036, d.address, { s: 24, fill: t.sub });
        return s;
      }
    },

    /* 3 — Festival greeting, square */
    {
      id: 'festival', name: 'Festival Greeting', cat: 'Festive', w: 1080, h: 1080,
      dflt: { headline: 'Happy Diwali', subline: 'Wishing you light, warmth and a full home this season' },
      fields: ['brand', 'headline', 'subline', 'phone', 'website'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1080);
        /* decorative arcs + dots */
        var cx = 900, cy = 180, i;
        for (i = 1; i <= 4; i++) {
          s += '<circle cx="' + cx + '" cy="' + cy + '" r="' + (70 * i) + '" fill="none" stroke="' +
            t.accent + '" stroke-width="2" opacity="' + (0.42 - i * 0.07) + '"/>';
        }

        s += '<circle cx="140" cy="220" r="300" fill="url(#glow)"/>';
        s += T(80, 560, d.headline.toUpperCase(), { s: 96, w: 700, fill: t.ink, ls: 4 });
        s += block(80, 640, d.subline, { s: 40, max: 32, fill: t.sub, lh: 56 });
        s += rule(80, 840, 260, 840, t.accent, 5);
        s += T(80, 900, 'Warm wishes from the team at', { s: 28, fill: t.sub, ls: 1 });
        s += T(80, 950, d.brand, { s: 42, w: 700, fill: t.ink });
        s += T(80, 1020, d.phone + '  ·  ' + d.website, { s: 26, fill: t.sub });
        return s;
      }
    },

    /* 4 — New arrival, portrait */
    {
      id: 'new-arrival', name: 'New Arrival', cat: 'Products', w: 1080, h: 1350,
      dflt: { headline: 'Just Landed', subline: 'Handloom cotton kurta sets, three new colours' },
      fields: ['brand', 'headline', 'subline', 'offer', 'phone', 'website'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1350);
        s += brandRow(d, t, 80, 120, 24);
        /* product frame */
        s += '<rect x="80" y="200" width="920" height="560" rx="28" fill="' + t.bg1 +
          '" stroke="' + t.line + '" stroke-width="3"/>';
        s += '<rect x="80" y="200" width="920" height="560" rx="28" fill="url(#glow)"/>';
        /* abstract product shape inside the frame */
        s += '<circle cx="540" cy="480" r="150" fill="none" stroke="' + t.accent + '" stroke-width="3" opacity="0.55"/>';
        s += '<circle cx="540" cy="480" r="96" fill="url(#ac)" opacity="0.9"/>';
        s += '<rect x="80" y="200" width="920" height="560" rx="28" fill="none" stroke="' + t.line + '" stroke-width="3"/>';
        /* badge */
        s += '<circle cx="912" cy="238" r="66" fill="url(#ac)"/>';
        s += T(912, 230, 'NEW', { s: 26, w: 700, a: 'middle', fill: t.onAccent, ls: 3 });
        s += T(912, 262, 'IN', { s: 20, w: 700, a: 'middle', fill: t.onAccent, ls: 3 });

        s += T(80, 856, d.headline.toUpperCase(), { s: 32, w: 700, ls: 7, fill: t.accent });
        s += block(80, 936, d.subline, { s: 58, w: 700, max: 26, fill: t.ink, lh: 70 });
        s += pill(80, 1112, 300, 76, 'url(#ac)');
        s += T(230, 1160, 'AVAILABLE NOW', { s: 26, w: 700, a: 'middle', fill: t.onAccent, ls: 2 });
        s += T(410, 1160, d.phone, { s: 30, w: 700, fill: t.ink });
        s += rule(80, 1210, 1000, 1210, t.line, 2);
        s += T(80, 1268, 'Available in store and on WhatsApp', { s: 26, fill: t.sub });
        s += T(1000, 1268, d.website, { s: 26, w: 700, a: 'end', fill: t.ink });
        return s;
      }
    },

    /* 5 — Menu card, portrait */
    {
      id: 'menu', name: 'Menu Card', cat: 'Menu & Prices', w: 1080, h: 1350,
      dflt: { headline: 'Menu', items: '# Hair\nHair Cut | 350\nHair Spa | 1,200\n# Skin\nFacial | 1,500\nCleanup | 800\n# Grooming\nBeard Trim | 200\nHead Massage | 400' },
      fields: ['brand', 'headline', 'items', 'address', 'phone', 'hours'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1350) + '<circle cx="1080" cy="180" r="380" fill="url(#glow)"/>';
        s += T(80, 130, d.brand.toUpperCase(), { s: 26, w: 700, ls: 6, fill: t.accent });
        s += T(80, 254, d.headline, { s: 80, w: 700, fill: t.ink });
        s += rule(80, 292, 320, 292, t.accent, 5);

        var rows = String(d.items || '').split('\n').filter(function (r) { return r.trim(); });
        var top = 380, bottom = 1120;
        var n = 0, i;
        for (i = 0; i < rows.length; i++) n += (rows[i].trim().charAt(0) === '#') ? 1.4 : 1;
        var unit = n > 0 ? (bottom - top) / n : 0;
        var y = top;
        for (i = 0; i < rows.length; i++) {
          var raw = rows[i].trim();
          if (raw.charAt(0) === '#') {
            s += T(80, y + 6, raw.slice(1).trim().toUpperCase(), { s: 22, w: 700, ls: 5, fill: t.accent });
            y += unit * 1.4;
            continue;
          }
          var p = raw.split('|'), nm = (p[0] || '').trim(), pr = (p[1] || '').trim();
          s += T(80, y, nm, { s: 36, w: 500, fill: t.ink });
          s += T(1000, y, pr ? (/\u20b9|rs/i.test(pr) ? pr : '\u20b9' + pr) : '', { s: 36, w: 700, a: 'end', fill: t.ink });
          var wN = txtWidth(nm, 36), wP = txtWidth(pr, 36) + 26;
          if (1000 - wP > 80 + wN + 20) s += rule(80 + wN + 16, y - 11, 1000 - wP, y - 11, t.line, 2, 1, '2 10');
          y += unit;
        }
        s += rule(80, 1200, 1000, 1200, t.line, 2);
        s += T(80, 1248, d.address, { s: 24, fill: t.sub });
        s += T(80, 1290, d.hours, { s: 24, fill: t.sub });
        s += T(1000, 1248, d.phone, { s: 28, w: 700, a: 'end', fill: t.ink });
        return s;
      }
    },

    /* 6 — Story / status, 1080x1920 */
    {
      id: 'story-flash', name: 'Story — Flash Sale', cat: 'Offers', w: 1080, h: 1920,
      fields: ['brand', 'offer', 'headline', 'subline', 'code', 'phone', 'whatsapp'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1920);
        s += '<circle cx="540" cy="760" r="520" fill="url(#glow)"/>';
        s += '<circle cx="540" cy="760" r="380" fill="none" stroke="' + t.accent + '" stroke-width="2" opacity="0.35"/>';
        s += '<circle cx="540" cy="760" r="300" fill="none" stroke="' + t.accent + '" stroke-width="2" opacity="0.22"/>';
        s += T(540, 190, d.brand.toUpperCase(), { s: 30, w: 700, ls: 8, a: 'middle', fill: t.ink });
        s += T(540, 250, 'TODAY ONLY', { s: 24, w: 700, ls: 6, a: 'middle', fill: t.accent });
        s += T(540, 790, d.offer, { s: 180, w: 700, a: 'middle', fill: 'url(#ac)' });
        s += rule(440, 860, 640, 860, t.accent, 4);
        s += block(540, 980, d.headline, { s: 56, w: 700, max: 22, a: 'middle', fill: t.ink, lh: 68 });
        s += block(540, 1110, d.subline, { s: 34, max: 34, a: 'middle', fill: t.sub, lh: 48 });
        if (d.code) {
          s += pill(240, 1310, 600, 92, 'none', t.accent);
          s += T(540, 1368, 'CODE  ' + d.code, { s: 38, w: 700, a: 'middle', fill: t.accent, ls: 3 });
        }
        s += rule(160, 1560, 920, 1560, t.line, 2);
        s += T(540, 1640, 'Order on WhatsApp', { s: 34, w: 700, a: 'middle', fill: t.ink });
        s += T(540, 1700, d.whatsapp, { s: 44, w: 700, a: 'middle', fill: 'url(#ac)' });
        s += T(540, 1820, d.brand + '  ·  ' + 'swipe up to chat', { s: 24, a: 'middle', fill: t.sub });
        return s;
      }
    },

    /* 7 — Contact card, square */
    {
      id: 'contact', name: 'Contact Card', cat: 'Business Basics', w: 1080, h: 1080,
      fields: ['brand', 'tagline', 'phone', 'whatsapp', 'address', 'hours', 'website'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1080) + '<circle cx="960" cy="960" r="420" fill="url(#glow)"/>';
        s += '<rect x="80" y="110" width="8" height="220" rx="4" fill="url(#ac)"/>';
        s += T(126, 178, d.brand, { s: 64, w: 700, fill: t.ink });
        s += block(126, 234, d.tagline, { s: 30, max: 42, fill: t.sub, lh: 40 });

        var rows = [
          ['CALL', d.phone],
          ['WHATSAPP', d.whatsapp],
          ['VISIT', d.address],
          ['HOURS', d.hours]
        ];
        var y = 430;
        for (var i = 0; i < rows.length; i++) {
          s += T(80, y, rows[i][0], { s: 20, w: 700, ls: 5, fill: t.accent });
          var val = rows[i][1] || '';
          var lines = wrap(val, 44);
          for (var k = 0; k < Math.min(lines.length, 2); k++) {
            s += T(80, y + 42 + k * 38, lines[k], { s: 30, w: 500, fill: t.ink });
          }
          y += 42 + Math.max(1, Math.min(lines.length, 2)) * 38 + 26;
        }
        s += rule(80, 960, 1000, 960, t.line, 2);
        s += T(80, 1014, d.website, { s: 27, w: 700, fill: t.sub });
        s += T(1000, 1014, 'DM to book', { s: 27, w: 700, a: 'end', fill: t.accent });
        return s;
      }
    },

    /* 8 — Quote / tip card, square */
    {
      id: 'quote', name: 'Quote Card', cat: 'Content', w: 1080, h: 1080,
      fields: ['brand', 'quote', 'attribution', 'phone'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1080) + '<circle cx="160" cy="120" r="320" fill="url(#glow)"/>';
        /* quote marks */
        s += '<path d="M120 300 q0 -80 80 -80 q-30 40 -10 60 q40 6 40 48 q0 42 -50 42 q-60 0 -60 -70 z" fill="url(#ac)" opacity="0.9"/>';
        s += '<path d="M240 300 q0 -80 80 -80 q-30 40 -10 60 q40 6 40 48 q0 42 -50 42 q-60 0 -60 -70 z" fill="url(#ac)" opacity="0.9"/>';
        var lines = wrap(d.quote, 26);
        var size = lines.length > 4 ? 46 : 56;
        s += block(120, 500, d.quote, { s: size, f: SERIF, max: 26, fill: t.ink, lh: size * 1.35 });
        var qh = blockHeight(d.quote, { s: size, lh: size * 1.35, max: 26 });
        s += rule(120, 500 + qh + 30, 260, 500 + qh + 30, t.accent, 4);
        s += T(120, 500 + qh + 96, d.attribution, { s: 30, w: 700, fill: t.sub });
        s += T(120, 990, d.brand.toUpperCase(), { s: 24, w: 700, ls: 6, fill: t.sub });
        s += T(960, 990, d.phone, { s: 26, w: 700, a: 'end', fill: t.ink });
        return s;
      }
    },

    /* 9 — Combo deal, portrait */
    {
      id: 'combo', name: 'Combo Deal', cat: 'Offers', w: 1080, h: 1350,
      dflt: { headline: 'Hair Spa + Facial Combo', offer: '\u20b91,999', items: 'Hair spa with scalp massage\nBrightening facial\nThreading (eyebrows + upper lip)\nComplimentary head massage', validity: 'Valid on weekdays, 11am to 4pm' },
      fields: ['brand', 'headline', 'items', 'offer', 'validity', 'phone'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1350) + '<circle cx="900" cy="1200" r="440" fill="url(#glow)"/>';
        s += brandRow(d, t, 80, 120, 24);
        s += pill(80, 190, 190, 56, 'url(#ac)');
        s += T(175, 227, 'COMBO', { s: 24, w: 700, a: 'middle', fill: t.onAccent, ls: 4 });
        s += block(80, 350, d.headline, { s: 66, w: 700, max: 24, fill: t.ink, lh: 78 });

        var rows = String(d.items || '').split('\n').filter(function (r) { return r.trim(); });
        var y = 530;
        for (var i = 0; i < rows.length && i < 5; i++) {
          s += '<circle cx="98" cy="' + (y - 12) + '" r="9" fill="' + t.accent + '"/>';
          s += T(130, y, rows[i].trim(), { s: 36, w: 400, fill: t.ink });
          y += 62;
        }
        s += rule(80, y + 20, 1000, y + 20, t.line, 2);
        s += T(80, y + 150, d.offer, { s: 130, w: 700, fill: 'url(#ac)' });
        s += T(80, y + 210, d.validity, { s: 30, fill: t.sub });
        s += pill(80, 1130, 420, 82, 'none', t.accent);
        s += T(290, 1182, 'BOOK ON WHATSAPP', { s: 24, w: 700, a: 'middle', fill: t.accent, ls: 2 });
        s += T(80, 1276, d.phone, { s: 34, w: 700, fill: t.ink });
        s += T(1000, 1276, d.brand, { s: 26, a: 'end', fill: t.sub });
        return s;
      }
    },

    /* 10 — Open hours, square */
    {
      id: 'open-hours', name: 'We Are Open', cat: 'Business Basics', w: 1080, h: 1080,
      dflt: { headline: 'We are open', subline: 'Walk in for a same-day appointment' },
      fields: ['brand', 'headline', 'hours', 'address', 'phone', 'subline'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1080) + '<circle cx="140" cy="940" r="360" fill="url(#glow)"/>';
        s += brandRow(d, t, 80, 120, 24);
        s += '<circle cx="100" cy="330" r="14" fill="' + t.accent + '"/>';
        s += T(130, 342, 'NOW SERVING', { s: 26, w: 700, ls: 6, fill: t.accent });
        s += T(80, 540, d.headline || 'We are open', { s: 120, w: 700, fill: t.ink });
        s += block(80, 640, d.subline, { s: 34, max: 40, fill: t.sub, lh: 48 });
        s += '<rect x="80" y="740" width="920" height="150" rx="24" fill="none" stroke="' + t.line + '" stroke-width="3"/>';
        s += T(120, 806, 'OPENING HOURS', { s: 22, w: 700, ls: 5, fill: t.accent });
        s += block(120, 852, d.hours, { s: 34, w: 500, max: 42, fill: t.ink, lh: 44 });
        s += T(80, 960, d.address, { s: 26, fill: t.sub });
        s += contactRow(d, t, 80, 1030, 920, 28);
        return s;
      }
    },

    /* 11 — Notice, square */
    {
      id: 'notice', name: 'Notice Board', cat: 'Business Basics', w: 1080, h: 1080,
      dflt: { headline: 'Closed 12\u201314 Nov' },
      fields: ['brand', 'headline', 'body', 'phone', 'whatsapp'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1080);
        s += '<rect x="48" y="48" width="984" height="984" rx="18" fill="none" stroke="' + t.accent + '" stroke-width="3" opacity="0.55"/>';
        s += T(80, 150, 'NOTICE', { s: 26, w: 700, ls: 8, fill: t.accent });
        s += T(1000, 150, d.brand.toUpperCase(), { s: 22, w: 700, ls: 4, a: 'end', fill: t.sub });
        s += rule(80, 190, 1000, 190, t.line, 2);
        s += block(80, 330, d.headline, { s: 84, w: 700, max: 20, fill: t.ink, lh: 96 });
        var hh = blockHeight(d.headline, { s: 84, lh: 96, max: 20 });
        s += block(80, 330 + hh + 40, d.body, { s: 32, max: 48, fill: t.sub, lh: 48 });
        s += rule(80, 900, 1000, 900, t.line, 2);
        s += T(80, 960, 'Questions? Call or WhatsApp', { s: 26, fill: t.sub });
        var cl = d.phone;
        if (d.whatsapp && d.whatsapp.replace(/\s/g, '') !== d.phone.replace(/\s/g, '')) cl += '  ·  ' + d.whatsapp;
        s += T(80, 1012, cl, { s: 30, w: 700, fill: t.ink });
        return s;
      }
    },

    /* 12 — Hiring, square */
    {
      id: 'hiring', name: 'We Are Hiring', cat: 'Business Basics', w: 1080, h: 1080,
      dflt: { headline: "We're hiring" },
      fields: ['brand', 'role', 'bullets', 'headline', 'phone', 'whatsapp'],
      draw: function (d, t) {
        var s = bg(t, 1080, 1080) + '<circle cx="1040" cy="60" r="340" fill="url(#glow)"/>';
        /* corner geometry */
        s += '<path d="M0 0 L260 0 L0 260 Z" fill="url(#ac)" opacity="0.18"/>';
        s += '<path d="M1080 1080 L820 1080 L1080 820 Z" fill="url(#ac)" opacity="0.18"/>';
        s += T(80, 140, String(d.headline || "We're hiring").toUpperCase(), { s: 26, w: 700, ls: 8, fill: t.accent });
        s += block(80, 300, d.role, { s: 92, w: 700, max: 18, fill: t.ink, lh: 104 });
        var hh = blockHeight(d.role, { s: 92, lh: 104, max: 18 });
        var rows = String(d.bullets || '').split('\n').filter(function (r) { return r.trim(); });
        var y = 300 + hh + 40;
        for (var i = 0; i < rows.length && i < 5; i++) {
          s += rule(80, y - 12, 104, y - 12, t.accent, 4);
          s += T(126, y, rows[i].trim(), { s: 34, fill: t.sub });
          y += 56;
        }
        s += rule(80, 900, 1000, 900, t.line, 2);
        s += T(80, 958, 'SEND YOUR CV / DM US', { s: 22, w: 700, ls: 5, fill: t.accent });
        s += T(80, 1014, d.whatsapp, { s: 38, w: 700, fill: t.ink });
        s += T(1000, 1014, d.brand, { s: 24, a: 'end', fill: t.sub });
        return s;
      }
    }
  ];

  function layoutById(id) {
    for (var i = 0; i < LAYOUTS.length; i++) if (LAYOUTS[i].id === id) return LAYOUTS[i];
    return LAYOUTS[0];
  }

  /* ---------- renderer ---------- */
  function render(layoutId, themeId, data, opts) {
    opts = opts || {};
    var L = layoutById(layoutId), t = themeById(themeId);
    var d = {};
    for (var k in DEFAULTS) if (DEFAULTS.hasOwnProperty(k)) d[k] = DEFAULTS[k];
    if (L.dflt) for (var q in L.dflt) if (L.dflt.hasOwnProperty(q)) d[q] = L.dflt[q];
    if (data) for (var j in data) if (data[j] != null && data[j] !== '') d[j] = data[j];
    var w = L.w, h = L.h;
    var uid = opts.uid || ('u' + Math.floor(Math.random() * 1e9).toString(36));
    var inner = L.draw(d, t).replace(/url\(#(bg|ac|glow)\)/g, 'url(#$1' + uid + ')');
    var head = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + h +
      '" width="' + w + '" height="' + h + '" role="img" aria-label="' +
      esc(L.name + ' — ' + d.brand) + '">' + defs(t, w, h, uid);
    return head + inner + '</svg>';
  }

  function allTemplates() {
    var out = [];
    for (var i = 0; i < LAYOUTS.length; i++) {
      for (var j = 0; j < THEMES.length; j++) {
        out.push({
          id: LAYOUTS[i].id + '--' + THEMES[j].id,
          layout: LAYOUTS[i].id, theme: THEMES[j].id,
          name: LAYOUTS[i].name, themeName: THEMES[j].name,
          cat: LAYOUTS[i].cat, w: LAYOUTS[i].w, h: LAYOUTS[i].h
        });
      }
    }
    return out;
  }

  var api = { render: render, LAYOUTS: LAYOUTS, THEMES: THEMES, DEFAULTS: DEFAULTS,
    allTemplates: allTemplates, layoutById: layoutById, themeById: themeById };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.SocialKit = api;

  /* =====================================================================
     UI — only runs in a browser
     ===================================================================== */
  if (typeof document === 'undefined') return;

  document.addEventListener('DOMContentLoaded', function () {
    var $ = function (s) { return document.querySelector(s); };
    var state = { layout: LAYOUTS[0].id, theme: THEMES[0].id, cat: 'All', data: {} };
    var saved = {};
    try { saved = JSON.parse(localStorage.getItem('socialkit_brand') || '{}'); } catch (e) { saved = {}; }
    for (var sk in saved) if (saved.hasOwnProperty(sk)) state.data[sk] = saved[sk];

    var previewWrap = $('#preview'), fieldHost = $('#fields'), gallery = $('#gallery');
    var nameEl = $('#tplName'), sizeEl = $('#tplSize'), themeSel = $('#themeSel');

    function current() {
      var L = layoutById(state.layout);
      return { L: L, t: themeById(state.theme) };
    }

    function buildFields() {
      var L = current().L;
      fieldHost.innerHTML = '';
      L.fields.forEach(function (key) {
        var isArea = (key === 'items' || key === 'bullets' || key === 'body' || key === 'quote' || key === 'address' || key === 'headline');
        var val = state.data[key] != null ? state.data[key] : DEFAULTS[key];
        var wrapEl = document.createElement('label');
        wrapEl.className = 'field';
        var lbl = document.createElement('span');
        lbl.textContent = labelFor(key);
        var input = document.createElement(isArea ? 'textarea' : 'input');
        if (isArea) input.rows = (key === 'items' || key === 'bullets') ? 4 : 2;
        input.value = val == null ? '' : val;
        input.addEventListener('input', function () {
          state.data[key] = input.value;
          persist();
          paint();
        });
        wrapEl.appendChild(lbl);
        wrapEl.appendChild(input);
        fieldHost.appendChild(wrapEl);
      });
    }

    function labelFor(k) {
      var m = { brand: 'Business name', tagline: 'Tagline / area', headline: 'Headline',
        subline: 'Supporting line', offer: 'Offer / price', code: 'Coupon code',
        validity: 'Validity line', phone: 'Phone', whatsapp: 'WhatsApp number',
        website: 'Website / handle', address: 'Address', hours: 'Opening hours',
        items: 'List (one per line: Name | Price)', body: 'Body text',
        role: 'Role / job title', bullets: 'Points (one per line)',
        quote: 'Quote text', attribution: 'Attribution', footer: 'Footer line' };
      return m[k] || k;
    }

    function persist() {
      try { localStorage.setItem('socialkit_brand', JSON.stringify(state.data)); } catch (e) {}
    }

    function paint() {
      var L = current().L;
      var svg = render(state.layout, state.theme, state.data);
      previewWrap.innerHTML = svg;
      var el = previewWrap.querySelector('svg');
      el.removeAttribute('width'); el.removeAttribute('height');
      el.setAttribute('preserveAspectRatio', 'xMidYMid meet');
      el.style.width = 'auto'; el.style.maxWidth = '100%'; el.style.maxHeight = '64vh';
      el.style.height = 'auto'; el.style.display = 'block';
      nameEl.textContent = L.name;
      sizeEl.textContent = L.w + ' × ' + L.h + ' px';
      var cards = gallery.querySelectorAll('.tpl');
      for (var i = 0; i < cards.length; i++) {
        cards[i].classList.toggle('sel',
          cards[i].getAttribute('data-layout') === state.layout &&
          cards[i].getAttribute('data-theme') === state.theme);
      }
    }

    function buildGallery() {
      var list = allTemplates();
      gallery.innerHTML = '';
      list.forEach(function (tpl) {
        if (state.cat !== 'All' && tpl.cat !== state.cat) return;
        var b = document.createElement('button');
        b.className = 'tpl';
        b.type = 'button';
        b.setAttribute('data-layout', tpl.layout);
        b.setAttribute('data-theme', tpl.theme);
        var thumb = document.createElement('div');
        thumb.className = 'tpl-thumb';
        thumb.innerHTML = render(tpl.layout, tpl.theme, state.data);
        var cap = document.createElement('div');
        cap.className = 'tpl-cap';
        cap.innerHTML = '<strong>' + tpl.name + '</strong><span>' + tpl.themeName + '</span>';
        b.appendChild(thumb);
        b.appendChild(cap);
        b.addEventListener('click', function () {
          state.layout = tpl.layout;
          state.theme = tpl.theme;
          themeSel.value = tpl.theme;
          buildFields();
          paint();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        gallery.appendChild(b);
      });
    }

    function fileName(ext) {
      var L = current().L;
      return 'socialkit-' + state.layout + '-' + state.theme + '.' + ext;
    }

    function downloadSvg() {
      var svg = render(state.layout, state.theme, state.data);
      var blob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
      triggerDownload(URL.createObjectURL(blob), fileName('svg'));
    }

    function downloadPng() {
      var L = current().L;
      var svg = render(state.layout, state.theme, state.data);
      var img = new Image();
      img.onload = function () {
        var c = document.createElement('canvas');
        c.width = L.w; c.height = L.h;
        var ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0, L.w, L.h);
        c.toBlob(function (blob) { triggerDownload(URL.createObjectURL(blob), fileName('png')); }, 'image/png');
      };
      img.onerror = function () { alert('PNG export failed in this browser. Use "Download SVG" instead.'); };
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    }

    function triggerDownload(url, name) {
      var a = document.createElement('a');
      a.href = url; a.download = name;
      document.body.appendChild(a); a.click();
      document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    }

    $('#btnSvg').addEventListener('click', downloadSvg);
    $('#btnPng').addEventListener('click', downloadPng);
    $('#btnReset').addEventListener('click', function () {
      state.data = {}; persist(); buildFields(); paint(); buildGallery();
    });
    themeSel.addEventListener('change', function () {
      state.theme = themeSel.value; paint();
    });
    var cats = $('#cats');
    ['All', 'Offers', 'Menu & Prices', 'Festive', 'Products', 'Content', 'Business Basics'].forEach(function (c) {
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'chip' + (c === 'All' ? ' on' : '');
      b.textContent = c;
      b.addEventListener('click', function () {
        state.cat = c;
        var chips = cats.querySelectorAll('.chip');
        for (var i = 0; i < chips.length; i++) chips[i].classList.remove('on');
        b.classList.add('on');
        buildGallery();
      });
      cats.appendChild(b);
    });

    themeSel.value = state.theme;
    buildFields(); buildGallery(); paint();
  });

})(typeof window !== 'undefined' ? window : this);
