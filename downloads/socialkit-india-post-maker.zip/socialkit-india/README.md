# SocialKit India — 48 ready-to-post social graphics + offline post maker

**Open `index.html` to start.** No install, no account, no internet needed.

- 12 layouts x 4 colour themes = 48 designs
- Square 1080x1080, portrait 1080x1350, story 1080x1920
- Export PNG (post-ready) or SVG (editable in Inkscape / Illustrator / Figma)
- Edit business details once, every template updates
- Plain HTML + JavaScript + SVG. No libraries, no external fonts, no trackers

## Files
| File | Purpose |
|---|---|
| `index.html` | The Post Maker app |
| `app.js` | Layout engine (12 layouts, 4 themes, export) |
| `samples/` | All 48 designs pre-exported as SVG |
| `README.html` | Full instructions (open in a browser) |
| `LICENSE.txt` | Licence terms |

## Quick start
1. Double-click `index.html`.
2. Fill in your business details in the right-hand panel.
3. Pick a design, pick a theme, press **Download PNG**.

The sample business ("Sharma Studio") is placeholder content — replace every
field with your own details before posting.

## Customising colours
Edit the `THEMES` array at the top of `app.js`. Each theme has `bg1`, `bg2`,
`ink`, `sub`, `accent`, `accent2`, `onAccent` and `line`.

## Licence
Use on unlimited businesses you own or manage. Do not resell or redistribute
the template files. See `LICENSE.txt`.
