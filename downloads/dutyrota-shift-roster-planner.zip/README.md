# DutyRota — staff shift & leave roster planner

**Version 1.0 · Digitalaikart · one-time purchase, no subscription**

DutyRota builds a month of staff shifts for a shop, cafe, kitchen, clinic, salon or
small factory. You describe your team, your shifts and how many people each shift
needs; it fills the month while respecting weekly offs, approved leave, holidays,
your maximum days in a row and each person's weekly cap. Then it prints an A4
landscape roster you can pin to the wall, exports a CSV, and writes a WhatsApp
message you can send to the staff group.

It is a single file — `index.html` — that runs in your browser. Nothing is uploaded,
there is no login, and it works with the internet switched off.

---

## 1. Open it

1. Unzip the folder anywhere on your computer — Desktop is fine.
2. Double-click `index.html`. It opens in Chrome, Edge, Firefox or Safari.
3. On a phone, open the same file in the browser (or email it to yourself and open
   the attachment in Chrome). The layout stacks, and the roster scrolls sideways.

You do not need to install anything, and you do not need a server.

**Keep the folder.** The app saves your roster inside the browser's storage for that
file. If you move or delete the folder, use **Backup** first — see section 6.

---

## 2. Set up your team (left panel)

**Business** — the name printed at the top of the roster, and the month you are planning.

**Maximum days in a row** — the hard limit before the generator forces a day off.
Six is the usual choice for a six-day week; set 5 if your staff must have two days
off a week.

**Nobody is rostered on a holiday** — ticked, a holiday date means the whole team is
off. Untick it if your shop stays open on holidays and you only want the date marked.

**Staff** — one card per person:

| Field | What it does |
|---|---|
| Name | Printed on the roster and in the WhatsApp text |
| Role | A label such as Counter, Kitchen, Delivery. Shown under the name |
| Weekly off | The weekday they are always off (Monday, Tuesday … Sunday). Leave it on "No fixed off" only if they really can work any day |
| Max shifts / week | Their cap in a Monday–Sunday week. 6 means one rest day a week; 5 means two |
| Prefers | Optional. If set, the generator tries to keep this person on that shift |

**Shifts** — one card per shift:

| Field | What it does |
|---|---|
| Name and Code | "Morning" and "M". The code is what appears in the grid — keep it to one or two letters |
| Start / End | 24-hour times, `08:00` to `14:00`. A shift that ends before it starts, like `22:00` to `06:00`, is read as crossing midnight |
| Break (min) | Deducted from the paid hours shown in the totals |
| Needed / day | How many people that shift needs on a normal day |
| Weekend | How many it needs on Saturday and Sunday. Leave it blank to use the same number |

**Leave & holidays** — leave is a date range for one person, either Leave (L) or
Paid holiday (H). Holidays are dates for the whole business. Both are applied the
next time you press **Generate roster**.

---

## 3. Generate and adjust

Press **Generate roster**. The generator fills the month in this order:

1. A cell you edited by hand is **pinned** and never overwritten.
2. Approved leave and paid holidays are placed first.
3. On a closed holiday, nobody is rostered.
4. Each person's weekly-off weekday is always free.
5. Nobody works more than your "maximum days in a row".
6. Nobody works more than their own weekly cap.
7. Everyone still free is spread across the shifts that need people, sharing shift
   types as evenly as possible. Anyone left over gets an extra day off rather than an
   overstaffed shift.

To change one cell, **click it**: shift → Off → Leave → Holiday → clear, and round
again. **Right-click** steps backwards. An edited cell gets a small dot (a pin) and
survives the next Generate. **Clear all pins** removes the pins so the generator owns
the month again.

The **Coverage check** card tells you, per shift, how many people-days the month
needed and how many you rostered, and how many days a shift was short. The **Checks**
card lists anything that needs your attention — a shift with nobody on it, two people
with the same name, a time typed wrongly, a person rostered past the limit.

---

## 4. Print it

Press **Print / PDF**. The print layout is fixed at A4 landscape: your business name,
the month, the legend, the grid, a per-shift coverage line under each day, and a
sign-off line for the manager and the owner.

- In the print dialog choose **A4**, **Landscape**, margins **Default** and scale
  **100%** (not "Fit to page" — it shrinks the grid and makes it hard to read).
- Choose "Save as PDF" instead of a printer to get a file you can WhatsApp.
- The app itself, the side panel and the buttons are not printed.

`sample-roster-print.pdf` in this folder shows exactly what the printout looks like.

---

## 5. Share it

**WhatsApp text** opens the month as plain text, one line per day, with shift codes
and who is off. Press **Copy text** and paste it into your staff group.

```
Sample Sweets & Cafe (example data) — November 2026

1 Sun — M: Anil Kumar, Imran Sheikh | E: Priya Sharma, Meena Iyer, Kavita Nair | F: Ravi Verma | Off: Sunita Devi, Deepak Yadav
2 Mon — M: Sunita Devi, Deepak Yadav | E: Ravi Verma, Imran Sheikh | F: Kavita Nair | Off: Anil Kumar, Priya Sharma, Meena Iyer
```

**CSV** downloads one row per person per day — date, weekday, staff, role, status,
shift, start, end, hours. Open it in Excel, Google Sheets or LibreOffice to cost the
roster against wages, or to feed an attendance sheet. It opens correctly with Indian
date and number settings.

---

## 6. Keep your data

Everything is stored in your own browser. Nothing leaves your computer.

- **Backup** downloads the whole plan as one `.json` file — team, shifts, leave,
  holidays and every assignment.
- **Restore** loads that file back. Use it to move to another computer, to keep a
  copy before you clear the month, or to send the plan to whoever writes the roster.
- Your browser keeps the latest state automatically, so closing the tab does not lose
  work. Clearing browsing data **does** — take a Backup first.

`example-roster.json` is a complete worked example you can Restore to look at, then
edit into your own team.

---

## 7. Working rules worth knowing

- A week runs **Monday to Sunday** for the weekly cap, because that is how most Indian
  rosters and wage weeks are counted.
- Weekly off is one fixed weekday per person. If two people share the same weekly off
  and both are on leave, a weekend shift can be short — the Coverage check will say so.
- The generator never creates overtime; it only assigns one shift per person per day.
- Hours are shown to one decimal place and exclude the break you typed in.
- The roster is a plan, not an attendance record. DutyRota does not record who
  actually turned up.

---

## 8. Troubleshooting

**The page is blank or the buttons do nothing.** Use a current browser (Chrome, Edge,
Firefox, Safari 15 or newer). Very old Internet Explorer will not work.

**It says the browser will not save locally.** Some browsers block storage for files
opened straight from disk. The app still works; press **Backup** before closing, and
**Restore** next time.

**The printout is cut off on the right.** Set landscape and 100% scale, and turn off
"Fit to page" or "Shrink oversized pages".

**A shift is short every day.** You have fewer people than the shifts need, or too
many weekly offs on the same weekday. Lower "Needed / day", add a person, or spread
the weekly offs.

**Somebody got an extra day off.** There were more people available than slots that
day. That is deliberate: the alternative is paying someone to stand around. Pin them
into a shift if you want them in.

**I want next month with the same team.** Change the month in the Business panel. Your
staff, shifts, leave and holidays stay; press **Generate roster** for the new month.

---

## 9. Licence in one line

One buyer, one business, unlimited staff and unlimited printing inside that business.
Do not resell, redistribute or host the files for other people. Full terms in
`LICENSE.txt`.

Questions or a file that will not open: **lonefaisal977@gmail.com** — replacements
within 7 days of purchase.
