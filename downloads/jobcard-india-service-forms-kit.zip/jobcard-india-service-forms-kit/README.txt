JobCard India — 8 Service Business Forms (Word + PDF)
Version 1.0 · published 15 November 2026

WHAT THIS IS
Eight forms for an Indian service business, each supplied twice: an editable
.docx you can brand in a minute, and a print-ready .pdf. A4, one page each.

QUICK START
1. Unzip the folder anywhere. Nothing to install.
2. Open forms/01-job-card.docx in Word, LibreOffice, Google Docs or WPS.
3. Replace "YOUR BUSINESS NAME" and the grey address line with your own
   details (Ctrl+H, Replace All, or just click and type).
4. Repeat in the other seven files. Ten minutes, once.
5. Print a pad, or fill the PDF on a tablet.

THE FORMS
01-job-card.docx / .pdf              Job Card / Service Request (intake)
02-service-estimate.docx / .pdf      Service Estimate / Quotation (GST rows)
03-work-order.docx / .pdf            Work Order / Job Assignment
04-delivery-challan.docx / .pdf      Delivery Challan (HSN, serials, e-way bill)
05-amc-contract.docx / .pdf          Annual Maintenance Contract
06-warranty-certificate.docx / .pdf  Warranty Certificate
07-completion-handover.docx / .pdf   Work Completion & Handover Note
08-payment-receipt.docx / .pdf       Payment Receipt (UPI, UTR, balance)

FILES
forms/            The eight forms, .docx and .pdf
START-HERE.html   The full guide: when to use each form, numbering, what to
                  capture at intake, the clauses that protect you, GST notes,
                  printing tips, editing and troubleshooting
README.txt        This file
LICENSE.txt       Your licence

WHAT TO CHANGE BEFORE FIRST USE
- "YOUR BUSINESS NAME" and the address line in the header of every form
- The storage charge (Rs 50/day) and the 30-day / 90-day periods in JC-01, if
  your practice differs
- The workmanship warranty period (30 days in JC-01, editable in JC-06)
- Any clause your accountant or lawyer wants changed

IMPORTANT
These are business templates, not legal advice. GST rates, thresholds and
e-way bill limits change; confirm the current rule with your accountant.

Support: lonefaisal977@gmail.com
