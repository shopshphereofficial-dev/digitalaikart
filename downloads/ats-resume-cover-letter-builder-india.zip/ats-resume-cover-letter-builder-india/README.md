# ATS Resume & Cover Letter Builder — India Edition

An offline resume and cover-letter builder that runs entirely in your browser.
No sign-up, no subscription, no upload, no watermark. Fill in your details, watch the
live preview, check your resume against the job advert, then print or save as PDF.

Built by **Digitalaikart** · https://digitalkartai.shop

---

## What is in this folder

| File | What it is |
|---|---|
| `index.html` | The builder app. Double-click it to open in your browser. |
| `ATS-Playbook.html` | A bonus reference: bullet formulas, action verbs, keyword banks, Indian conventions and a formatting checklist. |
| `example-data.json` | A clearly-labelled example profile you can import to see how everything looks. |
| `README.md` | This file. |
| `LICENSE.txt` | The licence for your purchase. |

---

## How to open it

1. Unzip this folder anywhere on your computer or phone.
2. Double-click **`index.html`**. It opens in Chrome, Edge, Firefox, Safari, Brave or Opera.
3. That is it. The app works fully offline — you do not need an internet connection,
   an account, or any software installed.

> Tip: keep the whole folder together. If you move `index.html` somewhere else, move the
> other files with it.

---

## How to build your resume

1. **Personal details** — name, headline (your target job title), email, phone, city and
   LinkedIn. These form the top of the resume.
2. **Professional summary** — two or three lines: your role, your years and domain, two
   tools you use, and one measurable result.
3. **Skills** — type them comma-separated. List 10–16 and use the exact words from the job advert.
4. **Work experience** — click *Add experience* for each role. Write one bullet per line,
   using the formula **action verb + what you did + tool + measurable result**
   (e.g. *"Automated the monthly MIS in Power BI, cutting reporting time 40%."*).
5. **Education, projects, extras** — fill in as much as applies. Freshers should give
   projects and internships a full treatment here.
6. Watch the **live preview** on the right (or below on a phone). It is a true A4 page.

## How to check your resume against a job advert

1. Paste the full job advert into the **ATS keyword check** box.
2. The readiness score and the bars update instantly. Each bar shows what you scored and
   what to fix.
3. The tips list the advert keywords you are missing. Weave in the ones that are genuinely
   true for you, then re-check.

The score is a transparent, rule-based checklist (contact details, summary length, skills
count, experience bullets, measurable results, action verbs, education, and keyword match
against the advert). It is a writing aid, not a prediction of any specific employer's system.

## How to save and apply

- **Print / Save as PDF** — click the gold button. In the print dialog choose
  *Save as PDF* (or *Microsoft Print to PDF*). Print settings: **A4**, margins **None/Default**,
  and **Background graphics ON** so the accent colour prints. The tool prints only the
  document you are viewing — no app interface, no watermark.
- **Cover letter tab** — fill the role, company and tone, click *Generate cover letter*,
  then edit the text until it sounds like you. Print it the same way.
- **Copy resume as plain text** / **Download plain-text resume** — for portals (like some
  Naukri or company forms) that ask you to paste text rather than upload a file.
- **Save draft** — keeps your work in this browser for next time.
- **Export JSON / Import JSON** — a portable backup. Import `example-data.json` to try it.
- **Clear all** — start again from empty.

Your details never leave your device. The app stores a draft only in your own browser's
local storage, and you can clear it at any time.

---

## Choosing a template and colour

Three templates ship with the builder, all deliberately **single-column** so that resume
parsers read them cleanly:

- **Classic ATS** — serif, understated, safest for any industry.
- **Modern** — sans-serif with a coloured name and headings.
- **Executive** — centred, letter-spaced, conservative; good for senior and finance roles.

Use the colour picker to set the accent. Keep it professional — navy, graphite, teal or maroon.

---

## Compatibility

- **Browsers:** current Chrome, Edge, Firefox, Safari, Brave, Opera — desktop and mobile.
- **Operating systems:** Windows, macOS, Linux, Android, iOS. Nothing to install.
- **Output:** A4 PDF via your browser's print dialog, or plain text for copy-paste.
- **Word (.docx):** if an advert demands a Word file, open the printed PDF in Word
  (*File → Open*) or type the content into a blank document — the text is all selectable.

---

## Tips for the best result

- One page for under ~8 years of experience; two pages at most for senior roles.
- Put a number in as many bullets as you honestly can.
- Mirror the job title from the advert in your headline.
- Re-tailor for each application — paste each new advert into the keyword check.
- Read `ATS-Playbook.html` for bullet formulas and keyword banks by function.

---

## Support

Questions, a file that will not open, or a payment issue? Email
**lonefaisal977@gmail.com** with your Razorpay payment reference and we will help.

© 2026 Digitalaikart. See `LICENSE.txt` for the terms of use.
