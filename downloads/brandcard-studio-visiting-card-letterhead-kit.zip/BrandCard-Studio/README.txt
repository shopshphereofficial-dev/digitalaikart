BRANDCARD STUDIO — VISITING CARDS, LETTERHEAD & SERVICE CARD
India Edition · Digitalaikart (digitalkartai.shop)

--------------------------------------------------------------
QUICK START
--------------------------------------------------------------
1. Double-click index.html. It opens in Chrome, Edge, Firefox or Safari.
2. Type your business details in the left panel.
3. Pick a template, an accent colour, and (optionally) your UPI QR image.
4. Choose "What to print", click "Print / Save as PDF".
   In the dialog: Margins = None, Scale = 100%, Background graphics = ON.
5. Send the PDF to a local press, or print at home.

Read START-HERE.html for the full guide (printing specs, duplex
alignment, colours, troubleshooting).

--------------------------------------------------------------
FILES
--------------------------------------------------------------
index.html            The studio. Single file, works offline.
START-HERE.html       Full printable guide.
example-profile.json  Example data (Sharma Electricals) to load and edit.
README.txt            This file.
LICENSE.txt           Usage terms.

--------------------------------------------------------------
WHAT IT MAKES
--------------------------------------------------------------
Visiting cards   90 x 54 mm (standard India), 85 x 50 mm, or 54 x 90 mm
                 vertical. 10 cards per A4 sheet at 90x54, cut guides on,
                 back sheet mirrored for duplex printing.
Letterhead       A4, 210 x 297 mm, header band, watermark monogram,
                 footer with address and GSTIN.
Rate card        A5, 148 x 210 mm, up to 8 services with prices,
                 payment QR and a note line.

6 card templates: Classic Rule, Gold Band (dark), Vertical Split,
Monogram, Service List, Minimal Grid.
8 accent colours. Your text is never uploaded anywhere.

--------------------------------------------------------------
SYSTEM REQUIREMENTS
--------------------------------------------------------------
Any modern browser from the last few years. No installation, no
account, no internet connection needed, no macros, no add-ins.
Best on a laptop or desktop; the layout is not built for phones.

--------------------------------------------------------------
TROUBLESHOOTING
--------------------------------------------------------------
Cards print smaller than 90 x 54 mm
  Your print dialog is scaling. Set Scale to 100% / Actual size and
  turn OFF "Fit to page" or "Shrink to fit".

Background colours do not print
  Turn on "Background graphics" (Chrome/Edge) or "Print backgrounds"
  (Safari/Firefox).

Backs do not line up with fronts
  Print the 2-page PDF as a duplex job, flip on the LONG edge. Test on
  plain paper first. The back sheet is already mirrored.

QR code will not scan
  Use a large, clean PNG/JPG of the QR (not a tiny screenshot), and a
  template with a white back. Print at 300 GSM quality.

Text is cut off at the card edge
  Shorten the business name or the tagline. Long names shrink
  automatically, but a 60-character name will not fit a 90 mm card.

Nothing happens when I click Print
  Some browsers block printing from local files in private mode. Open
  the file in a normal window.

I lost my details
  Reload the page - the studio restores your last session. If you saved
  a profile JSON, click "Load profile" and pick it.

--------------------------------------------------------------
SUPPORT
--------------------------------------------------------------
Email lonefaisal977@gmail.com with the template name and a screenshot
of the print dialog if something does not behave. We fix broken files.

Version 1.0 · November 2026
