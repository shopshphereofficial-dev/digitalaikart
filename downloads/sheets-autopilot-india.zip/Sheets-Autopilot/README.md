# Sheets Autopilot — 12 Google Sheets automations for small businesses

Everything in this pack runs inside your own Google account, on Google Apps Script.
No server, no subscription, no third-party login, no API keys.

**Start with `SETUP-GUIDE.html`** (open it in any browser). `START-HERE.txt` is the
60-second version.

---

## What is in the box

| File | What it is |
|---|---|
| `SETUP-GUIDE.html` | The full guide — setup, every automation, quotas, troubleshooting. Open in a browser. |
| `picker.html` | Offline script picker: search the 12 automations, copy the code, or download the `.gs`. |
| `Sheets-Autopilot-Starter.xlsx` | Starter workbook with the exact columns each script reads, plus clearly-marked example rows. |
| `scripts/01…12-*.gs` | The 12 scripts. Each is self-contained with its own `CONFIG` block at the top. |
| `tests/run-tests.js` | Self-test suite. `node tests/run-tests.js` — 30 checks, no dependencies. |
| `LICENSE.txt` | Single-user licence. |

## The 12 automations

| # | File | Does | Reads | Trigger |
|---|---|---|---|---|
| 01 | `01-invoice-reminders.gs` | Escalating payment reminders at −3, 0, +7, +15, +30 days | Invoices | Daily 9am |
| 02 | `02-payment-receipts.gs` | Receipt email with amount in Indian words the moment a row is Paid | Invoices | Every 15 min |
| 03 | `03-lead-followups.gs` | Instant ack + follow-ups on day 3, 7, 14; stops when the lead closes | Leads | Daily 10am |
| 04 | `04-daily-digest.gs` | One 8am email: overdue, due today, leads, stock, deadlines | 4 tabs | Daily 8am |
| 05 | `05-low-stock-alert.gs` | Alerts at the reorder level, once per item per day | Stock | Daily 9am |
| 06 | `06-gst-reminders.gs` | GST milestone reminders with a 7-point checklist | none | Daily 8am |
| 07 | `07-deadlines-to-calendar.gs` | Syncs deadlines to Google Calendar, idempotently | Deadlines | Every 6 h |
| 08 | `08-weekly-backup.gs` | CSV backup of every tab to Drive, last 8 kept | all tabs | Sunday 10pm |
| 09 | `09-duplicate-cleanup.gs` | Finds duplicate leads by phone/email, flags, never deletes | Leads | On demand |
| 10 | `10-client-onboarding.gs` | New client → Drive folder + filled template + welcome email | Clients | Every 30 min |
| 11 | `11-monthly-client-report.gs` | Per-client monthly invoiced/paid/pending summary | Invoices, Deadlines | 1st, 9am |
| 12 | `12-whatsapp-reminders.gs` | Daily list of wa.me links with the message pre-typed | Invoices, Leads | Daily 9am |

## Quick start (one automation)

1. Upload `Sheets-Autopilot-Starter.xlsx` to Drive → open with Google Sheets → *File > Save as Google Sheets*.
2. Delete the example rows (every one is marked `(example)`).
3. *Extensions > Apps Script*, replace `Code.gs` with one script from `scripts/`.
4. Edit the `CONFIG` block at the top: business name, your email, sheet name.
5. Run the `install…()` function once, approve the permissions, then run the main
   function by hand and check *Executions*.

One Apps Script project per script is the simplest arrangement — the scripts each carry
their own helper functions with the same names.

## Column headers each script expects

Exact header text matters. The starter workbook already has all of them.

**Invoices** — `Invoice No | Client Name | Client Email | Client Phone | Amount | Date Issued | Due Date | Status | Paid On | Payment Mode | Notes | Last Reminder | Reminder Stage | Receipt No`

**Leads** — `Date | Name | Phone | Email | Source | Requirement | Status | Last Contact | Next Follow-up | Notes | Follow-up Stage | Duplicate Of`

**Stock** — `SKU | Item | Unit | Opening Qty | In Qty | Out Qty | Reorder Level | Unit Cost | Last Alert On`

**Deadlines** — `Title | Client | Due Date | Type | Owner | Status | Calendar Event ID`

**Clients** — `Client Name | Email | Phone | Company | Plan | Onboarded On | Drive Folder ID | Status`

Status values are compared case-insensitively, but they must be a clean value:
`Paid`, `Unpaid`, `Won`, `Lost`, `Done`, `New` — not `paid ✓`.

## Running the tests

```bash
node tests/run-tests.js
```

No `npm install`. The suite loads each script into a sandbox with stand-ins for
`SpreadsheetApp`, `MailApp` and friends, then checks the logic: date maths, the
Indian money format, amount in words, duplicate grouping, CSV escaping, GST
milestone dates and the WhatsApp link builder. 30 checks.

## Limits worth knowing

Apps Script quotas (Google's published figures): a personal `@gmail.com` account can
email 100 recipients a day with 90 minutes of total trigger runtime; Google Workspace
is 1,500 recipients and 6 hours. Design around those numbers, or move the project to
Workspace for volume.

## Support

Email **lonefaisal977@gmail.com** with the script name and the error text from the
Executions panel. Bug fixes are free.
