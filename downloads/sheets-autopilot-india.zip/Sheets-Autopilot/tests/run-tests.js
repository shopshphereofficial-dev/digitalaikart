/**
 * Self-test suite for Sheets Autopilot.
 *
 * Runs every .gs file in ../scripts inside a sandbox with stand-ins for
 * SpreadsheetApp / MailApp / DriveApp, then checks the logic of each
 * automation — date maths, money formatting, duplicate detection, CSV
 * escaping, WhatsApp links and the full send paths.
 *
 * Usage:  node tests/run-tests.js
 * Needs:  Node 16 or newer. No dependencies, no install.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const SCRIPTS = path.join(__dirname, '..', 'scripts');
const results = [];

function test(name, fn) {
  try { fn(); results.push({ ok: true, name }); }
  catch (e) { results.push({ ok: false, name, err: e.message }); }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || 'assertion failed'); }
function eq(actual, expected, msg) {
  const a = JSON.stringify(actual), b = JSON.stringify(expected);
  if (a !== b) throw new Error((msg ? msg + ': ' : '') + 'expected ' + b + ', got ' + a);
}

/* ------------------------------------------------------------ sheet mock */

class FakeSheet {
  constructor(name, values) {
    this.name = name;
    this.values = (values || []).map(r => r.slice());
  }
  getName() { return this.name; }
  getDataRange() {
    const self = this;
    return { getValues() { return self.values.map(r => r.slice()); } };
  }
  getRange(row, col) {
    const self = this;
    return {
      setValue(v) {
        while (self.values.length < row) self.values.push([]);
        const r = self.values[row - 1];
        while (r.length < col) r.push('');
        r[col - 1] = v;
        return this;
      },
      getValue() { return (self.values[row - 1] || [])[col - 1]; }
    };
  }
}

function book(sheets) {
  return {
    getSheetByName(n) { return sheets[n] || null; },
    getSheets() { return Object.keys(sheets).map(k => sheets[k]); }
  };
}

/* ----------------------------------------------------------- loader mock */

function load(file, sheetMap) {
  const code = fs.readFileSync(path.join(SCRIPTS, file), 'utf8');
  const mail = [];
  const logs = [];
  const sandbox = {
    console,
    MailApp: { sendEmail(o) { mail.push(o); } },
    Logger: { log(m) { logs.push(m); } },
    SpreadsheetApp: {
      getActiveSpreadsheet() { return book(sheetMap || {}); },
      getUi() { return { createMenu() { return { addItem() { return this; }, addToUi() { return this; } }; } }; }
    },
    Utilities: { newBlob: (d, t, n) => ({ name: n, getDataAsString: () => d }) },
    DriveApp: {},
    DocumentApp: {},
    CalendarApp: {},
    ScriptApp: { getProjectTriggers: () => [], WeekDay: { SUNDAY: 'SUNDAY' } },
    encodeURIComponent,
    Object, Array, String, Number, Date, Math, JSON, RegExp, isNaN, parseInt, parseFloat
  };
  sandbox.global = sandbox;
  vm.createContext(sandbox);
  new vm.Script(code, { filename: file }).runInContext(sandbox);
  sandbox.__mail = mail;
  sandbox.__logs = logs;
  return sandbox;
}

const FILES = fs.readdirSync(SCRIPTS).filter(f => f.endsWith('.gs')).sort();

/* ================================================================ syntax */

test('all script files parse cleanly', () => {
  assert(FILES.length === 12, 'expected 12 scripts, found ' + FILES.length);
  FILES.forEach(f => new vm.Script(fs.readFileSync(path.join(SCRIPTS, f), 'utf8'), { filename: f }));
});

/* ================================================== 01 invoice reminders */

const invHeaders = ['Invoice No', 'Client Name', 'Client Email', 'Amount', 'Date Issued',
  'Due Date', 'Status', 'Paid On', 'Notes', 'Last Reminder', 'Reminder Stage'];

function day(offset) {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  d.setDate(d.getDate() + offset);
  return d;
}

test('01 money_ formats in the Indian lakh/crore grouping', () => {
  const c = load('01-invoice-reminders.gs');
  eq(c.money_(123456.5), '₹1,23,456.50');
  eq(c.money_(1500), '₹1,500.00');
  eq(c.money_(0), '₹0.00');
  eq(c.money_(-2500), '-₹2,500.00');
  eq(c.money_(10000000), '₹1,00,00,000.00');
});

test('01 stageFor_ picks the right reminder stage', () => {
  const c = load('01-invoice-reminders.gs');
  eq(c.stageFor_(10), null, 'more than 3 days out is too early');
  eq(c.stageFor_(3).key, 'T-3');
  eq(c.stageFor_(0).key, 'DUE');
  eq(c.stageFor_(-3).key, 'DUE', 'latest crossed milestone wins');
  eq(c.stageFor_(-7).key, 'D+7');
  eq(c.stageFor_(-10).key, 'D+7');
  eq(c.stageFor_(-16).key, 'D+15');
  eq(c.stageFor_(-40).key, 'D+30');
});

test('01 stageAlreadySent_ prevents repeat emails', () => {
  const c = load('01-invoice-reminders.gs');
  assert(c.stageAlreadySent_('D+7') === true, 'known stage should count as sent');
  assert(c.stageAlreadySent_('') === false, 'blank stage should not count as sent');
  assert(c.stageAlreadySent_(null) === false, 'null stage should not count as sent');
});

test('01 sendInvoiceReminders emails only the rows that are due', () => {
  const sheet = new FakeSheet('Invoices', [
    invHeaders,
    ['INV-1', 'Asha', 'asha@example.com', 5000, day(-20), day(0), 'Unpaid', '', '', '', ''],
    ['INV-2', 'Ravi', 'ravi@example.com', 12000, day(-40), day(-10), 'Unpaid', '', '', '', ''],
    ['INV-3', 'Meera', 'meera@example.com', 8000, day(-5), day(20), 'Unpaid', '', '', '', ''],
    ['INV-4', 'Paid Co', 'paid@example.com', 3000, day(-30), day(-5), 'Paid', day(-6), '', '', ''],
    ['INV-5', 'No Email', '', 1000, day(-9), day(0), 'Unpaid', '', '', '', '']
  ]);
  const c = load('01-invoice-reminders.gs', { Invoices: sheet });
  const sent = c.sendInvoiceReminders();
  eq(sent.length, 2, 'two client reminders');
  eq(sent.map(s => s.invoice).sort(), ['INV-1', 'INV-2']);
  eq(sheet.values[1][10], 'DUE');        // reminder stage written back
  eq(sheet.values[2][10], 'D+7');
  assert(sheet.values[1][9] instanceof Date, 'last reminder timestamp written');
  assert(c.__mail.some(m => m.to === 'you@example.com'), 'owner summary sent');
  assert(c.__mail[0].body.indexOf('₹5,000.00') > -1, 'amount appears in the email body');
});

/* ==================================================== 02 payment receipts */

test('02 amountInWordsIndian_ writes Indian words', () => {
  const c = load('02-payment-receipts.gs');
  eq(c.amountInWordsIndian_(125000), 'One Lakh Twenty Five Thousand Rupees Only');
  eq(c.amountInWordsIndian_(10500000), 'One Crore Five Lakh Rupees Only');
  eq(c.amountInWordsIndian_(100), 'One Hundred Rupees Only');
  eq(c.amountInWordsIndian_(0), 'Zero Rupees Only');
  eq(c.amountInWordsIndian_(2500.5), 'Two Thousand Five Hundred Rupees and Fifty Paise Only');
  eq(c.amountInWordsIndian_(99), 'Ninety Nine Rupees Only');
});

test('02 receiptNumber_ and pendingReceipts_', () => {
  const c = load('02-payment-receipts.gs');
  eq(c.receiptNumber_('RCPT', new Date(2026, 9, 26), 7), 'RCPT-2026-10-0007');
  const rows = [
    { Status: 'Paid', 'Receipt No': '' },
    { Status: 'paid', 'Receipt No': 'RCPT-2026-10-0001' },
    { Status: 'Unpaid', 'Receipt No': '' },
    { Status: 'Settled', 'Receipt No': '' }
  ];
  eq(c.pendingReceipts_(rows).length, 2);
});

test('02 sendPaymentReceipts issues numbers and emails once', () => {
  const sheet = new FakeSheet('Invoices', [
    ['Invoice No', 'Client Name', 'Client Email', 'Amount', 'Date Issued', 'Due Date', 'Status', 'Paid On', 'Receipt No'],
    ['INV-9', 'Asha', 'asha@example.com', 125000, day(-10), day(0), 'Paid', day(0), ''],
    ['INV-10', 'Ravi', 'ravi@example.com', 4000, day(-3), day(3), 'Unpaid', '', '']
  ]);
  const c = load('02-payment-receipts.gs', { Invoices: sheet });
  const sent = c.sendPaymentReceipts();
  eq(sent.length, 1);
  eq(sheet.values[1][8], 'RCPT-' + new Date().getFullYear() + '-' + String(new Date().getMonth() + 1).padStart(2, '0') + '-0001');
  assert(c.__mail[0].body.indexOf('One Lakh Twenty Five Thousand Rupees Only') > -1, 'words in receipt');
  // second run must not re-issue
  eq(c.sendPaymentReceipts().length, 0);
});

/* ===================================================== 03 lead follow-ups */

test('03 nextStageFor_ respects schedule and stop statuses', () => {
  const c = load('03-lead-followups.gs');
  const today = new Date();
  const fresh = { Date: today, Status: 'New', 'Follow-up Stage': '' };
  eq(c.nextStageFor_(fresh, today).due, true, 'first contact is due immediately');
  eq(c.nextStageFor_(fresh, today).stage, 1);

  const waiting = { Date: day(0), Status: 'New', 'Follow-up Stage': 1 };
  eq(c.nextStageFor_(waiting, today).due, false, 'day 3 follow-up not due on day 0');

  const later = { Date: day(-4), Status: 'New', 'Follow-up Stage': 1 };
  eq(c.nextStageFor_(later, today).due, true, 'day 3 follow-up due on day 4');
  eq(c.nextStageFor_(later, today).stage, 2);

  const won = { Date: day(-20), Status: 'Won', 'Follow-up Stage': 1 };
  eq(c.nextStageFor_(won, today).due, false, 'closed leads are never chased');

  const lastOne = { Date: day(-60), Status: 'New', 'Follow-up Stage': 3 };
  eq(c.nextStageFor_(lastOne, today).stage, 4, 'the final follow-up is still due');
  const finished = { Date: day(-60), Status: 'New', 'Follow-up Stage': 4 };
  eq(c.nextStageFor_(finished, today).due, false, 'sequence ends after the last stage');
});

test('03 runLeadFollowUps sends and stops correctly', () => {
  const sheet = new FakeSheet('Leads', [
    ['Date', 'Name', 'Phone', 'Email', 'Source', 'Requirement', 'Status', 'Last Contact', 'Next Follow-up', 'Notes', 'Follow-up Stage'],
    [day(0), 'New Lead', '9876543210', 'new@example.com', 'Instagram', 'Logo design', 'New', '', '', '', ''],
    [day(-30), 'Lost Lead', '9876543211', 'lost@example.com', 'Referral', 'Website', 'Lost', '', '', '', ''],
    [day(-5), 'Stage Two', '9876543212', 'two@example.com', 'Walk-in', 'Menu card', 'New', day(-5), day(0), '', 1]
  ]);
  const c = load('03-lead-followups.gs', { Leads: sheet });
  const sent = c.runLeadFollowUps();
  eq(sent.length, 2, 'new lead ack + stage two follow-up');
  eq(sheet.values[1][10], 1);
  eq(sheet.values[3][10], 2);
  assert(sheet.values[1][8] instanceof Date, 'next follow-up date set');
});

/* ======================================================== 04 daily digest */

test('04 buildDigestModel_ classifies invoices, stock and deadlines', () => {
  const c = load('04-daily-digest.gs');
  const today = new Date();
  const model = c.buildDigestModel_({
    invoices: [
      { 'Invoice No': 'A', 'Client Name': 'X', Amount: 1000, 'Due Date': day(0), Status: 'Unpaid' },
      { 'Invoice No': 'B', 'Client Name': 'Y', Amount: 2500, 'Due Date': day(-4), Status: 'Unpaid' },
      { 'Invoice No': 'C', 'Client Name': 'Z', Amount: 900, 'Due Date': day(-2), Status: 'Paid' }
    ],
    leads: [{ Name: 'L', Phone: '9', 'Next Follow-up': day(-1), Status: 'New' }],
    stock: [{ SKU: 'S1', Item: 'Chai cups', 'Opening Qty': 5, 'In Qty': 0, 'Out Qty': 0, 'Reorder Level': 10 }],
    deadlines: [{ Title: 'D', Client: 'C', 'Due Date': day(3), Status: 'Open' }]
  }, today, c.CONFIG);
  eq(model.dueToday.length, 1);
  eq(model.overdue.length, 1);
  eq(model.overdueTotal, 2500);
  eq(model.leads.length, 1);
  eq(model.stock.length, 1);
  eq(model.deadlines.length, 1);
  assert(c.isQuiet_(model) === false, 'model is not quiet');
});

test('04 buildDigestHtml_ renders totals and escapes markup', () => {
  const c = load('04-daily-digest.gs');
  const today = new Date();
  const model = {
    dueToday: [{ 'Invoice No': 'A', 'Client Name': 'X <b>', Amount: 1000 }],
    overdue: [{ 'Invoice No': 'B', 'Client Name': 'Y', Amount: 2500, 'Due Date': day(-4) }],
    leads: [], stock: [], deadlines: [],
    overdueTotal: 2500, dueTotal: 1000
  };
  const html = c.buildDigestHtml_(model, today, c.CONFIG);
  assert(html.indexOf('₹2,500.00') > -1, 'overdue total in html');
  assert(html.indexOf('&lt;b&gt;') > -1, 'html is escaped');
  assert(html.indexOf('<table') > -1, 'tables rendered');
});

/* ====================================================== 05 low stock alert */

test('05 currentQty_ and lowStockItems_ (with same-day dedupe)', () => {
  const c = load('05-low-stock-alert.gs');
  const today = new Date();
  eq(c.currentQty_({ 'Opening Qty': 10, 'In Qty': 5, 'Out Qty': 3 }), 12);
  eq(c.currentQty_({ 'Current Qty': 4, 'Opening Qty': 99 }), 4);

  const rows = [
    { _row: 2, SKU: 'A', Item: 'Cups', 'Opening Qty': 4, 'In Qty': 0, 'Out Qty': 0, 'Reorder Level': 10, 'Unit Cost': 2 },
    { _row: 3, SKU: 'B', Item: 'Lids', 'Opening Qty': 50, 'In Qty': 0, 'Out Qty': 0, 'Reorder Level': 10 },
    { _row: 4, SKU: 'C', Item: 'Sleeves', 'Opening Qty': 1, 'In Qty': 0, 'Out Qty': 0, 'Reorder Level': 10, 'Last Alert On': today }
  ];
  const items = c.lowStockItems_(rows, today, c.CONFIG);
  eq(items.length, 1, 'row 4 already alerted today');
  eq(items[0].sku, 'A');
  eq(items[0].shortfall, 6);
  eq(items[0].valueAtRisk, 12);
});

test('05 checkLowStock emails and stamps Last Alert On', () => {
  const sheet = new FakeSheet('Stock', [
    ['SKU', 'Item', 'Opening Qty', 'In Qty', 'Out Qty', 'Reorder Level', 'Unit Cost', 'Last Alert On'],
    ['A', 'Cups', 4, 0, 0, 10, 2, ''],
    ['B', 'Lids', 80, 0, 0, 10, 1, '']
  ]);
  const c = load('05-low-stock-alert.gs', { Stock: sheet });
  const items = c.checkLowStock();
  eq(items.length, 1);
  assert(sheet.values[1][7] instanceof Date, 'alert stamped');
  eq(c.__mail.length, 1);
  eq(c.checkLowStock().length, 0, 'no repeat alert the same day');
});

/* ====================================================== 06 GST reminders */

test('06 gstMilestones_ monthly dates are the 11th and 20th', () => {
  const c = load('06-gst-reminders.gs');
  const ms = c.gstMilestones_(new Date(2026, 9, 26), 'monthly');   // Oct 2026
  eq(ms.length, 2, 'the two upcoming milestones');
  eq(ms[0].code, 'GSTR-1');
  eq(ms[0].due.getDate(), 11);
  eq(ms[0].due.getMonth(), 10, 'November 11 for October period');
  eq(ms[1].code, 'GSTR-3B');
  eq(ms[1].due.getDate(), 20);
  eq(ms[0].period, 'October 2026', 'past due dates are dropped');
});

test('06 quarterly and composition milestone dates', () => {
  const c = load('06-gst-reminders.gs');
  const q = c.gstMilestones_(new Date(2026, 9, 26), 'quarterly');
  eq(q[0].code, 'GSTR-1');
  eq(q[0].due.getDate(), 13);
  const comp = c.gstMilestones_(new Date(2026, 9, 26), 'composition');
  eq(comp[0].code, 'CMP-08');
  eq(comp[0].due.getDate(), 18);
  eq(comp[0].due.getMonth(), 0, 'January after the December quarter end');
});

test('06 milestonesDueToday_ fires inside the reminder window only', () => {
  const c = load('06-gst-reminders.gs');
  eq(c.milestonesDueToday_(new Date(2026, 10, 6), 'monthly', [5, 1, 0]).map(m => m.code), ['GSTR-1']);
  eq(c.milestonesDueToday_(new Date(2026, 10, 19), 'monthly', [5, 1, 0]).map(m => m.code), ['GSTR-3B']);
  eq(c.milestonesDueToday_(new Date(2026, 10, 13), 'monthly', [5, 1, 0]).length, 0);
  eq(c.financialYear_(new Date(2026, 9, 26)), '2026-27');
  eq(c.financialYear_(new Date(2026, 1, 26)), '2025-26');
});

/* ================================================= 07 deadlines → calendar */

test('07 syncAction_ decides create / update / delete / skip', () => {
  const c = load('07-deadlines-to-calendar.gs');
  const today = new Date();
  eq(c.syncAction_({ 'Due Date': day(3), Status: 'Open', 'Calendar Event ID': '' }, today), 'create');
  eq(c.syncAction_({ 'Due Date': day(3), Status: 'Open', 'Calendar Event ID': 'abc' }, today), 'update');
  eq(c.syncAction_({ 'Due Date': day(3), Status: 'Done', 'Calendar Event ID': 'abc' }, today), 'delete');
  eq(c.syncAction_({ 'Due Date': day(3), Status: 'Done', 'Calendar Event ID': '' }, today), 'skip');
  eq(c.syncAction_({ 'Due Date': '', Status: 'Open', 'Calendar Event ID': '' }, today), 'skip');
});

test('07 all-day events end the next day and titles compose', () => {
  const c = load('07-deadlines-to-calendar.gs');
  const opts = c.buildEventOptions_({ 'Due Date': new Date(2026, 9, 26) }, c.CONFIG);
  eq(opts.allDay, true);
  eq(opts.end.getDate(), 27);
  eq(c.eventTitle_({ Title: 'Handover', Client: 'Asha', Type: 'Delivery' }), 'Handover · Asha [Delivery]');
});

/* ======================================================= 08 weekly backup */

test('08 toCsv_ escapes quotes, commas and newlines', () => {
  const c = load('08-weekly-backup.gs');
  eq(c.toCsv_([['a', 'b'], ['x,1', 'he said "hi"'], ['line\nbreak', '']]),
    'a,b\r\n"x,1","he said ""hi"""\r\n"line\nbreak",');
});

test('08 backupTargets_ and foldersToPrune_', () => {
  const c = load('08-weekly-backup.gs');
  eq(c.backupTargets_(['README', 'Invoices', 'Leads'], ['README']), ['Invoices', 'Leads']);
  eq(c.foldersToPrune_(['a', 'b', 'c', 'd'], 2), ['a', 'b']);
  eq(c.foldersToPrune_(['a'], 5), []);
});

/* =================================================== 09 duplicate cleanup */

test('09 normalisePhone_ handles Indian formats', () => {
  const c = load('09-duplicate-cleanup.gs');
  eq(c.normalisePhone_('+91 98765-43210'), '9876543210');
  eq(c.normalisePhone_('098765 43210'), '9876543210');
  eq(c.normalisePhone_('9876543210'), '9876543210');
  eq(c.normalisePhone_(''), '');
  eq(c.normalisePhone_('12345'), '');
});

test('09 findDuplicateGroups_ finds phone and email duplicates only', () => {
  const c = load('09-duplicate-cleanup.gs');
  const rows = [
    { _row: 2, Name: 'Asha', Phone: '9876543210', Email: 'asha@example.com' },
    { _row: 3, Name: 'Asha again', Phone: '+91 98765 43210', Email: 'other@example.com' },
    { _row: 4, Name: 'Ravi', Phone: '9811111111', Email: 'ASHA@example.com' },
    { _row: 5, Name: 'Meera', Phone: '9822222222', Email: 'meera@example.com' }
  ];
  const groups = c.findDuplicateGroups_(rows);
  eq(groups.length, 1, 'one duplicate cluster');
  eq(groups[0].keep, 2);
  eq(groups[0].duplicates.map(d => d.row), [3, 4]);
});

/* =================================================== 10 client onboarding */

test('10 fillTemplate_ replaces known tokens only', () => {
  const c = load('10-client-onboarding.gs');
  const out = c.fillTemplate_('Hi {{CLIENT}} of {{COMPANY}} — {{PLAN}} from {{BUSINESS}} on {{DATE}}. {{UNKNOWN}}',
    { CLIENT: 'Asha', COMPANY: 'Asha Foods', PLAN: 'Retainer', BUSINESS: 'Studio X', DATE: '26 Oct 2026' });
  eq(out, 'Hi Asha of Asha Foods — Retainer from Studio X on 26 Oct 2026. {{UNKNOWN}}');
  eq(c.safeFolderName_('A/B: C'), 'A-B- C');
});

/* ================================================= 11 monthly client report */

test('11 monthKey_ and summariseMonth_ totals', () => {
  const c = load('11-monthly-client-report.gs');
  eq(c.monthKey_(new Date(2026, 8, 15)), '2026-09');
  eq(c.monthLabelFromKey_('2026-09'), 'September 2026');
  const invoices = [
    { 'Client Name': 'Asha', 'Client Email': 'asha@example.com', Amount: 5000, 'Date Issued': new Date(2026, 8, 3), Status: 'Paid', 'Paid On': new Date(2026, 8, 20) },
    { 'Client Name': 'Asha', 'Client Email': 'asha@example.com', Amount: 7000, 'Date Issued': new Date(2026, 8, 25), Status: 'Unpaid', 'Paid On': '' },
    { 'Client Name': 'Ravi', 'Client Email': 'ravi@example.com', Amount: 2000, 'Date Issued': new Date(2026, 7, 25), Status: 'Paid', 'Paid On': new Date(2026, 8, 2) }
  ];
  const deadlines = [
    { Title: 'Logo', Client: 'Asha', 'Due Date': new Date(2026, 8, 10), Status: 'Done' },
    { Title: 'Website', Client: 'Asha', 'Due Date': new Date(2026, 8, 28), Status: 'Open' }
  ];
  const s = c.summariseMonth_(invoices, deadlines, '2026-09', c.CONFIG);
  const asha = s.clients.find(x => x.name === 'Asha');
  const ravi = s.clients.find(x => x.name === 'Ravi');
  eq(asha.invoiced, 12000);
  eq(asha.paid, 5000);
  eq(asha.pending, 7000);
  eq(asha.jobsDone, 1);
  eq(ravi.paid, 2000);
  eq(s.clients.length, 2);
});

test('11 a time-trigger event object is not mistaken for a month key', () => {
  const prev = new Date(); prev.setDate(1); prev.setMonth(prev.getMonth() - 1);
  const sheet = new FakeSheet('Invoices', [
    ['Invoice No', 'Client Name', 'Client Email', 'Amount', 'Date Issued', 'Due Date', 'Status', 'Paid On'],
    ['INV-1', 'Asha', 'asha@example.com', 5000, new Date(prev.getFullYear(), prev.getMonth(), 10),
     new Date(prev.getFullYear(), prev.getMonth(), 20), 'Paid', new Date(prev.getFullYear(), prev.getMonth(), 12)]
  ]);
  const c = load('11-monthly-client-report.gs', { Invoices: sheet });
  const summary = c.sendMonthlyClientReports({ triggerUid: 'abc', authMode: 'FULL' });
  assert(summary && typeof summary.monthKey === 'string', 'month key stays a string');
  assert(/^\d{4}-\d{2}$/.test(summary.monthKey), 'month key looks like YYYY-MM, got ' + summary.monthKey);
  eq(summary.clients.length, 1, 'previous month activity found');
});

/* ==================================================== 12 WhatsApp nudges */

test('12 waNumber_ normalises to international form', () => {
  const c = load('12-whatsapp-reminders.gs');
  eq(c.waNumber_('98765 43210', '91'), '919876543210');
  eq(c.waNumber_('098765-43210', '91'), '919876543210');
  eq(c.waNumber_('+91 98765 43210', '91'), '919876543210');
  eq(c.waNumber_('', '91'), '');
});

test('12 waLink_ encodes the message', () => {
  const c = load('12-whatsapp-reminders.gs');
  const link = c.waLink_('9876543210', 'Hi there, invoice INV-1 is due', '91');
  assert(link.indexOf('https://wa.me/919876543210?text=') === 0, 'link shape');
  assert(link.indexOf('Hi%20there') > -1, 'message encoded');
  eq(c.waLink_('', 'x', '91'), '');
});

test('12 buildWaItems_ picks only due invoices and leads', () => {
  const c = load('12-whatsapp-reminders.gs');
  const today = new Date();
  const items = c.buildWaItems_({
    invoices: [
      { 'Invoice No': 'A', 'Client Name': 'Asha', 'Client Phone': '9876543210', Amount: 5000, 'Due Date': day(-2), Status: 'Unpaid' },
      { 'Invoice No': 'B', 'Client Name': 'Ravi', 'Client Phone': '9876543211', Amount: 900, 'Due Date': day(9), Status: 'Unpaid' },
      { 'Invoice No': 'C', 'Client Name': 'Paid', 'Client Phone': '9876543212', Amount: 900, 'Due Date': day(-9), Status: 'Paid' }
    ],
    leads: [
      { Name: 'Meera', Phone: '9876543213', 'Next Follow-up': day(-1), Status: 'New' },
      { Name: 'Won Lead', Phone: '9876543214', 'Next Follow-up': day(-1), Status: 'Won' }
    ]
  }, today, c.CONFIG);
  eq(items.length, 2, 'one overdue invoice + one lead');
  eq(items.map(i => i.kind).sort(), ['Invoice', 'Lead']);
  const html = c.buildWaHtml_(items, today, c.CONFIG);
  assert(html.indexOf('wa.me') > -1, 'links in html');
  assert(html.indexOf('Open in WhatsApp') > -1, 'button label present');
});

test('12 empty day renders a friendly empty state', () => {
  const c = load('12-whatsapp-reminders.gs');
  const html = c.buildWaHtml_([], new Date(), c.CONFIG);
  assert(html.indexOf('Nobody needs a nudge today') > -1);
});

/* ================================================================ report */

const passed = results.filter(r => r.ok).length;
const failed = results.filter(r => !r.ok);

results.forEach(r => {
  console.log((r.ok ? '  PASS  ' : '  FAIL  ') + r.name + (r.ok ? '' : '\n         ' + r.err));
});
console.log('\n' + passed + '/' + results.length + ' tests passed' + (failed.length ? ' — ' + failed.length + ' FAILED' : ' — all green'));
process.exit(failed.length ? 1 : 0);
