/**
 * 10 · CLIENT ONBOARDING PACK
 * For every client row marked "New", creates a Drive folder, copies your
 * document template into it, fills in the placeholders, and emails the client
 * a welcome note with the folder link. Then marks the row Onboarded.
 *
 * Sheet: "Clients" — Client Name | Email | Phone | Company | Plan |
 *        Onboarded On | Drive Folder ID | Status
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG (paste the template
 *        Doc's ID from its URL), run installClientOnboarding() once.
 *
 * Template placeholders: {{CLIENT}}, {{COMPANY}}, {{PLAN}}, {{DATE}},
 *                        {{BUSINESS}}, {{OWNER}}
 */

var CONFIG = {
  SHEET_NAME: 'Clients',
  BUSINESS_NAME: 'Your Business Name',
  OWNER_NAME: 'Your Name',
  OWNER_EMAIL: 'you@example.com',
  SIGNATURE: '— Your Name, Your Business Name',
  TEMPLATE_DOC_ID: '',                 // optional: a Google Doc to copy per client
  FOLDER_PARENT_NAME: 'Client Files',
  NEW_STATUS: 'New',
  DONE_STATUS: 'Onboarded',
  EMAIL_CLIENT: true
};

/* ---------------------------------------------------------------- helpers */

function sheetByName_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Sheet "' + name + '" not found.');
  return sh;
}

function readTable_(sh) {
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var r = values[i];
    if (r.join('').toString().trim() === '') continue;
    var o = { _row: i + 1 };
    for (var j = 0; j < headers.length; j++) if (headers[j]) o[headers[j]] = r[j];
    rows.push(o);
  }
  return { headers: headers, rows: rows };
}

function dateText_(d) {
  if (!d) return '—';
  var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return d.getDate() + ' ' + m[d.getMonth()] + ' ' + d.getFullYear();
}

/** Pure: replace {{KEY}} tokens in a string. Unknown tokens are left alone. */
function fillTemplate_(text, map) {
  return String(text || '').replace(/\{\{\s*([A-Z0-9_]+)\s*\}\}/g, function (whole, key) {
    return Object.prototype.hasOwnProperty.call(map, key) ? String(map[key]) : whole;
  });
}

function placeholderMap_(client, cfg) {
  var c = cfg || CONFIG;
  return {
    CLIENT: client['Client Name'] || '',
    COMPANY: client['Company'] || client['Client Name'] || '',
    PLAN: client['Plan'] || 'Retainer',
    DATE: dateText_(new Date()),
    BUSINESS: c.BUSINESS_NAME,
    OWNER: c.OWNER_NAME
  };
}

function safeFolderName_(s) {
  return String(s || 'Client').replace(/[\/\\:*?"<>|]/g, '-').slice(0, 90).trim();
}

function welcomeBody_(client, folderUrl, cfg) {
  var c = cfg || CONFIG;
  var lines = [
    'Hi ' + (client['Client Name'] || 'there') + ',',
    '',
    'Welcome aboard — we are glad to be working with ' + (client['Company'] || 'you') + '.',
    '',
    'I have set up a shared folder for everything related to your ' + (client['Plan'] || 'project') + ':'
  ];
  if (folderUrl) lines.push(folderUrl);
  lines.push('');
  lines.push('What happens next:');
  lines.push('1. I add the brief, the timeline and any shared documents to that folder.');
  lines.push('2. You get an update every week on progress.');
  lines.push('3. Anything you need, reply to this email.');
  lines.push('');
  lines.push(c.SIGNATURE);
  return lines.join('\n');
}

/* ------------------------------------------------------------------ main */

function onboardNewClients() {
  var sh = sheetByName_(CONFIG.SHEET_NAME);
  var table = readTable_(sh);
  var headers = table.headers;
  var col = function (n) { return headers.indexOf(n); };
  var iFolder = col('Drive Folder ID'), iOnboarded = col('Onboarded On'), iStatus = col('Status');
  if (iStatus === -1) throw new Error('Add a "Status" column to the Clients sheet.');

  var rootIt = DriveApp.getFoldersByName(CONFIG.FOLDER_PARENT_NAME);
  var root = rootIt.hasNext() ? rootIt.next() : DriveApp.createFolder(CONFIG.FOLDER_PARENT_NAME);

  var done = [];
  table.rows.forEach(function (client) {
    if (String(client['Status'] || '').trim().toLowerCase() !== CONFIG.NEW_STATUS.toLowerCase()) return;

    var name = safeFolderName_((client['Company'] || client['Client Name']) + ' — ' + dateText_(new Date()));
    var folder = root.createFolder(name);
    var folderUrl = folder.getUrl();

    if (CONFIG.TEMPLATE_DOC_ID) {
      try {
        var tpl = DriveApp.getFileById(CONFIG.TEMPLATE_DOC_ID);
        var copy = tpl.makeCopy('Agreement — ' + (client['Company'] || client['Client Name']), folder);
        var doc = DocumentApp.openById(copy.getId());
        var body = doc.getBody();
        var map = placeholderMap_(client, CONFIG);
        var text = body.getText();
        var filled = fillTemplate_(text, map);
        if (filled !== text) {
          body.setText(filled);
          doc.saveAndClose();
        }
      } catch (e) {
        Logger.log('Template copy failed for ' + client['Client Name'] + ': ' + e.message);
      }
    }

    if (iFolder > -1) sh.getRange(client._row, iFolder + 1).setValue(folder.getId());
    if (iOnboarded > -1) sh.getRange(client._row, iOnboarded + 1).setValue(new Date());
    sh.getRange(client._row, iStatus + 1).setValue(CONFIG.DONE_STATUS);

    var email = String(client['Email'] || '').trim();
    if (CONFIG.EMAIL_CLIENT && email.indexOf('@') > -1) {
      MailApp.sendEmail({
        to: email,
        subject: 'Welcome to ' + CONFIG.BUSINESS_NAME + ' — your folder is ready',
        body: welcomeBody_(client, folderUrl, CONFIG),
        name: CONFIG.BUSINESS_NAME
      });
    }
    done.push({ client: client['Client Name'], folder: name, emailed: email.indexOf('@') > -1 });
  });

  Logger.log('Onboarded: ' + done.length);
  return done;
}

function installClientOnboarding() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'onboardNewClients') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('onboardNewClients').timeBased().everyMinutes(30).create();
  Logger.log('30-minute trigger installed for onboardNewClients().');
}
