/**
 * 12 · WHATSAPP CLICK-TO-CHAT LIST
 * Google's terms do not allow a free script to send WhatsApp messages for you,
 * so this does the honest version: each morning it emails you a list of the
 * people who need a nudge today, each with a wa.me link that opens WhatsApp
 * with the message already typed. One tap, you press send.
 *
 * Reads: "Invoices" (unpaid, overdue) and "Leads" (Next Follow-up due).
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG, run
 *        installWhatsAppList() once.
 */

var CONFIG = {
  INVOICES_SHEET: 'Invoices',
  LEADS_SHEET: 'Leads',
  OWNER_EMAIL: 'you@example.com',
  BUSINESS_NAME: 'Your Business Name',
  OWNER_NAME: 'Your Name',
  COUNTRY_CODE: '91',                 // India
  PAID_STATUSES: ['Paid', 'Settled', 'Received'],
  DONE_STATUSES: ['Won', 'Lost', 'Not Interested', 'Converted', 'Closed', 'Client'],
  MAX_ITEMS: 20,
  UPI_ID: ''
};

/* ---------------------------------------------------------------- helpers */

function getSheetIfExists_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return name ? ss.getSheetByName(name) : null;
}

function readTable_(sh) {
  if (!sh) return { headers: [], rows: [] };
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var r = values[i];
    if (r.join('').toString().trim() === '') continue;
    var o = { _row: i + 1 };
    for (var j = 0; j < headers.length; j++) if (headers[j]) o[headers[j]] = r[j];
    rows.push(o);
  }
  return { headers: headers, rows: rows };
}

function toDate_(v) {
  if (!v) return null;
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v.getTime()) ? null : v;
  var d = new Date(v);
  return isNaN(d.getTime()) ? null : d;
}

function startOfDay_(d) { var x = new Date(d.getTime()); x.setHours(0, 0, 0, 0); return x; }

function daysBetween_(from, to) {
  return Math.round((startOfDay_(to).getTime() - startOfDay_(from).getTime()) / 86400000);
}

function money_(n) {
  var v = Number(n) || 0;
  var s = Math.abs(v).toFixed(2).split('.'), whole = s[0], frac = s[1];
  var last3 = whole.slice(-3), rest = whole.slice(0, -3);
  if (rest) rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return (v < 0 ? '-' : '') + '₹' + (rest ? rest + ',' : '') + last3 + '.' + frac;
}

function dateText_(d) {
  if (!d) return '—';
  var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return d.getDate() + ' ' + m[d.getMonth()] + ' ' + d.getFullYear();
}

function statusIn_(status, list) {
  var s = String(status || '').trim().toLowerCase();
  for (var i = 0; i < list.length; i++) if (String(list[i]).toLowerCase() === s) return true;
  return false;
}

function esc_(s) {
  return String(s === undefined || s === null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Digits only, in international form: "098765 43210" -> "919876543210". Pure. */
function waNumber_(phone, countryCode) {
  var digits = String(phone || '').replace(/[^0-9]/g, '');
  if (!digits) return '';
  var cc = String(countryCode || CONFIG.COUNTRY_CODE || '91').replace(/[^0-9]/g, '');
  if (digits.length === 10) return cc + digits;
  if (digits.length === 11 && digits.charAt(0) === '0') return cc + digits.slice(1);
  if (digits.indexOf(cc) === 0 && digits.length >= 11) return digits;
  return digits.length > 10 ? digits : cc + digits;
}

/** wa.me link with the message pre-typed. Pure. */
function waLink_(phone, message, countryCode) {
  var n = waNumber_(phone, countryCode);
  if (!n) return '';
  return 'https://wa.me/' + n + '?text=' + encodeURIComponent(message || '');
}

function invoiceMessage_(inv, cfg) {
  var c = cfg || CONFIG;
  var lines = ['Hello ' + (inv['Client Name'] || '') + ', this is ' + c.OWNER_NAME + ' from ' + c.BUSINESS_NAME + '.'];
  lines.push('A gentle reminder about invoice ' + inv['Invoice No'] + ' for ' + money_(inv['Amount']) +
    ', due ' + dateText_(toDate_(inv['Due Date'])) + '.');
  if (c.UPI_ID) lines.push('UPI: ' + c.UPI_ID);
  lines.push('If it is already paid, please share the reference so I can update my records. Thank you!');
  return lines.join('\n');
}

function leadMessage_(lead, cfg) {
  var c = cfg || CONFIG;
  return ['Hello ' + (lead['Name'] || '') + ', this is ' + c.OWNER_NAME + ' from ' + c.BUSINESS_NAME + '.',
    'Following up on your enquiry' + (lead['Requirement'] ? ' about "' + lead['Requirement'] + '"' : '') + '.',
    'Would a short call this week be useful?'].join('\n');
}

/** Pure: build the day's list of { kind, name, phone, message, link }. */
function buildWaItems_(data, today, cfg) {
  var c = cfg || CONFIG;
  var items = [];

  (data.invoices || []).forEach(function (inv) {
    if (statusIn_(inv['Status'], c.PAID_STATUSES)) return;
    if (statusIn_(inv['Status'], ['Cancelled', 'Void', 'Draft'])) return;
    var due = toDate_(inv['Due Date']);
    if (!due) return;
    if (daysBetween_(today, due) > 0) return;               // not due yet
    if (!waNumber_(inv['Client Phone'] || inv['Phone'] || '', c.COUNTRY_CODE)) return;
    items.push({
      kind: 'Invoice',
      name: inv['Client Name'] || '',
      phone: inv['Client Phone'] || inv['Phone'] || '',
      message: invoiceMessage_(inv, c),
      daysLate: Math.abs(daysBetween_(today, due))
    });
  });

  (data.leads || []).forEach(function (lead) {
    if (statusIn_(lead['Status'], c.DONE_STATUSES)) return;
    var next = toDate_(lead['Next Follow-up']);
    if (!next || daysBetween_(today, next) > 0) return;
    if (!waNumber_(lead['Phone'], c.COUNTRY_CODE)) return;
    items.push({
      kind: 'Lead',
      name: lead['Name'] || '',
      phone: lead['Phone'],
      message: leadMessage_(lead, c),
      daysLate: 0
    });
  });

  items.forEach(function (i) { i.link = waLink_(i.phone, i.message, c.COUNTRY_CODE); });
  return items.slice(0, c.MAX_ITEMS);
}

/** Pure: the HTML email with one tappable link per person. */
function buildWaHtml_(items, today, cfg) {
  var c = cfg || CONFIG;
  var h = ['<!DOCTYPE html><html><body style="margin:0;background:#0a1628;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;">',
    '<div style="max-width:620px;margin:0 auto;padding:22px;color:#e2e8f0;">',
    '<h1 style="color:#f5c542;font-size:19px;margin:0 0 4px;">WhatsApp nudges — ' + esc_(dateText_(today)) + '</h1>',
    '<p style="color:#9fb0c7;font-size:13px;margin:0 0 18px;">Tap a link, WhatsApp opens with the message typed. You press send.</p>'];

  if (!items.length) {
    h.push('<div style="background:#0f1e36;border:1px solid #1e3557;border-radius:10px;padding:16px;font-size:13px;color:#9fb0c7;">Nobody needs a nudge today.</div>');
  }

  items.forEach(function (i) {
    h.push('<div style="background:#0f1e36;border:1px solid #1e3557;border-radius:10px;padding:13px 15px;margin:0 0 10px;">');
    h.push('<div style="font-size:14px;font-weight:700;">' + esc_(i.name) + ' <span style="color:#9fb0c7;font-weight:400;font-size:12px;">· ' + esc_(i.kind) + (i.daysLate ? ' · ' + i.daysLate + ' day(s) late' : '') + '</span></div>');
    h.push('<div style="color:#9fb0c7;font-size:12px;margin:3px 0 8px;white-space:pre-wrap;">' + esc_(i.message) + '</div>');
    h.push('<a href="' + esc_(i.link) + '" style="display:inline-block;background:linear-gradient(135deg,#f5c542,#e8a82c);color:#0a1628;font-weight:700;font-size:13px;padding:8px 14px;border-radius:8px;text-decoration:none;">Open in WhatsApp →</a>');
    h.push('</div>');
  });

  h.push('<p style="color:#9fb0c7;font-size:11px;margin:14px 0 0;">Sheets Autopilot · ' + esc_(c.BUSINESS_NAME) + ' · these links open your own WhatsApp; nothing is sent automatically.</p>');
  h.push('</div></body></html>');
  return h.join('');
}

/* ------------------------------------------------------------------ main */

function sendWhatsAppList() {
  var data = {
    invoices: readTable_(getSheetIfExists_(CONFIG.INVOICES_SHEET)).rows,
    leads: readTable_(getSheetIfExists_(CONFIG.LEADS_SHEET)).rows
  };
  var today = new Date();
  var items = buildWaItems_(data, today, CONFIG);
  MailApp.sendEmail({
    to: CONFIG.OWNER_EMAIL,
    subject: 'WhatsApp nudges today: ' + items.length,
    htmlBody: buildWaHtml_(items, today, CONFIG),
    body: items.length
      ? items.map(function (i) { return i.name + ' (' + i.kind + ') — ' + i.link; }).join('\n')
      : 'Nobody needs a nudge today.'
  });
  Logger.log('WhatsApp list: ' + items.length);
  return items;
}

function installWhatsAppList() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'sendWhatsAppList') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('sendWhatsAppList').timeBased().atHour(9).everyDays(1).create();
  Logger.log('Daily 9am trigger installed for sendWhatsAppList().');
}
