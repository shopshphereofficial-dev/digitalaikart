/**
 * 11 · MONTHLY CLIENT REPORT
 * On the 1st of each month, every active client gets a short, factual summary
 * of the month just gone: what was invoiced, what was paid, what is pending,
 * and how many jobs were completed. You get a copy of the whole run.
 *
 * Sheets: "Invoices" (Invoice No | Client Name | Client Email | Amount |
 *         Date Issued | Due Date | Status | Paid On) and
 *         "Deadlines" (Title | Client | Due Date | Type | Status)
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG, run
 *        installMonthlyClientReport() once. Run sendMonthlyClientReports()
 *        by hand first — it reports on the month you choose in CONFIG.
 */

var CONFIG = {
  INVOICES_SHEET: 'Invoices',
  DEADLINES_SHEET: 'Deadlines',
  BUSINESS_NAME: 'Your Business Name',
  OWNER_EMAIL: 'you@example.com',
  SIGNATURE: '— Your Name, Your Business Name',
  REPORT_MONTH_OFFSET: -1,          // -1 = last month
  EMAIL_CLIENTS: true,
  EMAIL_OWNER_COPY: true,
  PAID_STATUSES: ['Paid', 'Settled', 'Received'],
  DONE_STATUSES: ['Done', 'Completed']
};

/* ---------------------------------------------------------------- helpers */

function getSheetIfExists_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return name ? ss.getSheetByName(name) : null;
}

function readTable_(sh) {
  if (!sh) return { headers: [], rows: [] };
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var r = values[i];
    if (r.join('').toString().trim() === '') continue;
    var o = { _row: i + 1 };
    for (var j = 0; j < headers.length; j++) if (headers[j]) o[headers[j]] = r[j];
    rows.push(o);
  }
  return { headers: headers, rows: rows };
}

function toDate_(v) {
  if (!v) return null;
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v.getTime()) ? null : v;
  var d = new Date(v);
  return isNaN(d.getTime()) ? null : d;
}

function money_(n) {
  var v = Number(n) || 0;
  var s = Math.abs(v).toFixed(2).split('.'), whole = s[0], frac = s[1];
  var last3 = whole.slice(-3), rest = whole.slice(0, -3);
  if (rest) rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return (v < 0 ? '-' : '') + '₹' + (rest ? rest + ',' : '') + last3 + '.' + frac;
}

function dateText_(d) {
  if (!d) return '—';
  var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return d.getDate() + ' ' + m[d.getMonth()] + ' ' + d.getFullYear();
}

function statusIn_(status, list) {
  var s = String(status || '').trim().toLowerCase();
  for (var i = 0; i < list.length; i++) if (String(list[i]).toLowerCase() === s) return true;
  return false;
}

/** "2026-09" for a date. Pure. */
function monthKey_(d) {
  var x = toDate_(d);
  if (!x) return '';
  var m = x.getMonth() + 1;
  return x.getFullYear() + '-' + (m < 10 ? '0' + m : String(m));
}

function monthLabelFromKey_(key) {
  var parts = String(key || '').split('-');
  if (parts.length !== 2) return key;
  var m = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
    'August', 'September', 'October', 'November', 'December'];
  return m[Number(parts[1]) - 1] + ' ' + parts[0];
}

function shiftMonth_(d, offset) {
  var x = new Date(d.getFullYear(), d.getMonth() + (offset || 0), 1);
  return x;
}

/**
 * Pure: build per-client totals for one month key.
 * Returns { monthKey, clients: [{ name, email, invoiced, paid, pending,
 *   paidCount, pendingCount, jobsDone, jobTitles }] }
 */
function summariseMonth_(invoices, deadlines, key, cfg) {
  var c = cfg || CONFIG;
  var byClient = {};

  function bucket(name, email) {
    var k = String(name || 'Unnamed client').trim();
    if (!byClient[k]) byClient[k] = { name: k, email: '', invoiced: 0, paid: 0, pending: 0, paidCount: 0, pendingCount: 0, jobsDone: 0, jobTitles: [] };
    if (email && String(email).indexOf('@') > -1) byClient[k].email = String(email).trim();
    return byClient[k];
  }

  (invoices || []).forEach(function (inv) {
    var issued = monthKey_(inv['Date Issued']);
    var paidOn = monthKey_(inv['Paid On']);
    if (issued !== key && paidOn !== key) return;
    var b = bucket(inv['Client Name'], inv['Client Email']);
    var amt = Number(inv['Amount']) || 0;
    if (issued === key) b.invoiced += amt;
    if (statusIn_(inv['Status'], c.PAID_STATUSES)) {
      if (paidOn === key || (issued === key && !paidOn)) { b.paid += amt; b.paidCount++; }
    } else {
      if (issued === key) { b.pending += amt; b.pendingCount++; }
    }
  });

  (deadlines || []).forEach(function (d) {
    if (monthKey_(d['Due Date']) !== key) return;
    if (!statusIn_(d['Status'], c.DONE_STATUSES)) return;
    var b = bucket(d['Client'], '');
    b.jobsDone++;
    if (d['Title']) b.jobTitles.push(String(d['Title']));
  });

  var clients = Object.keys(byClient).map(function (k) { return byClient[k]; })
    .filter(function (b) { return b.invoiced || b.paid || b.jobsDone || b.pending; })
    .sort(function (a, b) { return b.invoiced - a.invoiced; });

  return { monthKey: key, clients: clients };
}

function clientReportBody_(summary, client, cfg) {
  var c = cfg || CONFIG;
  var lines = [
    'Hi ' + client.name + ',',
    '',
    'Here is your summary for ' + monthLabelFromKey_(summary.monthKey) + '.',
    '',
    'Invoiced  : ' + money_(client.invoiced) + ' (' + (client.paidCount + client.pendingCount) + ' invoice(s))',
    'Paid      : ' + money_(client.paid),
    'Pending   : ' + money_(client.pending) + (client.pendingCount ? ' (' + client.pendingCount + ' invoice(s) awaiting payment)' : ''),
    'Jobs done : ' + client.jobsDone
  ];
  if (client.jobTitles.length) {
    lines.push('');
    lines.push('Completed work:');
    client.jobTitles.slice(0, 12).forEach(function (t) { lines.push('  • ' + t); });
    if (client.jobTitles.length > 12) lines.push('  • …and ' + (client.jobTitles.length - 12) + ' more');
  }
  lines.push('');
  lines.push('Any line here you want explained, reply and I will send the detail.');
  lines.push('');
  lines.push(c.SIGNATURE);
  return lines.join('\n');
}

/* ------------------------------------------------------------------ main */

function sendMonthlyClientReports(overrideMonthKey) {
  // A time trigger passes an event object, so only accept a real "YYYY-MM" string.
  var key = (typeof overrideMonthKey === 'string' && /^\d{4}-\d{2}$/.test(overrideMonthKey))
    ? overrideMonthKey
    : monthKey_(shiftMonth_(new Date(), CONFIG.REPORT_MONTH_OFFSET));
  var invoices = readTable_(getSheetIfExists_(CONFIG.INVOICES_SHEET)).rows;
  var deadlines = readTable_(getSheetIfExists_(CONFIG.DEADLINES_SHEET)).rows;
  var summary = summariseMonth_(invoices, deadlines, key, CONFIG);

  if (!summary.clients.length) {
    Logger.log('No activity in ' + key + ' — nothing sent.');
    return summary;
  }

  var sentTo = [];
  summary.clients.forEach(function (client) {
    if (CONFIG.EMAIL_CLIENTS && client.email) {
      MailApp.sendEmail({
        to: client.email,
        subject: 'Your ' + monthLabelFromKey_(key) + ' summary — ' + CONFIG.BUSINESS_NAME,
        body: clientReportBody_(summary, client, CONFIG),
        name: CONFIG.BUSINESS_NAME
      });
      sentTo.push(client.name);
    }
  });

  if (CONFIG.EMAIL_OWNER_COPY) {
    var lines = ['Client reports for ' + monthLabelFromKey_(key), '', 'Clients with activity: ' + summary.clients.length, ''];
    var totalInv = 0, totalPaid = 0, totalPend = 0;
    summary.clients.forEach(function (cl) {
      totalInv += cl.invoiced; totalPaid += cl.paid; totalPend += cl.pending;
      lines.push('• ' + cl.name + ' — invoiced ' + money_(cl.invoiced) + ', paid ' + money_(cl.paid) +
        ', pending ' + money_(cl.pending) + ', jobs ' + cl.jobsDone + (cl.email ? '' : ' (no email on file)'));
    });
    lines.push('', 'Totals: invoiced ' + money_(totalInv) + ' · paid ' + money_(totalPaid) + ' · pending ' + money_(totalPend));
    lines.push('', 'Emailed to: ' + (sentTo.length ? sentTo.join(', ') : 'nobody (EMAIL_CLIENTS off or no addresses)'));
    MailApp.sendEmail({ to: CONFIG.OWNER_EMAIL, subject: 'Client reports sent — ' + monthLabelFromKey_(key), body: lines.join('\n') });
  }

  Logger.log('Client reports: ' + summary.clients.length + ' clients, emailed ' + sentTo.length);
  return summary;
}

function installMonthlyClientReport() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'sendMonthlyClientReports') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('sendMonthlyClientReports').timeBased().onMonthDay(1).atHour(9).create();
  Logger.log('Monthly (1st, 9am) trigger installed for sendMonthlyClientReports().');
}
