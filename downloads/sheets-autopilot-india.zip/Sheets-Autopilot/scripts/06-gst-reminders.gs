/**
 * 06 · GST FILING REMINDER
 * Nudges you before each GST milestone with a short checklist, so the 11th and
 * the 20th never sneak up. Works for monthly filers, quarterly (QRMP) filers
 * and composition dealers.
 *
 * Nothing is filed or calculated — this is a calendar with a checklist, based
 * on the statutory due dates you confirm in CONFIG. Always check the GST
 * portal for your own filing dates and any extension.
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG, run
 *        installGstReminders() once.
 */

var CONFIG = {
  OWNER_EMAIL: 'you@example.com',
  BUSINESS_NAME: 'Your Business Name',
  GSTIN: '',                                  // optional, printed in the email
  FILING_FREQUENCY: 'monthly',                // 'monthly' | 'quarterly' | 'composition'
  REMIND_DAYS_BEFORE: [5, 1, 0],              // how far ahead to email
  FY_START_MONTH: 4                           // April
};

/* ---------------------------------------------------------------- helpers */

function pad_(n, w) { var s = String(n); while (s.length < w) s = '0' + s; return s; }

function toDate_(v) {
  if (!v) return null;
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v.getTime()) ? null : v;
  var d = new Date(v);
  return isNaN(d.getTime()) ? null : d;
}

function startOfDay_(d) { var x = new Date(d.getTime()); x.setHours(0, 0, 0, 0); return x; }

function daysBetween_(from, to) {
  return Math.round((startOfDay_(to).getTime() - startOfDay_(from).getTime()) / 86400000);
}

function dateText_(d) {
  if (!d) return '—';
  var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return d.getDate() + ' ' + m[d.getMonth()] + ' ' + d.getFullYear();
}

/** Indian financial year label for a date: 2026-04-01 -> "2026-27". */
function financialYear_(d) {
  var y = d.getFullYear();
  var startYear = d.getMonth() + 1 >= CONFIG.FY_START_MONTH ? y : y - 1;
  return startYear + '-' + pad_((startYear + 1) % 100, 2);
}

function monthLabel_(d) {
  var m = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
    'August', 'September', 'October', 'November', 'December'];
  return m[d.getMonth()] + ' ' + d.getFullYear();
}

/**
 * Upcoming milestones: the current return period and the next one, sorted by
 * due date. Pure — every date is computed, nothing is hard-coded per year.
 * Statutory dates can move; the email always tells you to confirm on the portal.
 */
function gstMilestones_(today, frequency) {
  var freq = frequency || CONFIG.FILING_FREQUENCY;
  var out = [];
  var y = today.getFullYear(), m = today.getMonth();

  for (var k = 0; k <= 1; k++) {
    if (freq === 'composition') {
      // Quarter containing (today + 3k months); CMP-08 is due on the 18th of the next month.
      var qStartMonth = Math.floor((m + 3 * k) / 3) * 3;
      var qStart = new Date(y, qStartMonth, 1);
      var qEnd = new Date(qStart.getFullYear(), qStart.getMonth() + 2, 1);
      out.push({
        code: 'CMP-08',
        name: 'Composition quarterly statement and tax payment (CMP-08)',
        period: 'Quarter ' + monthLabel_(qStart) + ' – ' + monthLabel_(qEnd),
        due: new Date(qEnd.getFullYear(), qEnd.getMonth() + 1, 18)
      });
    } else if (freq === 'quarterly') {
      // QRMP: GSTR-1 on the 13th and GSTR-3B on the 24th, after the quarter ends.
      var qStartMonth2 = Math.floor((m + 3 * k) / 3) * 3;
      var qStart2 = new Date(y, qStartMonth2, 1);
      var qEnd2 = new Date(qStart2.getFullYear(), qStart2.getMonth() + 2, 1);
      var afterMonth = new Date(qEnd2.getFullYear(), qEnd2.getMonth() + 1, 1);
      var periodLabel = 'Quarter ' + monthLabel_(qStart2) + ' – ' + monthLabel_(qEnd2);
      out.push({ code: 'GSTR-1', name: 'Quarterly outward supplies (GSTR-1, QRMP)', period: periodLabel, due: new Date(afterMonth.getFullYear(), afterMonth.getMonth(), 13) });
      out.push({ code: 'GSTR-3B', name: 'Quarterly summary return and tax payment (GSTR-3B, QRMP)', period: periodLabel, due: new Date(afterMonth.getFullYear(), afterMonth.getMonth(), 24) });
    } else {
      // Monthly: GSTR-1 on the 11th and GSTR-3B on the 20th, for the previous month.
      var period = new Date(y, m + k - 1, 1);
      var dueMonth = new Date(y, m + k, 1);
      out.push({ code: 'GSTR-1', name: 'Outward supplies return (GSTR-1)', period: monthLabel_(period), due: new Date(dueMonth.getFullYear(), dueMonth.getMonth(), 11) });
      out.push({ code: 'GSTR-3B', name: 'Summary return and tax payment (GSTR-3B)', period: monthLabel_(period), due: new Date(dueMonth.getFullYear(), dueMonth.getMonth(), 20) });
    }
  }

  out = out.filter(function (ms) { return daysBetween_(today, ms.due) >= 0; });
  out.sort(function (a, b) { return a.due - b.due; });
  return out;
}

/** Pure: milestones that should be emailed today, given the lead-time list. */
function milestonesDueToday_(today, frequency, remindDays) {
  var days = remindDays || CONFIG.REMIND_DAYS_BEFORE;
  return gstMilestones_(today, frequency).filter(function (ms) {
    var left = daysBetween_(today, ms.due);
    return days.indexOf(left) > -1;
  }).map(function (ms) {
    ms.daysLeft = daysBetween_(today, ms.due);
    return ms;
  });
}

var GST_CHECKLIST = [
  'Download the sales register for the period (invoices issued, credit notes).',
  'Download the purchase register and match it with GSTR-2B on the portal.',
  'Reconcile any mismatch before you claim input tax credit.',
  'Check RCM (reverse charge) entries — rent from an unregistered landlord, imports, legal fees.',
  'Confirm e-invoice and e-way bill details for large B2B invoices.',
  'File the return on gst.gov.in and save the ARN acknowledgement.',
  'Pay the tax and note the CIN/challan number for your records.'
];

function gstEmailBody_(ms, cfg) {
  var c = cfg || CONFIG;
  var lines = [];
  lines.push('GST reminder — ' + ms.code + (ms.daysLeft > 0 ? ' due in ' + ms.daysLeft + ' day(s)' : (ms.daysLeft === 0 ? ' is due TODAY' : ' overdue')));
  lines.push('');
  lines.push('Return  : ' + ms.name);
  lines.push('Period  : ' + ms.period);
  lines.push('Due     : ' + dateText_(ms.due));
  if (c.GSTIN) lines.push('GSTIN   : ' + c.GSTIN);
  lines.push('');
  lines.push('Checklist:');
  GST_CHECKLIST.forEach(function (x, i) { lines.push('  ' + (i + 1) + '. ' + x); });
  lines.push('');
  lines.push('This reminder is based on the statutory due dates set in CONFIG. Always confirm the date and any extension on the GST portal before filing.');
  lines.push('');
  lines.push('— ' + c.BUSINESS_NAME + ' · Sheets Autopilot');
  return lines.join('\n');
}

/* ------------------------------------------------------------------ main */

function sendGstReminders() {
  var today = new Date();
  var due = milestonesDueToday_(today, CONFIG.FILING_FREQUENCY, CONFIG.REMIND_DAYS_BEFORE);
  if (!due.length) {
    Logger.log('No GST milestone inside the reminder window today.');
    return [];
  }
  due.forEach(function (ms) {
    MailApp.sendEmail({
      to: CONFIG.OWNER_EMAIL,
      subject: 'GST ' + ms.code + ' — ' + (ms.daysLeft === 0 ? 'due today' : ms.daysLeft + ' day(s) left') + ' · ' + ms.period,
      body: gstEmailBody_(ms, CONFIG)
    });
  });
  Logger.log('GST reminders sent: ' + due.length);
  return due;
}

function installGstReminders() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'sendGstReminders') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('sendGstReminders').timeBased().atHour(8).everyDays(1).create();
  Logger.log('Daily 8am trigger installed for sendGstReminders().');
}
