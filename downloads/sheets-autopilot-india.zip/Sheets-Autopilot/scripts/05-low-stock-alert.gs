/**
 * 05 · LOW-STOCK ALERT
 * Watches the Stock sheet and emails you once a day when anything drops to or
 * below its reorder level. Alerts once per item per day — no inbox spam.
 *
 * Sheet: "Stock" — SKU | Item | Unit | Opening Qty | In Qty | Out Qty |
 *        Reorder Level | Unit Cost | Last Alert On
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG, run
 *        installLowStockAlert() once.
 */

var CONFIG = {
  SHEET_NAME: 'Stock',
  OWNER_EMAIL: 'you@example.com',
  BUSINESS_NAME: 'Your Business Name',
  ALERT_ON_EQUAL: true,          // true = alert at exactly the reorder level too
  INCLUDE_VALUE_AT_RISK: true,   // qty below reorder x unit cost
  ONCE_PER_DAY: true
};

/* ---------------------------------------------------------------- helpers */

function sheetByName_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Sheet "' + name + '" not found.');
  return sh;
}

function readTable_(sh) {
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var r = values[i];
    if (r.join('').toString().trim() === '') continue;
    var o = { _row: i + 1 };
    for (var j = 0; j < headers.length; j++) if (headers[j]) o[headers[j]] = r[j];
    rows.push(o);
  }
  return { headers: headers, rows: rows };
}

function toDate_(v) {
  if (!v) return null;
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v.getTime()) ? null : v;
  var d = new Date(v);
  return isNaN(d.getTime()) ? null : d;
}

function sameDay_(a, b) {
  if (!a || !b) return false;
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function money_(n) {
  var v = Number(n) || 0;
  var s = Math.abs(v).toFixed(2).split('.'), whole = s[0], frac = s[1];
  var last3 = whole.slice(-3), rest = whole.slice(0, -3);
  if (rest) rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return (v < 0 ? '-' : '') + '₹' + (rest ? rest + ',' : '') + last3 + '.' + frac;
}

/** Current quantity: explicit column if present, else opening + in - out. */
function currentQty_(item) {
  if (item['Current Qty'] !== undefined && String(item['Current Qty']).trim() !== '') {
    var q = Number(item['Current Qty']);
    if (!isNaN(q)) return q;
  }
  var opening = Number(item['Opening Qty']) || 0;
  var inQty = Number(item['In Qty']) || 0;
  var outQty = Number(item['Out Qty']) || 0;
  return opening + inQty - outQty;
}

/** Pure: which stock rows need an alert right now? */
function lowStockItems_(rows, today, cfg) {
  var c = cfg || CONFIG;
  var out = [];
  (rows || []).forEach(function (item) {
    var qty = currentQty_(item);
    var reorder = Number(item['Reorder Level']);
    if (isNaN(qty) || isNaN(reorder) || reorder <= 0) return;
    var isLow = c.ALERT_ON_EQUAL ? qty <= reorder : qty < reorder;
    if (!isLow) return;
    if (c.ONCE_PER_DAY && sameDay_(toDate_(item['Last Alert On']), today)) return;
    out.push({
      row: item._row,
      sku: item['SKU'],
      item: item['Item'],
      qty: qty,
      reorder: reorder,
      shortfall: Math.max(0, reorder - qty),
      valueAtRisk: Math.max(0, reorder - qty) * (Number(item['Unit Cost']) || 0)
    });
  });
  return out;
}

function alertBody_(items, cfg) {
  var c = cfg || CONFIG;
  var lines = ['Low stock at ' + c.BUSINESS_NAME, ''];
  items.forEach(function (i) {
    lines.push('• ' + (i.item || i.sku) + ' (' + (i.sku || 'no SKU') + ') — in stock ' + i.qty +
      ', reorder level ' + i.reorder + ', short by ' + i.shortfall +
      (c.INCLUDE_VALUE_AT_RISK ? ', restock value ' + money_(i.valueAtRisk) : ''));
  });
  lines.push('');
  lines.push('Open the Stock sheet to raise a purchase order.');
  return lines.join('\n');
}

/* ------------------------------------------------------------------ main */

function checkLowStock() {
  var sh = sheetByName_(CONFIG.SHEET_NAME);
  var table = readTable_(sh);
  var headers = table.headers;
  var iAlert = headers.indexOf('Last Alert On');
  var today = new Date();
  var items = lowStockItems_(table.rows, today, CONFIG);

  if (!items.length) {
    Logger.log('Low stock: none.');
    return [];
  }

  MailApp.sendEmail({
    to: CONFIG.OWNER_EMAIL,
    subject: 'Low stock: ' + items.length + ' item(s) to reorder',
    body: alertBody_(items, CONFIG)
  });

  if (iAlert > -1) {
    items.forEach(function (i) { sh.getRange(i.row, iAlert + 1).setValue(today); });
  }
  Logger.log('Low stock alerts: ' + items.length);
  return items;
}

function installLowStockAlert() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'checkLowStock') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('checkLowStock').timeBased().atHour(9).everyDays(1).create();
  Logger.log('Daily 9am trigger installed for checkLowStock().');
}
