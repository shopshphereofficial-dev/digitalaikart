/**
 * 08 · WEEKLY DRIVE BACKUP
 * Every Sunday night, each sheet in the workbook is exported as a CSV into a
 * dated folder in your Drive. Old backups are pruned so the folder never
 * grows without limit.
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG, run
 *        installWeeklyBackup() once. Approve the Drive permission.
 */

var CONFIG = {
  BACKUP_ROOT_NAME: 'Sheet Backups',
  KEEP_FOLDERS: 8,                 // 8 weekly folders ≈ two months
  OWNER_EMAIL: 'you@example.com',
  SKIP_SHEETS: ['README', 'Start Here'],
  EMAIL_SUMMARY: true
};

/* ---------------------------------------------------------------- helpers */

function pad_(n, w) { var s = String(n); while (s.length < w) s = '0' + s; return s; }

function stamp_(d) {
  return d.getFullYear() + '-' + pad_(d.getMonth() + 1, 2) + '-' + pad_(d.getDate(), 2) +
    '_' + pad_(d.getHours(), 2) + pad_(d.getMinutes(), 2);
}

function csvEscape_(v) {
  var s = (v === null || v === undefined) ? '' : String(v);
  if (/[",\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}

/** Pure: 2D values -> CSV text. Tested directly. */
function toCsv_(values) {
  return (values || []).map(function (row) {
    return row.map(csvEscape_).join(',');
  }).join('\r\n');
}

/** Pure: which sheet names to back up. */
function backupTargets_(allNames, skipList) {
  var skip = (skipList || CONFIG.SKIP_SHEETS).map(function (s) { return String(s).toLowerCase(); });
  return (allNames || []).filter(function (n) {
    return skip.indexOf(String(n).trim().toLowerCase()) === -1;
  });
}

/** Pure: which existing folders to delete, given a sorted list (oldest first). */
function foldersToPrune_(folderNames, keep) {
  var k = Math.max(0, Number(keep) || 0);
  if (folderNames.length <= k) return [];
  return folderNames.slice(0, folderNames.length - k);
}

/* ------------------------------------------------------------------ main */

function runWeeklyBackup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var names = ss.getSheets().map(function (s) { return s.getName(); });
  var targets = backupTargets_(names, CONFIG.SKIP_SHEETS);

  var rootIt = DriveApp.getFoldersByName(CONFIG.BACKUP_ROOT_NAME);
  var root = rootIt.hasNext() ? rootIt.next() : DriveApp.createFolder(CONFIG.BACKUP_ROOT_NAME);

  var now = new Date();
  var folder = root.createFolder(stamp_(now));
  var files = [];

  targets.forEach(function (name) {
    var sh = ss.getSheetByName(name);
    var values = sh.getDataRange().getValues();
    var csv = toCsv_(values);
    var file = folder.createFile(Utilities.newBlob(csv, 'text/csv', name.replace(/[\/\\]/g, '-') + '.csv'));
    files.push({ sheet: name, rows: Math.max(0, values.length - 1), name: file.getName() });
  });

  // Prune old folders
  var all = [];
  var it = root.getFolders();
  while (it.hasNext()) all.push(it.next());
  all.sort(function (a, b) { return a.getName() < b.getName() ? -1 : 1; });
  var prune = foldersToPrune_(all.map(function (f) { return f.getName(); }), CONFIG.KEEP_FOLDERS);
  prune.forEach(function (name) {
    var pit = root.getFoldersByName(name);
    while (pit.hasNext()) pit.next().setTrashed(true);
  });

  var totalRows = files.reduce(function (a, f) { return a + f.rows; }, 0);
  if (CONFIG.EMAIL_SUMMARY) {
    var lines = ['Backup complete — ' + stamp_(now), '',
      'Folder: ' + CONFIG.BACKUP_ROOT_NAME + '/' + stamp_(now),
      'Sheets backed up: ' + files.length + ' (' + totalRows + ' data rows)', ''];
    files.forEach(function (f) { lines.push('• ' + f.name + ' — ' + f.rows + ' rows'); });
    if (prune.length) lines.push('', 'Removed ' + prune.length + ' old backup folder(s): ' + prune.join(', '));
    MailApp.sendEmail({ to: CONFIG.OWNER_EMAIL, subject: 'Backup done: ' + files.length + ' sheets', body: lines.join('\n') });
  }
  Logger.log('Backup: ' + files.length + ' files, pruned ' + prune.length);
  return { folder: stamp_(now), files: files, pruned: prune };
}

function installWeeklyBackup() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'runWeeklyBackup') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('runWeeklyBackup').timeBased().onWeekDay(ScriptApp.WeekDay.SUNDAY).atHour(22).create();
  Logger.log('Sunday 10pm trigger installed for runWeeklyBackup().');
}
