/**
 * 09 · DUPLICATE LEAD CLEANUP
 * Finds leads that share a phone number or email, keeps the earliest record,
 * and flags the rest in a "Duplicate Of" column instead of deleting anything.
 * Run it whenever the sheet starts feeling untrustworthy.
 *
 * Sheet: "Leads" — Date | Name | Phone | Email | ... | Duplicate Of
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG, then run
 *        findDuplicateLeads() from the editor. Nothing is deleted, ever.
 */

var CONFIG = {
  SHEET_NAME: 'Leads',
  DUPLICATE_COLUMN: 'Duplicate Of',
  REPORT_TO_OWNER: true,
  OWNER_EMAIL: 'you@example.com'
};

/* ---------------------------------------------------------------- helpers */

function sheetByName_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Sheet "' + name + '" not found.');
  return sh;
}

function readTable_(sh) {
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var r = values[i];
    if (r.join('').toString().trim() === '') continue;
    var o = { _row: i + 1 };
    for (var j = 0; j < headers.length; j++) if (headers[j]) o[headers[j]] = r[j];
    rows.push(o);
  }
  return { headers: headers, rows: rows };
}

/** +91 98765-43210 / 098765 43210 / 9876543210 -> "9876543210". Pure. */
function normalisePhone_(raw) {
  var digits = String(raw || '').replace(/[^0-9]/g, '');
  if (!digits) return '';
  if (digits.length > 10) digits = digits.slice(-10);
  return digits.length === 10 ? digits : '';
}

function normaliseEmail_(raw) {
  return String(raw || '').trim().toLowerCase();
}

/**
 * Pure: group duplicate rows. Returns an array of
 * { key, keep: rowNumber, duplicates: [{ row, name, phone, email }] }.
 * Rows are compared on phone first, then email.
 */
function findDuplicateGroups_(rows) {
  var groups = [];
  var byKey = {};

  (rows || []).forEach(function (r) {
    var phone = normalisePhone_(r['Phone']);
    var email = normaliseEmail_(r['Email']);
    var keys = [];
    if (phone) keys.push('p:' + phone);
    if (email && email.indexOf('@') > -1) keys.push('e:' + email);

    var hit = null;
    for (var i = 0; i < keys.length; i++) {
      if (byKey[keys[i]]) { hit = byKey[keys[i]]; break; }
    }
    if (!hit) {
      hit = { key: keys[0] || ('r:' + r._row), keep: r._row, duplicates: [], _rows: [r] };
      groups.push(hit);
    } else {
      hit.duplicates.push({ row: r._row, name: r['Name'], phone: r['Phone'], email: r['Email'] });
      hit._rows.push(r);
    }
    keys.forEach(function (k) { byKey[k] = hit; });
  });

  return groups.filter(function (g) { return g.duplicates.length > 0; });
}

/* ------------------------------------------------------------------ main */

function findDuplicateLeads() {
  var sh = sheetByName_(CONFIG.SHEET_NAME);
  var table = readTable_(sh);
  var headers = table.headers;
  var iDup = headers.indexOf(CONFIG.DUPLICATE_COLUMN);
  if (iDup === -1) {
    // add the column if it is missing
    sh.getRange(1, headers.length + 1).setValue(CONFIG.DUPLICATE_COLUMN);
    iDup = headers.length;
  }

  var groups = findDuplicateGroups_(table.rows);
  var flagged = 0;
  groups.forEach(function (g) {
    g.duplicates.forEach(function (d) {
      sh.getRange(d.row, iDup + 1).setValue('Duplicate of row ' + g.keep);
      flagged++;
    });
  });

  if (CONFIG.REPORT_TO_OWNER && flagged) {
    var lines = ['Duplicate leads found: ' + groups.length + ' group(s), ' + flagged + ' row(s) flagged.', ''];
    groups.forEach(function (g) {
      var keepRow = g._rows[0];
      lines.push('• Keep row ' + g.keep + ' — ' + (keepRow['Name'] || '') + ' (' + (keepRow['Phone'] || keepRow['Email'] || '') + ')');
      g.duplicates.forEach(function (d) {
        lines.push('    duplicate: row ' + d.row + ' — ' + (d.name || '') + ' (' + (d.phone || d.email || '') + ')');
      });
    });
    lines.push('', 'Nothing was deleted. Filter the "' + CONFIG.DUPLICATE_COLUMN + '" column to review, then delete by hand if you agree.');
    MailApp.sendEmail({ to: CONFIG.OWNER_EMAIL, subject: 'Duplicate leads: ' + flagged + ' flagged', body: lines.join('\n') });
  }

  Logger.log('Groups: ' + groups.length + ' | flagged: ' + flagged);
  return { groups: groups.length, flagged: flagged };
}
