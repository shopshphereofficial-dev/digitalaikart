/**
 * 03 · LEAD FOLLOW-UP SEQUENCE
 * Every new lead gets an instant acknowledgement, then three follow-ups
 * (day 3, day 7, day 14). The sequence stops the moment you change Status
 * to Won / Lost / Not Interested.
 *
 * Sheet: "Leads" — Date | Name | Phone | Email | Source | Requirement |
 *        Status | Last Contact | Next Follow-up | Notes | Follow-up Stage
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG, run
 *        installLeadFollowUps() once. The trigger runs daily at 10am.
 */

var CONFIG = {
  SHEET_NAME: 'Leads',
  BUSINESS_NAME: 'Your Business Name',
  OWNER_EMAIL: 'you@example.com',
  SIGNATURE: '— Your Name, Your Business Name',
  OWNER_NAME: 'Your Name',
  SCHEDULE_DAYS: [3, 7, 14],          // days after the lead came in
  STOP_STATUSES: ['Won', 'Lost', 'Not Interested', 'Converted', 'Closed', 'Client'],
  NEW_STATUS: 'New',
  SEND_ACK_IMMEDIATELY: true
};

/* ---------------------------------------------------------------- helpers */

function sheetByName_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Sheet "' + name + '" not found.');
  return sh;
}

function readTable_(sh) {
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var r = values[i];
    if (r.join('').toString().trim() === '') continue;
    var o = { _row: i + 1 };
    for (var j = 0; j < headers.length; j++) if (headers[j]) o[headers[j]] = r[j];
    rows.push(o);
  }
  return { headers: headers, rows: rows };
}

function toDate_(v) {
  if (!v) return null;
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v.getTime()) ? null : v;
  var d = new Date(v);
  return isNaN(d.getTime()) ? null : d;
}

function startOfDay_(d) { var x = new Date(d.getTime()); x.setHours(0, 0, 0, 0); return x; }

function daysBetween_(from, to) {
  return Math.round((startOfDay_(to).getTime() - startOfDay_(from).getTime()) / 86400000);
}

function addDays_(d, n) { var x = new Date(d.getTime()); x.setDate(x.getDate() + n); return x; }

function dateText_(d) {
  if (!d) return '—';
  var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return d.getDate() + ' ' + m[d.getMonth()] + ' ' + d.getFullYear();
}

function isStopStatus_(status, stopList) {
  var s = String(status || '').trim().toLowerCase();
  var list = stopList || CONFIG.STOP_STATUSES;
  for (var i = 0; i < list.length; i++) if (String(list[i]).toLowerCase() === s) return true;
  return false;
}

function stageCount_(schedule) { return (schedule || CONFIG.SCHEDULE_DAYS).length; }

/**
 * Which email is due today for a lead? Pure.
 * Stage 1 = the immediate acknowledgement (day 0).
 * Stage 2..n = follow-ups on CONFIG.SCHEDULE_DAYS (day 3, day 7, day 14).
 * Returns { stage, due, dueDate }.
 */
function nextStageFor_(lead, today, cfg) {
  var c = cfg || CONFIG;
  var started = toDate_(lead['Date']) || today;
  var done = Number(lead['Follow-up Stage'] || 0) || 0;
  var total = 1 + stageCount_(c.SCHEDULE_DAYS);
  if (isStopStatus_(lead['Status'], c.STOP_STATUSES)) return { stage: done, due: false };
  if (done >= total) return { stage: done, due: false };

  var nextStage = done + 1;
  var offset = nextStage === 1 ? 0 : c.SCHEDULE_DAYS[nextStage - 2];
  var dueDate = addDays_(started, offset);
  var due = daysBetween_(today, dueDate) <= 0;
  return { stage: nextStage, due: due, dueDate: dueDate };
}

function ackBody_(lead, cfg) {
  var c = cfg || CONFIG;
  return [
    'Hi ' + (lead['Name'] || 'there') + ',',
    '',
    'Thanks for getting in touch with ' + c.BUSINESS_NAME + '. We have your enquiry' +
      (lead['Requirement'] ? ' about "' + lead['Requirement'] + '"' : '') + ' and ' + c.OWNER_NAME + ' will reply personally within one working day.',
    '',
    'If it is urgent, just reply to this email and it reaches us directly.',
    '',
    c.SIGNATURE
  ].join('\n');
}

function followUpBody_(lead, stage, cfg) {
  var c = cfg || CONFIG;
  var openers = [
    'Just following up on your enquiry',
    'Checking in once more',
    'One last note from us'
  ];
  var opener = openers[Math.min(Math.max(stage - 2, 0), openers.length - 1)];
  var lines = [
    'Hi ' + (lead['Name'] || 'there') + ',',
    '',
    opener + ' — ' + (lead['Requirement'] ? 'about "' + lead['Requirement'] + '".' : 'about what you asked us for.'),
    '',
    stage === 1
      ? 'Happy to send a quote or answer any questions. Would a short call this week help?'
      : (stage === 2
        ? 'If the timing is not right, that is completely fine — tell me when to check back and I will.'
        : 'I will leave it here for now. The door stays open: reply any time and we pick up where we left off.'),
    '',
    c.SIGNATURE
  ];
  return lines.join('\n');
}

/* ------------------------------------------------------------------ main */

function runLeadFollowUps() {
  var sh = sheetByName_(CONFIG.SHEET_NAME);
  var table = readTable_(sh);
  var headers = table.headers;
  var col = function (n) { return headers.indexOf(n); };
  var iStage = col('Follow-up Stage'), iNext = col('Next Follow-up'), iLast = col('Last Contact');
  if (iStage === -1) throw new Error('Add a "Follow-up Stage" column to the Leads sheet.');

  var today = new Date();
  var emailed = [], done = 0;

  table.rows.forEach(function (lead) {
    if (isStopStatus_(lead['Status'])) { done++; return; }
    var email = String(lead['Email'] || '').trim();
    var plan = nextStageFor_(lead, today, CONFIG);
    if (!plan.due) return;
    if (email.indexOf('@') === -1) return;

    var isAck = plan.stage === 1;
    if (isAck && !CONFIG.SEND_ACK_IMMEDIATELY) return;

    MailApp.sendEmail({
      to: email,
      subject: isAck
        ? 'Thanks for your enquiry — ' + CONFIG.BUSINESS_NAME
        : 'Following up on your enquiry — ' + CONFIG.BUSINESS_NAME,
      body: isAck ? ackBody_(lead, CONFIG) : followUpBody_(lead, plan.stage, CONFIG),
      name: CONFIG.BUSINESS_NAME
    });

    if (iStage > -1) sh.getRange(lead._row, iStage + 1).setValue(plan.stage);
    if (iLast > -1) sh.getRange(lead._row, iLast + 1).setValue(today);
    if (iNext > -1) {
      var total = 1 + stageCount_(CONFIG.SCHEDULE_DAYS);
      var nxt = plan.stage < total
        ? addDays_(toDate_(lead['Date']) || today, CONFIG.SCHEDULE_DAYS[plan.stage - 1])
        : '';
      sh.getRange(lead._row, iNext + 1).setValue(nxt);
    }
    emailed.push({ name: lead['Name'], stage: plan.stage, ack: isAck });
  });

  Logger.log('Follow-ups sent: ' + emailed.length + ' | stopped or finished: ' + done);
  return emailed;
}

function installLeadFollowUps() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'runLeadFollowUps') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('runLeadFollowUps').timeBased().atHour(10).everyDays(1).create();
  Logger.log('Daily 10am trigger installed for runLeadFollowUps().');
}
