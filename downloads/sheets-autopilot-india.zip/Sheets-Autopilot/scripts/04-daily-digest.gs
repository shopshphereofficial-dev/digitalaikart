/**
 * 04 · MORNING BUSINESS DIGEST
 * One email at 8am with the five things that need you today: money due,
 * money overdue, leads to chase, stock to reorder and deadlines this week.
 *
 * Reads up to four sheets (missing sheets are skipped, not fatal):
 *   Invoices, Leads, Stock, Deadlines
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG, run
 *        installDailyDigest() once. Run sendDailyDigest() by hand first to
 *        see the email in your inbox.
 */

var CONFIG = {
  OWNER_EMAIL: 'you@example.com',
  BUSINESS_NAME: 'Your Business Name',
  INVOICES_SHEET: 'Invoices',
  LEADS_SHEET: 'Leads',
  STOCK_SHEET: 'Stock',
  DEADLINES_SHEET: 'Deadlines',
  PAID_STATUSES: ['Paid', 'Settled', 'Received'],
  DONE_STATUSES: ['Done', 'Completed', 'Cancelled', 'Void', 'Lost', 'Won', 'Closed'],
  DEADLINE_WINDOW_DAYS: 7,
  SEND_EVEN_IF_EMPTY: false
};

/* ---------------------------------------------------------------- helpers */

function getSheetIfExists_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return name ? ss.getSheetByName(name) : null;
}

function readTable_(sh) {
  if (!sh) return { headers: [], rows: [] };
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var r = values[i];
    if (r.join('').toString().trim() === '') continue;
    var o = { _row: i + 1 };
    for (var j = 0; j < headers.length; j++) if (headers[j]) o[headers[j]] = r[j];
    rows.push(o);
  }
  return { headers: headers, rows: rows };
}

function toDate_(v) {
  if (!v) return null;
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v.getTime()) ? null : v;
  var d = new Date(v);
  return isNaN(d.getTime()) ? null : d;
}

function startOfDay_(d) { var x = new Date(d.getTime()); x.setHours(0, 0, 0, 0); return x; }

function daysBetween_(from, to) {
  return Math.round((startOfDay_(to).getTime() - startOfDay_(from).getTime()) / 86400000);
}

function money_(n) {
  var v = Number(n) || 0, neg = v < 0;
  v = Math.abs(v);
  var s = v.toFixed(2).split('.'), whole = s[0], frac = s[1];
  var last3 = whole.slice(-3), rest = whole.slice(0, -3);
  if (rest) rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return (neg ? '-' : '') + '₹' + (rest ? rest + ',' : '') + last3 + '.' + frac;
}

function dateText_(d) {
  if (!d) return '—';
  var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return d.getDate() + ' ' + m[d.getMonth()] + ' ' + d.getFullYear();
}

function statusIn_(status, list) {
  var s = String(status || '').trim().toLowerCase();
  for (var i = 0; i < list.length; i++) if (String(list[i]).toLowerCase() === s) return true;
  return false;
}

function esc_(s) {
  return String(s === undefined || s === null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/* --------------------------------------------------------- data gathering */

/** Pure: turns raw sheet tables into the digest model. Tested directly. */
function buildDigestModel_(data, today, cfg) {
  var c = cfg || CONFIG;
  var model = { dueToday: [], overdue: [], leads: [], stock: [], deadlines: [] };

  (data.invoices || []).forEach(function (inv) {
    if (statusIn_(inv['Status'], c.PAID_STATUSES)) return;
    if (statusIn_(inv['Status'], ['Cancelled', 'Void', 'Draft'])) return;
    var due = toDate_(inv['Due Date']);
    if (!due) return;
    var d = daysBetween_(today, due);
    if (d === 0) model.dueToday.push(inv);
    else if (d < 0) model.overdue.push(inv);
  });

  (data.leads || []).forEach(function (lead) {
    if (statusIn_(lead['Status'], c.DONE_STATUSES)) return;
    var next = toDate_(lead['Next Follow-up']);
    if (next && daysBetween_(today, next) <= 0) model.leads.push(lead);
  });

  (data.stock || []).forEach(function (item) {
    var qty = Number(item['Current Qty']);
    if (isNaN(qty) && item['Opening Qty'] !== undefined) {
      qty = (Number(item['Opening Qty']) || 0) + (Number(item['In Qty']) || 0) - (Number(item['Out Qty']) || 0);
    }
    var reorder = Number(item['Reorder Level']);
    if (!isNaN(qty) && !isNaN(reorder) && reorder > 0 && qty <= reorder) {
      model.stock.push({ sku: item['SKU'], item: item['Item'], qty: qty, reorder: reorder });
    }
  });

  (data.deadlines || []).forEach(function (d) {
    if (statusIn_(d['Status'], c.DONE_STATUSES)) return;
    var due = toDate_(d['Due Date']);
    if (!due) return;
    var left = daysBetween_(today, due);
    if (left <= c.DEADLINE_WINDOW_DAYS) model.deadlines.push({ row: d, left: left });
  });

  model.overdueTotal = model.overdue.reduce(function (a, i) { return a + (Number(i['Amount']) || 0); }, 0);
  model.dueTotal = model.dueToday.reduce(function (a, i) { return a + (Number(i['Amount']) || 0); }, 0);
  return model;
}

function isQuiet_(model) {
  return !model.dueToday.length && !model.overdue.length && !model.leads.length &&
    !model.stock.length && !model.deadlines.length;
}

/** Pure: builds the HTML email body from the model. Tested directly. */
function buildDigestHtml_(model, today, cfg) {
  var c = cfg || CONFIG;
  var card = '#0f1e36', gold = '#f5c542', text = '#e2e8f0', muted = '#9fb0c7';
  var h = [];
  h.push('<!DOCTYPE html><html><body style="margin:0;padding:0;background:#0a1628;">');
  h.push('<div style="max-width:640px;margin:0 auto;padding:24px;background:#0a1628;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;color:' + text + ';">');
  h.push('<h1 style="font-size:20px;margin:0 0 4px;color:' + gold + ';">Good morning — ' + esc_(c.BUSINESS_NAME) + '</h1>');
  h.push('<p style="margin:0 0 20px;color:' + muted + ';font-size:13px;">' + esc_(dateText_(today)) + ' · your 8am digest</p>');

  function block(title, count, rowsHtml) {
    h.push('<div style="background:' + card + ';border:1px solid #1e3557;border-radius:10px;padding:14px 16px;margin:0 0 12px;">');
    h.push('<div style="font-size:14px;font-weight:700;color:' + text + ';margin:0 0 8px;">' + esc_(title) + ' <span style="color:' + gold + ';">' + count + '</span></div>');
    h.push(rowsHtml || '<div style="color:' + muted + ';font-size:13px;">Nothing here. Good.</div>');
    h.push('</div>');
  }
  function table(headers, rows) {
    var t = ['<table style="width:100%;border-collapse:collapse;font-size:13px;">'];
    t.push('<tr>' + headers.map(function (x) { return '<th style="text-align:left;padding:4px 6px 4px 0;color:' + muted + ';font-weight:600;border-bottom:1px solid #1e3557;">' + esc_(x) + '</th>'; }).join('') + '</tr>');
    rows.forEach(function (r) {
      t.push('<tr>' + r.map(function (x) { return '<td style="padding:5px 6px 5px 0;border-bottom:1px solid #14263f;">' + esc_(x) + '</td>'; }).join('') + '</tr>');
    });
    t.push('</table>');
    return t.join('');
  }

  block('Overdue invoices', money_(model.overdueTotal),
    model.overdue.length ? table(['Invoice', 'Client', 'Amount', 'Days late'],
      model.overdue.map(function (i) {
        return [i['Invoice No'], i['Client Name'], money_(i['Amount']), String(Math.abs(daysBetween_(today, toDate_(i['Due Date']))))];
      })) : '');

  block('Due today', money_(model.dueTotal),
    model.dueToday.length ? table(['Invoice', 'Client', 'Amount'],
      model.dueToday.map(function (i) { return [i['Invoice No'], i['Client Name'], money_(i['Amount'])]; })) : '');

  block('Leads to chase', model.leads.length,
    model.leads.length ? table(['Name', 'Phone', 'Requirement'],
      model.leads.map(function (l) { return [l['Name'], l['Phone'], l['Requirement']]; })) : '');

  block('Reorder these', model.stock.length,
    model.stock.length ? table(['SKU', 'Item', 'In stock', 'Reorder at'],
      model.stock.map(function (s) { return [s.sku, s.item, s.qty, s.reorder]; })) : '');

  block('Deadlines in the next ' + c.DEADLINE_WINDOW_DAYS + ' days', model.deadlines.length,
    model.deadlines.length ? table(['Title', 'Client', 'Due', 'Days left'],
      model.deadlines.map(function (d) { return [d.row['Title'], d.row['Client'], dateText_(toDate_(d.row['Due Date'])), d.left]; })) : '');

  h.push('<p style="color:' + muted + ';font-size:12px;margin:16px 0 0;">Sent by Sheets Autopilot · daily digest · open your sheet to act on any of these.</p>');
  h.push('</div></body></html>');
  return h.join('');
}

/* ------------------------------------------------------------------ main */

function sendDailyDigest() {
  var data = {
    invoices: readTable_(getSheetIfExists_(CONFIG.INVOICES_SHEET)).rows,
    leads: readTable_(getSheetIfExists_(CONFIG.LEADS_SHEET)).rows,
    stock: readTable_(getSheetIfExists_(CONFIG.STOCK_SHEET)).rows,
    deadlines: readTable_(getSheetIfExists_(CONFIG.DEADLINES_SHEET)).rows
  };
  var today = new Date();
  var model = buildDigestModel_(data, today, CONFIG);
  if (isQuiet_(model) && !CONFIG.SEND_EVEN_IF_EMPTY) {
    Logger.log('Digest skipped — nothing to report.');
    return { skipped: true };
  }
  var html = buildDigestHtml_(model, today, CONFIG);
  MailApp.sendEmail({
    to: CONFIG.OWNER_EMAIL,
    subject: 'Today: ' + model.overdue.length + ' overdue · ' + model.dueToday.length + ' due · ' +
      model.leads.length + ' leads · ' + model.stock.length + ' to reorder',
    htmlBody: html,
    body: 'Your 8am digest. Open this email in an HTML-capable client to see the tables.'
  });
  Logger.log('Digest sent to ' + CONFIG.OWNER_EMAIL);
  return model;
}

function installDailyDigest() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'sendDailyDigest') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('sendDailyDigest').timeBased().atHour(8).everyDays(1).create();
  Logger.log('Daily 8am trigger installed for sendDailyDigest().');
}
