/**
 * 07 · DEADLINES → GOOGLE CALENDAR
 * Pushes every live row in the Deadlines sheet into your Google Calendar,
 * keeps the event in sync when the date changes, and removes it when the row
 * is marked Done. Event IDs are stored in the sheet so nothing is duplicated.
 *
 * Sheet: "Deadlines" — Title | Client | Due Date | Type | Owner | Status |
 *        Calendar Event ID
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG, run
 *        installDeadlineSync() once. Calendar ID is usually your email for
 *        the default calendar.
 */

var CONFIG = {
  SHEET_NAME: 'Deadlines',
  CALENDAR_ID: 'primary',          // or the calendar's ID from its settings
  ALL_DAY_EVENTS: true,
  EVENT_HOUR: 10,                  // used when ALL_DAY_EVENTS is false
  EVENT_MINUTES: 30,
  DONE_STATUSES: ['Done', 'Completed', 'Cancelled', 'Void'],
  OWNER_EMAIL: 'you@example.com',
  BUSINESS_NAME: 'Your Business Name',
  EMAIL_SUMMARY: true
};

/* ---------------------------------------------------------------- helpers */

function sheetByName_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Sheet "' + name + '" not found.');
  return sh;
}

function readTable_(sh) {
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var r = values[i];
    if (r.join('').toString().trim() === '') continue;
    var o = { _row: i + 1 };
    for (var j = 0; j < headers.length; j++) if (headers[j]) o[headers[j]] = r[j];
    rows.push(o);
  }
  return { headers: headers, rows: rows };
}

function toDate_(v) {
  if (!v) return null;
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v.getTime()) ? null : v;
  var d = new Date(v);
  return isNaN(d.getTime()) ? null : d;
}

function dateText_(d) {
  if (!d) return '—';
  var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return d.getDate() + ' ' + m[d.getMonth()] + ' ' + d.getFullYear();
}

function isDone_(status, doneList) {
  var s = String(status || '').trim().toLowerCase();
  var list = doneList || CONFIG.DONE_STATUSES;
  for (var i = 0; i < list.length; i++) if (String(list[i]).toLowerCase() === s) return true;
  return false;
}

/** Default calendar unless a specific calendar ID is set in CONFIG. */
function getCalendar_() {
  if (!CONFIG.CALENDAR_ID || CONFIG.CALENDAR_ID === 'primary') return CalendarApp.getDefaultCalendar();
  try {
    return CalendarApp.getCalendarById(CONFIG.CALENDAR_ID) || CalendarApp.getDefaultCalendar();
  } catch (e) {
    Logger.log('Calendar "' + CONFIG.CALENDAR_ID + '" not reachable, using the default calendar.');
    return CalendarApp.getDefaultCalendar();
  }
}

function eventTitle_(row, cfg) {
  var c = cfg || CONFIG;
  var parts = [row['Title'] || 'Deadline'];
  if (row['Client']) parts.push('· ' + row['Client']);
  if (row['Type']) parts.push('[' + row['Type'] + ']');
  return parts.join(' ');
}

function eventDescription_(row, cfg) {
  var c = cfg || CONFIG;
  return [
    'Client: ' + (row['Client'] || '—'),
    'Type: ' + (row['Type'] || '—'),
    'Owner: ' + (row['Owner'] || '—'),
    'Status: ' + (row['Status'] || '—'),
    '',
    'Synced from the Deadlines sheet by Sheets Autopilot.'
  ].join('\n');
}

/** Pure: decide what to do with one row. Returns 'create' | 'update' | 'delete' | 'skip'. */
function syncAction_(row, today, cfg) {
  var c = cfg || CONFIG;
  var due = toDate_(row['Due Date']);
  var hasEvent = !!String(row['Calendar Event ID'] || '').trim();
  if (!due) return hasEvent && isDone_(row['Status'], c.DONE_STATUSES) ? 'delete' : 'skip';
  if (isDone_(row['Status'], c.DONE_STATUSES)) return hasEvent ? 'delete' : 'skip';
  return hasEvent ? 'update' : 'create';
}

function buildEventOptions_(row, cfg) {
  var c = cfg || CONFIG;
  var due = toDate_(row['Due Date']);
  if (c.ALL_DAY_EVENTS) {
    var next = new Date(due.getTime());
    next.setDate(next.getDate() + 1);
    return { start: due, end: next, allDay: true };
  }
  var start = new Date(due.getTime());
  start.setHours(c.EVENT_HOUR, 0, 0, 0);
  var end = new Date(start.getTime() + c.EVENT_MINUTES * 60000);
  return { start: start, end: end, allDay: false };
}

/* ------------------------------------------------------------------ main */

function syncDeadlinesToCalendar() {
  var sh = sheetByName_(CONFIG.SHEET_NAME);
  var table = readTable_(sh);
  var headers = table.headers;
  var iEvent = headers.indexOf('Calendar Event ID');
  if (iEvent === -1) throw new Error('Add a "Calendar Event ID" column to the Deadlines sheet.');

  var cal = getCalendar_();
  var today = new Date();
  var stats = { created: 0, updated: 0, deleted: 0, skipped: 0 };

  table.rows.forEach(function (row) {
    var action = syncAction_(row, today, CONFIG);
    var opts = buildEventOptions_(row, CONFIG);
    var existingId = String(row['Calendar Event ID'] || '').trim();

    try {
      if (action === 'create') {
        var ev = cal.createEvent(eventTitle_(row, CONFIG), opts.start, opts.end, {
          description: eventDescription_(row, CONFIG),
          allDayEvent: opts.allDay
        });
        sh.getRange(row._row, iEvent + 1).setValue(ev.getId());
        stats.created++;
      } else if (action === 'update') {
        var ev2 = cal.getEventById(existingId);
        if (!ev2) {
          var recreated = cal.createEvent(eventTitle_(row, CONFIG), opts.start, opts.end, {
            description: eventDescription_(row, CONFIG), allDayEvent: opts.allDay
          });
          sh.getRange(row._row, iEvent + 1).setValue(recreated.getId());
          stats.created++;
        } else {
          ev2.setTitle(eventTitle_(row, CONFIG));
          ev2.setDescription(eventDescription_(row, CONFIG));
          if (opts.allDay) {
            ev2.setAllDayDates(opts.start, opts.end);
          } else {
            ev2.setTime(opts.start, opts.end);
          }
          stats.updated++;
        }
      } else if (action === 'delete') {
        var ev3 = cal.getEventById(existingId);
        if (ev3) ev3.deleteEvent();
        sh.getRange(row._row, iEvent + 1).setValue('');
        stats.deleted++;
      } else {
        stats.skipped++;
      }
    } catch (e) {
      Logger.log('Row ' + row._row + ' failed: ' + e.message);
      stats.skipped++;
    }
  });

  if (CONFIG.EMAIL_SUMMARY) {
    MailApp.sendEmail({
      to: CONFIG.OWNER_EMAIL,
      subject: 'Calendar sync: ' + stats.created + ' new, ' + stats.updated + ' updated, ' + stats.deleted + ' removed',
      body: 'Deadlines sheet synced to the calendar "' + CONFIG.CALENDAR_ID + '".\n\n' +
        'Created: ' + stats.created + '\nUpdated: ' + stats.updated + '\nRemoved: ' + stats.deleted +
        '\nSkipped: ' + stats.skipped
    });
  }
  Logger.log(JSON.stringify(stats));
  return stats;
}

function installDeadlineSync() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'syncDeadlinesToCalendar') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('syncDeadlinesToCalendar').timeBased().everyHours(6).create();
  Logger.log('6-hourly trigger installed for syncDeadlinesToCalendar().');
}
