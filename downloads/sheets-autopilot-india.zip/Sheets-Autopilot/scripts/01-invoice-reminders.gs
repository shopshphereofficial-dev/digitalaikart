/**
 * 01 · INVOICE REMINDER ENGINE
 * Sends polite, escalating payment reminders for unpaid invoices on a daily trigger.
 *
 * Sheet: "Invoices"
 * Columns used: Invoice No | Client Name | Client Email | Amount | Date Issued |
 *               Due Date | Status | Paid On | Notes | Last Reminder | Reminder Stage
 *
 * Setup: paste this file into Extensions > Apps Script (project "Invoices"),
 *        edit CONFIG, run installInvoiceReminders(), approve permissions.
 * Test : run sendInvoiceReminders() once by hand and read the log.
 */

var CONFIG = {
  SHEET_NAME: 'Invoices',
  BUSINESS_NAME: 'Your Business Name',
  OWNER_EMAIL: 'you@example.com',      // daily summary goes here
  REPLY_TO: 'you@example.com',
  SIGNATURE: '— Your Name, Your Business Name',
  UPI_ID: '',                          // optional: shown in reminders if set
  REMINDER_STAGES: [                   // days before / after the due date
    { key: 'T-3',  daysLeft: 3,  label: 'Friendly heads-up' },
    { key: 'DUE',  daysLeft: 0,  label: 'Due today' },
    { key: 'D+7',  daysLeft: -7, label: 'First follow-up' },
    { key: 'D+15', daysLeft: -15, label: 'Second follow-up' },
    { key: 'D+30', daysLeft: -30, label: 'Final notice' }
  ],
  PAID_STATUSES: ['Paid', 'Settled', 'Received'],
  SKIP_STATUSES: ['Cancelled', 'Void', 'Draft'],
  SEND_OWNER_SUMMARY: true
};

/* ---------------------------------------------------------------- helpers */

function sheetByName_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Sheet "' + name + '" not found. Create it from the starter workbook.');
  return sh;
}

function readTable_(sh) {
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var r = values[i];
    if (r.join('').toString().trim() === '') continue;
    var o = { _row: i + 1 };
    for (var j = 0; j < headers.length; j++) if (headers[j]) o[headers[j]] = r[j];
    rows.push(o);
  }
  return { headers: headers, rows: rows };
}

function toDate_(v) {
  if (!v) return null;
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v.getTime()) ? null : v;
  var d = new Date(v);
  return isNaN(d.getTime()) ? null : d;
}

function startOfDay_(d) {
  var x = new Date(d.getTime());
  x.setHours(0, 0, 0, 0);
  return x;
}

function daysBetween_(from, to) {
  var a = startOfDay_(from).getTime();
  var b = startOfDay_(to).getTime();
  return Math.round((b - a) / 86400000);
}

function money_(n) {
  var v = Number(n) || 0;
  var neg = v < 0;
  v = Math.abs(v);
  var s = v.toFixed(2).split('.');
  var whole = s[0], frac = s[1];
  var last3 = whole.slice(-3), rest = whole.slice(0, -3);
  if (rest) rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  var out = '₹' + (rest ? rest + ',' : '') + last3 + '.' + frac;
  return neg ? '-' + out : out;
}

function dateText_(d) {
  if (!d) return '—';
  var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return d.getDate() + ' ' + m[d.getMonth()] + ' ' + d.getFullYear();
}

function statusIn_(status, list) {
  var s = String(status || '').trim().toLowerCase();
  for (var i = 0; i < list.length; i++) if (String(list[i]).toLowerCase() === s) return true;
  return false;
}

/**
 * Which reminder stage is due for an invoice, given how many days are left?
 * Returns the stage object or null. Pure — used by the test suite.
 */
function stageFor_(daysLeft, stages) {
  var list = (stages || CONFIG.REMINDER_STAGES).slice();
  var best = null;
  for (var i = 0; i < list.length; i++) {
    var st = list[i];
    if (daysLeft <= st.daysLeft) {
      if (!best || st.daysLeft < best.daysLeft) best = st;
    }
  }
  return best;
}

/** Has this exact stage already been sent? Prevents double-emailing. */
function stageAlreadySent_(currentStage, stages) {
  if (!currentStage) return false;
  var list = stages || CONFIG.REMINDER_STAGES;
  for (var i = 0; i < list.length; i++) {
    if (list[i].key === String(currentStage).trim()) return true;
  }
  return false;
}

function reminderSubject_(inv, stage, daysLeft) {
  var left = (typeof daysLeft === 'number') ? daysLeft : null;
  if (left !== null && left > 0) {
    return 'Friendly reminder: invoice ' + inv['Invoice No'] + ' is due on ' + dateText_(toDate_(inv['Due Date']));
  }
  if (left === 0) {
    return 'Invoice ' + inv['Invoice No'] + ' — ' + money_(inv['Amount']) + ' due today';
  }
  return 'Payment reminder — invoice ' + inv['Invoice No'] + ' (' + money_(inv['Amount']) + ')';
}

function reminderBody_(inv, stage, cfg, daysLeft) {
  var c = cfg || CONFIG;
  var due = toDate_(inv['Due Date']);
  var left = (typeof daysLeft === 'number') ? daysLeft : null;
  var lines = [];
  lines.push('Hi ' + (inv['Client Name'] || 'there') + ',');
  lines.push('');
  if (left !== null && left > 0) {
    lines.push('A quick note that invoice ' + inv['Invoice No'] + ' for ' + money_(inv['Amount']) +
      ' falls due on ' + dateText_(due) + ' (' + left + ' day' + (left === 1 ? '' : 's') + ' from today).' +
      ' Nothing to do if it is already scheduled.');
  } else if (left === 0) {
    lines.push('Invoice ' + inv['Invoice No'] + ' for ' + money_(inv['Amount']) +
      ' is due today (' + dateText_(due) + ').');
  } else if (left !== null) {
    lines.push('Invoice ' + inv['Invoice No'] + ' for ' + money_(inv['Amount']) +
      ' was due on ' + dateText_(due) + ', ' + Math.abs(left) + ' day' + (Math.abs(left) === 1 ? '' : 's') +
      ' ago, and is still showing as unpaid at our end.');
  } else {
    lines.push('Invoice ' + inv['Invoice No'] + ' for ' + money_(inv['Amount']) +
      ' was due on ' + dateText_(due) + ' and is still showing as unpaid at our end.');
  }
  lines.push('');
  lines.push('Invoice no.: ' + inv['Invoice No']);
  lines.push('Amount due : ' + money_(inv['Amount']));
  lines.push('Due date   : ' + dateText_(due));
  if (c.UPI_ID) lines.push('UPI        : ' + c.UPI_ID);
  lines.push('');
  lines.push('If you have already paid, please ignore this note and send us the reference — we will update our records.');
  lines.push('If anything about the invoice is unclear, just reply to this email.');
  lines.push('');
  lines.push(c.SIGNATURE);
  return lines.join('\n');
}

/* ------------------------------------------------------------------ main */

function sendInvoiceReminders() {
  var sh = sheetByName_(CONFIG.SHEET_NAME);
  var table = readTable_(sh);
  var headers = table.headers;
  var today = new Date();
  var col = function (name) { return headers.indexOf(name); };
  var iLast = col('Last Reminder');
  var iStage = col('Reminder Stage');
  var sent = [], skippedNoEmail = 0, settled = 0;

  table.rows.forEach(function (inv) {
    var status = inv['Status'];
    if (statusIn_(status, CONFIG.PAID_STATUSES)) { settled++; return; }
    if (statusIn_(status, CONFIG.SKIP_STATUSES)) return;

    var due = toDate_(inv['Due Date']);
    if (!due) return;
    var email = String(inv['Client Email'] || '').trim();
    if (email.indexOf('@') === -1) { skippedNoEmail++; return; }

    var daysLeft = daysBetween_(today, due);
    var stage = stageFor_(daysLeft, CONFIG.REMINDER_STAGES);
    if (!stage) return;                                  // too early
    if (stageAlreadySent_(inv['Reminder Stage'], CONFIG.REMINDER_STAGES)) return;

    MailApp.sendEmail({
      to: email,
      replyTo: CONFIG.REPLY_TO,
      subject: reminderSubject_(inv, stage, daysLeft),
      body: reminderBody_(inv, stage, CONFIG, daysLeft),
      name: CONFIG.BUSINESS_NAME
    });

    if (iLast > -1) sh.getRange(inv._row, iLast + 1).setValue(new Date());
    if (iStage > -1) sh.getRange(inv._row, iStage + 1).setValue(stage.key);
    sent.push({ invoice: inv['Invoice No'], client: inv['Client Name'], stage: stage.key, amount: Number(inv['Amount']) || 0 });
  });

  if (CONFIG.SEND_OWNER_SUMMARY && (sent.length || skippedNoEmail)) {
    var total = sent.reduce(function (a, s) { return a + s.amount; }, 0);
    var body = ['Invoice reminders sent: ' + sent.length, ''];
    sent.forEach(function (s) { body.push('• ' + s.invoice + ' — ' + s.client + ' — ' + s.stage + ' — ' + money_(s.amount)); });
    if (skippedNoEmail) body.push('', 'Skipped ' + skippedNoEmail + ' invoice(s) with no client email on file.');
    body.push('', 'Value chased today: ' + money_(total));
    MailApp.sendEmail({
      to: CONFIG.OWNER_EMAIL,
      subject: 'Reminders sent today: ' + sent.length + ' · ' + money_(total),
      body: body.join('\n')
    });
  }
  Logger.log('Reminders sent: ' + sent.length + ' | skipped (no email): ' + skippedNoEmail + ' | already paid: ' + settled);
  return sent;
}

/** Run once. Adds a menu and a daily 9am trigger (removes old ones first). */
function installInvoiceReminders() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'sendInvoiceReminders') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('sendInvoiceReminders').timeBased().atHour(9).everyDays(1).create();
  Logger.log('Daily 9am trigger installed for sendInvoiceReminders().');
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Autopilot')
    .addItem('Send invoice reminders now', 'sendInvoiceReminders')
    .addItem('Install daily 9am trigger', 'installInvoiceReminders')
    .addToUi();
}
