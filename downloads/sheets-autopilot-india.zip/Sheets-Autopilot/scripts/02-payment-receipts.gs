/**
 * 02 · PAYMENT RECEIPT SENDER
 * The moment you set an invoice's Status to "Paid", the client gets a receipt
 * email with a receipt number and the amount written in Indian words.
 *
 * Sheet: "Invoices" — Invoice No | Client Name | Client Email | Amount |
 *        Date Issued | Due Date | Status | Paid On | Notes | Receipt No
 *
 * Setup: paste into Extensions > Apps Script, edit CONFIG, then run
 *        installReceiptTrigger() once. Trigger runs every 15 minutes and only
 *        emails rows that are Paid but have no Receipt No yet.
 */

var CONFIG = {
  SHEET_NAME: 'Invoices',
  BUSINESS_NAME: 'Your Business Name',
  OWNER_EMAIL: 'you@example.com',
  SIGNATURE: '— Your Name, Your Business Name',
  RECEIPT_PREFIX: 'RCPT',
  PAYMENT_MODE_FALLBACK: 'as recorded',
  ALSO_EMAIL_OWNER: true
};

/* ---------------------------------------------------------------- helpers */

function sheetByName_(name) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if (!sh) throw new Error('Sheet "' + name + '" not found.');
  return sh;
}

function readTable_(sh) {
  var values = sh.getDataRange().getValues();
  if (!values.length) return { headers: [], rows: [] };
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var i = 1; i < values.length; i++) {
    var r = values[i];
    if (r.join('').toString().trim() === '') continue;
    var o = { _row: i + 1 };
    for (var j = 0; j < headers.length; j++) if (headers[j]) o[headers[j]] = r[j];
    rows.push(o);
  }
  return { headers: headers, rows: rows };
}

function toDate_(v) {
  if (!v) return null;
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v.getTime()) ? null : v;
  var d = new Date(v);
  return isNaN(d.getTime()) ? null : d;
}

function money_(n) {
  var v = Number(n) || 0, neg = v < 0;
  v = Math.abs(v);
  var s = v.toFixed(2).split('.'), whole = s[0], frac = s[1];
  var last3 = whole.slice(-3), rest = whole.slice(0, -3);
  if (rest) rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  var out = '₹' + (rest ? rest + ',' : '') + last3 + '.' + frac;
  return neg ? '-' + out : out;
}

function dateText_(d) {
  if (!d) return '—';
  var m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return d.getDate() + ' ' + m[d.getMonth()] + ' ' + d.getFullYear();
}

function pad_(n, w) { var s = String(n); while (s.length < w) s = '0' + s; return s; }

/** Indian numbering: 125000 -> "One Lakh Twenty Five Thousand Rupees Only" */
function amountInWordsIndian_(amount) {
  var n = Math.floor(Math.abs(Number(amount) || 0));
  var paise = Math.round((Math.abs(Number(amount) || 0) - n) * 100);
  if (n === 0 && paise === 0) return 'Zero Rupees Only';

  var ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  var tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function two(x) {
    if (x < 20) return ones[x];
    return (tens[Math.floor(x / 10)] + (x % 10 ? ' ' + ones[x % 10] : ''));
  }
  function three(x) {
    var h = Math.floor(x / 100), r = x % 100, out = [];
    if (h) out.push(ones[h] + ' Hundred');
    if (r) out.push(two(r));
    return out.join(' ');
  }

  var crore = Math.floor(n / 10000000); n = n % 10000000;
  var lakh = Math.floor(n / 100000); n = n % 100000;
  var thousand = Math.floor(n / 1000); n = n % 1000;
  var rest = n;

  var parts = [];
  if (crore) parts.push(three(crore) + ' Crore');
  if (lakh) parts.push(three(lakh) + ' Lakh');
  if (thousand) parts.push(three(thousand) + ' Thousand');
  if (rest) parts.push(three(rest));

  var words = parts.join(' ').replace(/\s+/g, ' ').trim();
  var out = (words || 'Zero') + ' Rupees';
  if (paise) out += ' and ' + two(paise) + ' Paise';
  return out + ' Only';
}

/** RCPT-2026-10-0007 style number from a running counter. */
function receiptNumber_(prefix, date, seq) {
  var d = date || new Date();
  return prefix + '-' + d.getFullYear() + '-' + pad_(d.getMonth() + 1, 2) + '-' + pad_(seq, 4);
}

/** Rows that are Paid but still have no receipt number. Pure. */
function pendingReceipts_(rows, paidStatuses) {
  var paid = (paidStatuses || ['paid', 'settled', 'received']).map(function (s) { return String(s).toLowerCase(); });
  return rows.filter(function (r) {
    var st = String(r['Status'] || '').trim().toLowerCase();
    return paid.indexOf(st) > -1 && !String(r['Receipt No'] || '').trim();
  });
}

function receiptBody_(inv, receiptNo, cfg) {
  var c = cfg || CONFIG;
  var paidOn = toDate_(inv['Paid On']) || new Date();
  var lines = [
    'Hi ' + (inv['Client Name'] || 'there') + ',',
    '',
    'Thank you — we have received your payment. This email is your receipt.',
    '',
    'Receipt no. : ' + receiptNo,
    'Invoice no. : ' + inv['Invoice No'],
    'Amount paid : ' + money_(inv['Amount']),
    'In words    : ' + amountInWordsIndian_(inv['Amount']),
    'Paid on     : ' + dateText_(paidOn),
    'Mode        : ' + (inv['Payment Mode'] || c.PAYMENT_MODE_FALLBACK),
    '',
    'Keep this email for your records. Nothing further is needed from you.',
    '',
    c.SIGNATURE
  ];
  return lines.join('\n');
}

/* ------------------------------------------------------------------ main */

function sendPaymentReceipts() {
  var sh = sheetByName_(CONFIG.SHEET_NAME);
  var table = readTable_(sh);
  var headers = table.headers;
  var iReceipt = headers.indexOf('Receipt No');
  var iPaidOn = headers.indexOf('Paid On');
  if (iReceipt === -1) throw new Error('Add a "Receipt No" column to the ' + CONFIG.SHEET_NAME + ' sheet.');

  var existing = table.rows.filter(function (r) { return String(r['Receipt No'] || '').trim(); }).length;
  var todo = pendingReceipts_(table.rows);
  var sent = [];

  todo.forEach(function (inv, idx) {
    var email = String(inv['Client Email'] || '').trim();
    var receiptNo = receiptNumber_(CONFIG.RECEIPT_PREFIX, new Date(), existing + idx + 1);
    if (iReceipt > -1) sh.getRange(inv._row, iReceipt + 1).setValue(receiptNo);
    if (iPaidOn > -1 && !toDate_(inv['Paid On'])) sh.getRange(inv._row, iPaidOn + 1).setValue(new Date());
    if (email.indexOf('@') === -1) { sent.push({ invoice: inv['Invoice No'], receipt: receiptNo, emailed: false }); return; }

    MailApp.sendEmail({
      to: email,
      subject: 'Payment received — receipt ' + receiptNo,
      body: receiptBody_(inv, receiptNo, CONFIG),
      name: CONFIG.BUSINESS_NAME
    });
    sent.push({ invoice: inv['Invoice No'], receipt: receiptNo, emailed: true });
  });

  if (CONFIG.ALSO_EMAIL_OWNER && sent.length) {
    var lines = ['Receipts issued: ' + sent.length, ''];
    sent.forEach(function (s) { lines.push('• ' + s.receipt + ' for invoice ' + s.invoice + (s.emailed ? '' : ' (no client email — receipt number assigned, not emailed)')); });
    MailApp.sendEmail({ to: CONFIG.OWNER_EMAIL, subject: 'Receipts issued: ' + sent.length, body: lines.join('\n') });
  }
  Logger.log('Receipts issued: ' + sent.length);
  return sent;
}

function installReceiptTrigger() {
  var triggers = ScriptApp.getProjectTriggers();
  for (var i = 0; i < triggers.length; i++) {
    if (triggers[i].getHandlerFunction() === 'sendPaymentReceipts') ScriptApp.deleteTrigger(triggers[i]);
  }
  ScriptApp.newTrigger('sendPaymentReceipts').timeBased().everyMinutes(15).create();
  Logger.log('15-minute trigger installed for sendPaymentReceipts().');
}
