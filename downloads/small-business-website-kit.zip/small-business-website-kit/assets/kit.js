/* Small Business Website Kit — shared JavaScript
   Kept deliberately small and dependency-free so the templates work
   offline, on any host, with nothing to install.
   - mobile menu toggle
   - auto year in the footer
   - contact form -> WhatsApp / email handoff (no server needed)
   - coming-soon countdown (reads data-deadline on <body>)
*/
(function () {
  "use strict";

  /* ---- mobile menu ---- */
  document.addEventListener("click", function (e) {
    var t = e.target.closest(".nav-toggle");
    if (t) {
      var links = document.querySelector(".nav-links");
      if (links) links.classList.toggle("open");
    }
  });

  /* ---- current year in footer ---- */
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("[data-year]").forEach(function (el) {
      el.textContent = new Date().getFullYear();
    });

    /* ---- contact form: build a message and open WhatsApp / mail ---- */
    document.querySelectorAll("form[data-contact]").forEach(function (form) {
      form.addEventListener("submit", function (ev) {
        ev.preventDefault();
        var get = function (n) {
          var f = form.querySelector('[name="' + n + '"]');
          return f ? f.value.trim() : "";
        };
        var lines = [
          "New enquiry from your website",
          "",
          "Name: " + get("name"),
          "Phone: " + get("phone"),
          "Email: " + get("email"),
          "Message: " + get("message")
        ];
        var text = encodeURIComponent(lines.join("\n"));
        var phone = (form.getAttribute("data-wa") || "").replace(/[^0-9]/g, "");
        var done = form.querySelector(".form-done");
        if (phone) {
          window.open("https://wa.me/" + phone + "?text=" + text, "_blank");
        } else {
          var email = form.getAttribute("data-email") || "";
          window.location.href = "mailto:" + email + "?subject=" + encodeURIComponent("Website enquiry") + "&body=" + text;
        }
        if (done) done.classList.remove("hide");
      });
    });

    /* ---- coming soon countdown ---- */
    var body = document.body;
    var deadline = body && body.getAttribute("data-deadline");
    var cd = document.querySelector("[data-countdown]");
    if (deadline && cd) {
      var target = new Date(deadline).getTime();
      var set = function (sel, val) {
        var el = cd.querySelector(sel);
        if (el) el.textContent = String(val).padStart(2, "0");
      };
      var tick = function () {
        var diff = Math.max(0, target - Date.now());
        var d = Math.floor(diff / 86400000);
        var h = Math.floor((diff % 86400000) / 3600000);
        var m = Math.floor((diff % 3600000) / 60000);
        var s = Math.floor((diff % 60000) / 1000);
        set("[data-d]", d); set("[data-h]", h); set("[data-m]", m); set("[data-s]", s);
      };
      tick();
      setInterval(tick, 1000);
    }
  });
})();
