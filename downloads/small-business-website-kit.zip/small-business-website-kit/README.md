# Small Business Website Kit

**Five ready-to-use, mobile-friendly website templates for Indian small businesses.**
HTML + CSS only — no build tools, no subscriptions, nothing to install.

---

## What's in this download

```
index.html                  ← START HERE: preview every template
CHEATSHEET.html             ← one-page customisation guide
README.md                   ← this file
LICENSE.txt                 ← usage terms

assets/
  kit.css                   ← the single stylesheet shared by all templates
  kit.js                    ← small script: mobile menu, contact forms, countdown

templates/
  local-business/index.html ← repair, salon, clinic, tuition, cleaning services
  freelancer/index.html     ← designer, developer, consultant, writer
  product-launch/index.html ← sell a course, product or service online
  restaurant-menu/index.html← cafe, cloud kitchen, tiffin service
  coming-soon/index.html    ← countdown + email sign-up while you build
```

**To begin:** double-click `index.html` (or open it in any browser) and click a template to preview it.

---

## The five templates

| Template | Use it for | Key sections |
|---|---|---|
| **Local services** | Shops and home-service businesses | Services, rate table, why-us, work gallery, booking form |
| **Freelancer** | Solo professionals | Portfolio, services, three packages, process, FAQ, enquiry form |
| **Product / course launch** | Selling a digital product or course | Benefits, curriculum, who-it's-for, two price tiers, FAQ, buy button |
| **Restaurant / kitchen** | Cafes and tiffin services | Menu with veg/non-veg marks, monthly plans, how to order, location |
| **Coming soon** | Any business before launch | Live countdown, email sign-up, social links |

---

## Customise it in six edits

1. **Colours** — open `assets/kit.css` and change the values at the top (`--brand`, `--brand-dark`, `--accent`, `--ink`, `--soft`). All five templates re-theme instantly.
2. **Your details** — open a template's `index.html` and use Find & Replace to swap the sample name, phone, email and WhatsApp number for your own.
3. **Remove the sample banner** — delete the line that starts with `<div class="demo-bar">`.
4. **Text** — edit the words between the `<h1>`, `<h2>`, `<p>` and `<li>` tags. Leave the tags in place.
5. **Images** — add your own photos with `<img src="photos/your-photo.jpg" alt="Description">`.
6. **Publish** — drag the folder onto `app.netlify.com/drop`, or push it to GitHub Pages.

Full step-by-step detail is in `CHEATSHEET.html`.

> The sample business names, phone numbers, prices and reviews are **placeholders**. Replace every one of them with your real details before you publish, and never publish reviews that are not genuine.

---

## How the contact forms work

There is no server, database or email service to set up. When a visitor submits a form:

- if the form has a `data-wa` number, their message opens in **WhatsApp** ready to send;
- otherwise it opens their **email app** addressed to your `data-email`.

To change where enquiries go, edit these two attributes on the `<form>` tag:

```html
<form data-contact data-wa="919000000000" data-email="you@yourbusiness.com">
```

Use the full WhatsApp number with the country code and **no** `+`, spaces or dashes (e.g. `919000000000`).

---

## Publishing your site (free options)

**Netlify Drop — easiest**
1. Go to `app.netlify.com/drop`.
2. Drag your template folder onto the page.
3. You get a live link in seconds. You can add your own domain later.

**GitHub Pages**
1. Create a free GitHub account and a new repository.
2. Upload the template files (keep `index.html` at the top level of the repo or folder).
3. In **Settings → Pages**, choose the `main` branch and save. Your site appears at `yourname.github.io/repo`.

**A note on the home page:** hosts look for a file named `index.html` as the home page. Keep that filename.

---

## Compatibility

- Works in every modern browser: Chrome, Edge, Firefox, Safari (desktop and mobile).
- No external fonts, frameworks, trackers or CDN links — the pages load fast and work **offline**.
- You can edit the files in any text editor: Notepad, TextEdit, VS Code, Sublime, or even online editors.
- Responsive down to small phone widths; test on a phone before going live.

---

## Frequently asked questions

**Do I need to know how to code?**
No. If you can copy and paste text, you can customise these templates. The cheat sheet walks through each edit.

**Can I use these for a client's business?**
Yes — see `LICENSE.txt`. You may use the templates for your own business and for client projects. You may not resell or redistribute them as templates.

**Will these work with WordPress?**
They are plain HTML pages, not a WordPress theme. You can host them on their own, or copy the layout into a builder if you prefer.

**Can I add more pages?**
Yes. Copy a template folder, rename it (e.g. `services/`) and edit the copy. Link to it from the menu with `<a href="services/index.html">`.

**Something looks broken after I edited it.**
Most often a tag was deleted by mistake. Undo your last change, or re-open the original file from the download and start that edit again.

---

## Support

This is a digital template product. If a file is corrupted or missing from your download, contact the store where you bought it and it will be replaced.

*Version 1.0*
