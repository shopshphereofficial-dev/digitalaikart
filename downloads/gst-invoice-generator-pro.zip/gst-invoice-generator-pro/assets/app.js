/* =====================================================================
   GST Invoice Generator Pro  —  offline web tool
   (c) 2026 Digitalaikart. Sold as a digital product. See LICENSE.txt.
   Single-file, dependency-free. Works fully offline in any modern browser.
   ===================================================================== */
(function () {
  'use strict';

  /* ------------------------------------------------------------------
     1. PURE HELPERS  (no DOM — unit-testable, exported at the bottom)
     ------------------------------------------------------------------ */

  var GST_RATES = [0, 0.25, 3, 5, 12, 18, 28];

  function num(v) {
    var n = parseFloat(v);
    return isFinite(n) ? n : 0;
  }

  function round2(n) {
    return Math.round((num(n) + Number.EPSILON) * 100) / 100;
  }

  /* Compute one line item's money figures.
     item = { qty, rate, discount, gstRate }  (discount is a percentage) */
  function computeLine(item) {
    item = item || {};
    var qty = num(item.qty);
    var rate = num(item.rate);
    var disc = num(item.discount);
    var gstRate = num(item.gstRate);
    var gross = qty * rate;
    var discountAmt = gross * disc / 100;
    var taxable = gross - discountAmt;
    var gst = taxable * gstRate / 100;
    return {
      gross: round2(gross),
      discountAmt: round2(discountAmt),
      taxable: round2(taxable),
      gst: round2(gst),
      total: round2(taxable + gst)
    };
  }

  /* Inter-state supply => IGST, intra-state => CGST + SGST */
  function isInterState(bizState, placeOfSupply) {
    return !!bizState && !!placeOfSupply && String(bizState) !== String(placeOfSupply);
  }

  /* Totals for a whole document.
     opts = { roundOff: true|false }  (default true) */
  function computeTotals(items, bizState, placeOfSupply, opts) {
    opts = opts || {};
    items = items || [];
    var inter = isInterState(bizState, placeOfSupply);
    var grossTotal = 0, discountTotal = 0, taxable = 0, cgst = 0, sgst = 0, igst = 0;
    var byRate = {};
    items.forEach(function (it) {
      var c = computeLine(it);
      grossTotal += c.gross;
      discountTotal += c.discountAmt;
      taxable += c.taxable;
      if (inter) { igst += c.gst; }
      else { cgst += c.gst / 2; sgst += c.gst / 2; }
      var r = num(it.gstRate);
      byRate[r] = round2((byRate[r] || 0) + c.taxable);
    });
    var taxTotal = cgst + sgst + igst;
    var beforeRound = taxable + taxTotal;
    var grand = (opts.roundOff === false) ? beforeRound : Math.round(beforeRound);
    return {
      interState: inter,
      grossTotal: round2(grossTotal),
      discountTotal: round2(discountTotal),
      taxable: round2(taxable),
      cgst: round2(cgst),
      sgst: round2(sgst),
      igst: round2(igst),
      taxTotal: round2(taxTotal),
      roundOff: round2(grand - beforeRound),
      grandTotal: round2(grand),
      byRate: byRate
    };
  }

  /* ---------------- amount in words (Indian system) ---------------- */
  var ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen'];
  var TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy',
    'Eighty', 'Ninety'];

  function twoDigit(n) {
    n = Math.floor(n);
    if (n < 20) return ONES[n];
    var t = Math.floor(n / 10), o = n % 10;
    return TENS[t] + (o ? ' ' + ONES[o] : '');
  }

  function wordsUpTo999(n) {
    n = Math.floor(n);
    var out = '';
    var h = Math.floor(n / 100), r = n % 100;
    if (h) { out += ONES[h] + ' Hundred'; if (r) out += ' '; }
    if (r) { out += twoDigit(r); }
    return out.trim();
  }

  function numToWords(n) {
    n = Math.floor(num(n));
    if (n === 0) return 'Zero';
    var crore = Math.floor(n / 10000000); n = n % 10000000;
    var lakh = Math.floor(n / 100000); n = n % 100000;
    var thousand = Math.floor(n / 1000); n = n % 1000;
    var parts = [];
    if (crore) parts.push(wordsUpTo999(crore) + ' Crore');
    if (lakh) parts.push(wordsUpTo999(lakh) + ' Lakh');
    if (thousand) parts.push(wordsUpTo999(thousand) + ' Thousand');
    if (n) parts.push(wordsUpTo999(n));
    return parts.join(' ').replace(/\s+/g, ' ').trim();
  }

  function inWordsIndian(amount) {
    var a = round2(num(amount));
    if (a === 0) return 'Zero Rupees Only';
    var neg = a < 0; a = Math.abs(a);
    var rupees = Math.floor(a);
    var paise = Math.round((a - rupees) * 100);
    var out = rupees ? numToWords(rupees) + (rupees === 1 ? ' Rupee' : ' Rupees') : '';
    if (paise > 0) { out += (out ? ' and ' : '') + numToWords(paise) + (paise === 1 ? ' Paisa' : ' Paise'); }
    return (neg ? 'Minus ' : '') + (out || 'Zero Rupees') + ' Only';
  }

  /* ---------------- GSTIN validation ---------------- */
  var GSTIN_RE = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;

  function validateGSTIN(gstin) {
    gstin = String(gstin || '').trim().toUpperCase();
    if (!gstin) return { valid: false, reason: 'empty' };
    if (gstin.length !== 15) return { valid: false, reason: 'length' };
    if (!GSTIN_RE.test(gstin)) return { valid: false, reason: 'format' };
    return { valid: true, reason: 'ok' };
  }

  /* ---------------- helpers used by the UI ---------------- */
  function todayISO() {
    var d = new Date();
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var day = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + m + '-' + day;
  }

  function fmtMoney(n) {
    n = round2(n);
    var s = n.toFixed(2);
    var parts = s.split('.');
    var whole = parts[0];
    var last3 = whole.slice(-3);
    var rest = whole.slice(0, -3);
    if (rest) { rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ','); last3 = ',' + last3; }
    return rest + last3 + '.' + parts[1];
  }

  /* ==================================================================
     2. THE BROWSER APP  (only runs when a DOM exists)
     ================================================================== */
  if (typeof document === 'undefined') {
    if (typeof module !== 'undefined' && module.exports) {
      module.exports = {
        GST_RATES: GST_RATES, num: num, round2: round2,
        computeLine: computeLine, isInterState: isInterState,
        computeTotals: computeTotals, numToWords: numToWords,
        inWordsIndian: inWordsIndian, validateGSTIN: validateGSTIN,
        fmtMoney: fmtMoney, todayISO: todayISO
      };
    }
    return;
  }

  /* ---------------- states of India ---------------- */
  var STATES = [
    ['01', 'Jammu & Kashmir'], ['02', 'Himachal Pradesh'], ['03', 'Punjab'],
    ['04', 'Chandigarh'], ['05', 'Uttarakhand'], ['06', 'Haryana'], ['07', 'Delhi'],
    ['08', 'Rajasthan'], ['09', 'Uttar Pradesh'], ['10', 'Bihar'], ['11', 'Sikkim'],
    ['12', 'Arunachal Pradesh'], ['13', 'Nagaland'], ['14', 'Manipur'],
    ['15', 'Mizoram'], ['16', 'Tripura'], ['17', 'Meghalaya'], ['18', 'Assam'],
    ['19', 'West Bengal'], ['20', 'Jharkhand'], ['21', 'Odisha'],
    ['22', 'Chhattisgarh'], ['23', 'Madhya Pradesh'], ['24', 'Gujarat'],
    ['26', 'Dadra & Nagar Haveli and Daman & Diu'], ['27', 'Maharashtra'],
    ['29', 'Karnataka'], ['30', 'Goa'], ['31', 'Lakshadweep'], ['32', 'Kerala'],
    ['33', 'Tamil Nadu'], ['34', 'Puducherry'], ['35', 'Andaman & Nicobar Islands'],
    ['36', 'Telangana'], ['37', 'Andhra Pradesh'], ['38', 'Ladakh'],
    ['97', 'Other Territory']
  ];

  /* ---------------- storage ---------------- */
  var KEY = { profile: 'dkgst_profile_v1', clients: 'dkgst_clients_v1', docs: 'dkgst_docs_v1' };

  function load(key, fallback) {
    try { var raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
    catch (e) { return fallback; }
  }
  function save(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); return true; }
    catch (e) { return false; }
  }

  var state = {
    profile: load(KEY.profile, defaultProfile()),
    clients: load(KEY.clients, []),
    docs: load(KEY.docs, []),
    editingId: null,
    items: []
  };

  function defaultProfile() {
    return {
      name: '', gstin: '', address: '', state: '', phone: '', email: '',
      logo: '', bank: '', upi: '', prefix: 'INV-', nextNumber: 1,
      defaultGst: 18, terms: 'Payment due within 15 days. Goods once sold will not be taken back.',
      roundOff: true, showLogo: true
    };
  }

  function uid() { return 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

  /* ---------------- tiny DOM helpers ---------------- */
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function nl2br(s) { return esc(s).replace(/\n/g, '<br>'); }
  function el(tag, attrs, html) {
    var n = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      if (k === 'class') n.className = attrs[k];
      else if (k === 'html') n.innerHTML = attrs[k];
      else n.setAttribute(k, attrs[k]);
    });
    if (html != null) n.innerHTML = html;
    return n;
  }
  function stateName(code) {
    for (var i = 0; i < STATES.length; i++) if (STATES[i][0] === code) return STATES[i][1];
    return '';
  }

  /* ---------------- toast ---------------- */
  var toastTimer = null;
  function toast(msg, kind) {
    var t = $('#toast');
    t.textContent = msg;
    t.className = 'toast show' + (kind ? ' ' + kind : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.className = 'toast'; }, 2600);
  }

  /* ---------------- tabs ---------------- */
  function showTab(name) {
    $$('.tab-panel').forEach(function (p) { p.classList.toggle('active', p.id === 'tab-' + name); });
    $$('.navtab').forEach(function (b) { b.classList.toggle('active', b.dataset.tab === name); });
    if (name === 'saved') renderSaved();
    if (name === 'clients') renderClients();
    if (name === 'settings') fillSettings();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ================= CREATE TAB ================= */
  function addItemRow(item) {
    item = item || { desc: '', hsn: '', qty: 1, rate: '', discount: 0, gstRate: state.profile.defaultGst };
    state.items.push(item);
    renderItems();
  }

  function renderItems() {
    var tb = $('#itemsBody');
    tb.innerHTML = '';
    state.items.forEach(function (it, idx) {
      var c = computeLine(it);
      var tr = el('tr', { 'data-idx': idx });
      tr.innerHTML =
        '<td><input class="in-desc" value="' + esc(it.desc) + '" placeholder="Service or goods description" aria-label="Description"></td>' +
        '<td><input class="in-hsn" value="' + esc(it.hsn) + '" placeholder="9983" aria-label="HSN or SAC"></td>' +
        '<td><input class="in-qty num" type="number" min="0" step="any" value="' + esc(it.qty) + '" aria-label="Quantity"></td>' +
        '<td><input class="in-rate num" type="number" min="0" step="any" value="' + esc(it.rate) + '" placeholder="0.00" aria-label="Rate"></td>' +
        '<td><input class="in-disc num" type="number" min="0" max="100" step="any" value="' + esc(it.discount) + '" aria-label="Discount percent"></td>' +
        '<td><select class="in-gst" aria-label="GST rate">' +
        GST_RATES.map(function (r) {
          return '<option value="' + r + '"' + (num(it.gstRate) === r ? ' selected' : '') + '>' + r + '%</option>';
        }).join('') + '</select></td>' +
        '<td class="amt">' + fmtMoney(c.total) + '</td>' +
        '<td class="rowdel"><button type="button" class="icon-btn del" title="Remove line" aria-label="Remove line">&#10005;</button></td>';
      tb.appendChild(tr);
    });
    if (!state.items.length) {
      tb.innerHTML = '<tr class="empty-row"><td colspan="8">No line items yet — click “Add line item”.</td></tr>';
    }
    recalc();
  }

  function syncItemsFromDOM() {
    $$('#itemsBody tr[data-idx]').forEach(function (tr) {
      var idx = parseInt(tr.dataset.idx, 10);
      var it = state.items[idx];
      if (!it) return;
      it.desc = $('.in-desc', tr).value;
      it.hsn = $('.in-hsn', tr).value;
      it.qty = $('.in-qty', tr).value;
      it.rate = $('.in-rate', tr).value;
      it.discount = $('.in-disc', tr).value;
      it.gstRate = $('.in-gst', tr).value;
    });
  }

  function currentDoc() {
    var d = {
      id: state.editingId || uid(),
      type: $('input[name="docType"]:checked').value,
      number: $('#invNumber').value.trim(),
      date: $('#invDate').value,
      dueDate: $('#dueDate').value,
      placeOfSupply: $('#placeOfSupply').value,
      client: readClientForm(),
      items: state.items.map(function (it) { return Object.assign({}, it); }),
      notes: $('#notes').value,
      terms: $('#terms').value,
      createdAt: (state.editingId ? (findDoc(state.editingId) || {}).createdAt : null) || new Date().toISOString(),
      status: (state.editingId ? (findDoc(state.editingId) || {}).status : null) || 'Unpaid'
    };
    return d;
  }

  function findDoc(id) { for (var i = 0; i < state.docs.length; i++) if (state.docs[i].id === id) return state.docs[i]; return null; }

  function readClientForm() {
    return {
      name: $('#clName').value.trim(),
      gstin: $('#clGstin').value.trim().toUpperCase(),
      address: $('#clAddress').value.trim(),
      state: $('#clState').value,
      phone: $('#clPhone').value.trim(),
      email: $('#clEmail').value.trim()
    };
  }

  function writeClientForm(c) {
    c = c || {};
    $('#clName').value = c.name || '';
    $('#clGstin').value = c.gstin || '';
    $('#clAddress').value = c.address || '';
    $('#clState').value = c.state || '';
    $('#clPhone').value = c.phone || '';
    $('#clEmail').value = c.email || '';
  }

  function recalc() {
    syncItemsFromDOM();
    var bizState = state.profile.state;
    var pos = $('#placeOfSupply').value;
    var t = computeTotals(state.items, bizState, pos, { roundOff: state.profile.roundOff });
    $('#tTaxable').textContent = '₹' + fmtMoney(t.taxable);
    $('#tDisc').textContent = '₹' + fmtMoney(t.discountTotal);
    $('#tDiscRow').style.display = t.discountTotal > 0 ? '' : 'none';
    var taxLabel = t.interState ? 'IGST' : 'CGST';
    var taxLabel2 = t.interState ? '' : 'SGST';
    $('#tCgstLabel').textContent = taxLabel;
    $('#tCgst').textContent = '₹' + fmtMoney(t.interState ? t.igst : t.cgst);
    $('#tSgstRow').style.display = t.interState ? 'none' : '';
    $('#tSgst').textContent = '₹' + fmtMoney(t.sgst);
    $('#tRoundRow').style.display = t.roundOff ? '' : 'none';
    $('#tRound').textContent = (t.roundOff >= 0 ? '+' : '−') + '₹' + fmtMoney(Math.abs(t.roundOff));
    $('#tGrand').textContent = '₹' + fmtMoney(t.grandTotal);
    $('#words').textContent = inWordsIndian(t.grandTotal);
    var badge = $('#supplyBadge');
    badge.textContent = t.interState ? 'Inter-state supply · IGST' : (pos ? 'Intra-state supply · CGST + SGST' : 'Choose a place of supply');
    badge.className = 'badge ' + (t.interState ? 'inter' : 'intra');
    $$('#itemsBody tr[data-idx]').forEach(function (tr) {
      var idx = parseInt(tr.dataset.idx, 10);
      var c = computeLine(state.items[idx]);
      $('.amt', tr).textContent = fmtMoney(c.total);
    });
    return t;
  }

  function saveInvoice() {
    var d = currentDoc();
    if (!d.items.length) { toast('Add at least one line item first.', 'warn'); return; }
    var bad = d.items.some(function (it) { return !String(it.desc).trim(); });
    if (bad) { toast('Every line needs a description.', 'warn'); return; }
    if (!d.number) { toast('Give this document a number.', 'warn'); return; }
    if (!d.client.name) { toast('Add the client name.', 'warn'); return; }
    var existing = findDoc(d.id);
    if (existing) {
      Object.keys(d).forEach(function (k) { existing[k] = d[k]; });
      toast('Document updated.', 'ok');
    } else {
      state.docs.unshift(d);
      toast('Document saved.', 'ok');
    }
    // bump auto number if we used the suggested one
    var suggested = suggestedNumber(d.type);
    if (d.number === suggested) {
      state.profile.nextNumber = num(state.profile.nextNumber) + 1;
      save(KEY.profile, state.profile);
    }
    save(KEY.docs, state.docs);
    state.editingId = d.id;
    renderSaved();
    showTab('saved');
  }

  function suggestedNumber(type) {
    var prefix = (state.profile.prefix || 'INV-');
    if (type === 'Quotation') prefix = prefix.replace(/INV/i, 'QTN');
    var n = String(num(state.profile.nextNumber)).padStart(3, '0');
    return prefix + n;
  }

  function newInvoice() {
    state.editingId = null;
    state.items = [];
    var type = 'Tax Invoice';
    $$('input[name="docType"]').forEach(function (r) { r.checked = (r.value === type); });
    $('#invNumber').value = suggestedNumber(type);
    $('#invDate').value = todayISO();
    $('#dueDate').value = '';
    $('#placeOfSupply').value = state.profile.state || '';
    writeClientForm({ state: state.profile.state || '' });
    $('#notes').value = '';
    $('#terms').value = state.profile.terms || '';
    addItemRow();
    recalc();
  }

  function loadDocIntoForm(id) {
    var d = findDoc(id);
    if (!d) return;
    state.editingId = d.id;
    $$('input[name="docType"]').forEach(function (r) { r.checked = (r.value === d.type); });
    $('#invNumber').value = d.number;
    $('#invDate').value = d.date;
    $('#dueDate').value = d.dueDate || '';
    $('#placeOfSupply').value = d.placeOfSupply || '';
    writeClientForm(d.client);
    state.items = d.items.map(function (it) { return Object.assign({}, it); });
    $('#notes').value = d.notes || '';
    $('#terms').value = d.terms || '';
    renderItems();
    showTab('create');
  }

  function loadSample() {
    state.editingId = null;
    var p = state.profile;
    if (!p.name) {
      toast('Tip: set your business details in Settings first — showing a sample with example data.', 'warn');
    }
    $$('input[name="docType"]').forEach(function (r) { r.checked = (r.value === 'Tax Invoice'); });
    $('#invNumber').value = 'INV-001';
    $('#invDate').value = todayISO();
    var dd = new Date(); dd.setDate(dd.getDate() + 15);
    $('#dueDate').value = dd.toISOString().slice(0, 10);
    var bizState = p.state || '27';
    $('#placeOfSupply').value = bizState;
    writeClientForm({
      name: 'Sunrise Traders (EXAMPLE)', gstin: '27ABCDE1234F1Z5',
      address: '12, Market Road, Andheri East, Mumbai 400069',
      state: bizState, phone: '+91 90000 00000', email: 'client@example.com'
    });
    state.items = [
      { desc: 'Website design — home page (EXAMPLE)', hsn: '998314', qty: 1, rate: 25000, discount: 10, gstRate: 18 },
      { desc: 'Annual hosting & maintenance (EXAMPLE)', hsn: '998315', qty: 1, rate: 6000, discount: 0, gstRate: 18 }
    ];
    $('#notes').value = 'Thank you for your business. This is clearly-labelled example data.';
    $('#terms').value = p.terms || '';
    renderItems();
    toast('Sample loaded — replace every EXAMPLE line with your own.', 'ok');
  }

  /* ================= PRINT / PDF ================= */
  function buildInvoiceHTML(d) {
    var p = state.profile;
    var t = computeTotals(d.items, p.state, d.placeOfSupply, { roundOff: p.roundOff });
    var title = d.type === 'Quotation' ? 'QUOTATION' : 'TAX INVOICE';
    var rows = d.items.map(function (it, i) {
      var c = computeLine(it);
      return '<tr>' +
        '<td class="c">' + (i + 1) + '</td>' +
        '<td>' + nl2br(it.desc) + (it.hsn ? '<div class="mut">HSN/SAC: ' + esc(it.hsn) + '</div>' : '') + '</td>' +
        '<td class="r">' + esc(num(it.qty)) + '</td>' +
        '<td class="r">' + fmtMoney(it.rate) + '</td>' +
        '<td class="r">' + (num(it.discount) ? num(it.discount) + '%' : '—') + '</td>' +
        '<td class="r">' + fmtMoney(c.taxable) + '</td>' +
        '<td class="r">' + esc(num(it.gstRate)) + '%</td>' +
        '<td class="r">' + fmtMoney(c.gst) + '</td>' +
        '<td class="r">' + fmtMoney(c.total) + '</td>' +
        '</tr>';
    }).join('');
    var logo = (p.showLogo && p.logo) ? '<img src="' + p.logo + '" alt="Business logo" class="inv-logo">' : '';
    var taxRows = t.interState
      ? '<tr><td>IGST</td><td class="r">' + fmtMoney(t.igst) + '</td></tr>'
      : '<tr><td>CGST</td><td class="r">' + fmtMoney(t.cgst) + '</td></tr><tr><td>SGST</td><td class="r">' + fmtMoney(t.sgst) + '</td></tr>';
    return '' +
      '<div class="inv">' +
      '<div class="inv-head">' +
      '<div class="inv-biz">' + logo + '<h2>' + esc(p.name || 'Your Business Name') + '</h2>' +
      (p.address ? '<p>' + nl2br(p.address) + '</p>' : '') +
      (p.state ? '<p>State: ' + esc(stateName(p.state)) + ' (' + esc(p.state) + ')</p>' : '') +
      (p.gstin ? '<p><strong>GSTIN:</strong> ' + esc(p.gstin) + '</p>' : '') +
      (p.phone ? '<p>Phone: ' + esc(p.phone) + '</p>' : '') +
      (p.email ? '<p>Email: ' + esc(p.email) + '</p>' : '') +
      '</div>' +
      '<div class="inv-meta">' +
      '<h1>' + title + '</h1>' +
      '<table class="meta-tbl">' +
      '<tr><td>Number</td><td class="r"><strong>' + esc(d.number) + '</strong></td></tr>' +
      '<tr><td>Date</td><td class="r">' + esc(fmtDate(d.date)) + '</td></tr>' +
      (d.dueDate ? '<tr><td>' + (d.type === 'Quotation' ? 'Valid till' : 'Due date') + '</td><td class="r">' + esc(fmtDate(d.dueDate)) + '</td></tr>' : '') +
      '<tr><td>Place of supply</td><td class="r">' + esc(stateName(d.placeOfSupply) || '—') + '</td></tr>' +
      '</table>' +
      '</div></div>' +
      '<div class="inv-parties">' +
      '<div><div class="lbl">Bill to</div>' +
      '<p class="strong">' + esc(d.client.name || '—') + '</p>' +
      (d.client.address ? '<p>' + nl2br(d.client.address) + '</p>' : '') +
      (d.client.state ? '<p>' + esc(stateName(d.client.state)) + '</p>' : '') +
      (d.client.gstin ? '<p>GSTIN: ' + esc(d.client.gstin) + '</p>' : '') +
      (d.client.phone ? '<p>Phone: ' + esc(d.client.phone) + '</p>' : '') +
      '</div>' +
      '<div class="inv-taxmode"><div class="lbl">Supply type</div><p>' +
      (t.interState ? 'Inter-state (IGST)' : 'Intra-state (CGST + SGST)') + '</p></div>' +
      '</div>' +
      '<table class="inv-tbl"><thead><tr>' +
      '<th class="c">#</th><th>Description</th><th class="r">Qty</th><th class="r">Rate</th>' +
      '<th class="r">Disc</th><th class="r">Taxable</th><th class="r">GST</th><th class="r">Tax</th><th class="r">Amount</th>' +
      '</tr></thead><tbody>' + rows + '</tbody></table>' +
      '<div class="inv-foot">' +
      '<div class="inv-notes">' +
      (d.notes ? '<div class="lbl">Notes</div><p>' + nl2br(d.notes) + '</p>' : '') +
      (d.terms ? '<div class="lbl">Terms &amp; conditions</div><p>' + nl2br(d.terms) + '</p>' : '') +
      ((p.bank || p.upi) ? '<div class="lbl">Payment</div><p>' +
        (p.bank ? 'Bank: ' + nl2br(p.bank) + '<br>' : '') +
        (p.upi ? 'UPI: ' + esc(p.upi) : '') + '</p>' : '') +
      '</div>' +
      '<div class="inv-totals">' +
      '<table>' +
      '<tr><td>Taxable value</td><td class="r">' + fmtMoney(t.taxable) + '</td></tr>' +
      taxRows +
      (t.roundOff ? '<tr><td>Round off</td><td class="r">' + (t.roundOff >= 0 ? '+' : '−') + fmtMoney(Math.abs(t.roundOff)) + '</td></tr>' : '') +
      '<tr class="grand"><td>Grand total</td><td class="r">₹' + fmtMoney(t.grandTotal) + '</td></tr>' +
      '</table>' +
      '<p class="words"><strong>In words:</strong> ' + esc(inWordsIndian(t.grandTotal)) + '</p>' +
      '</div></div>' +
      '<div class="inv-sign"><div><div class="signline"></div>Authorised signatory</div><div class="inv-brand">Generated with GST Invoice Generator Pro · Digitalaikart</div></div>' +
      '</div>';
  }

  function fmtDate(iso) {
    if (!iso) return '—';
    var p = iso.split('-');
    if (p.length !== 3) return iso;
    return p[2] + '-' + p[1] + '-' + p[0];
  }

  function printDoc(d) {
    if (!d) { toast('Nothing to print yet.', 'warn'); return; }
    $('#printArea').innerHTML = buildInvoiceHTML(d);
    document.body.classList.add('printing');
    setTimeout(function () { window.print(); }, 60);
  }

  /* ================= SAVED TAB ================= */
  function renderSaved() {
    var docs = state.docs;
    var totals = { invoiced: 0, paid: 0, outstanding: 0, count: docs.length };
    docs.forEach(function (d) {
      if (d.type !== 'Tax Invoice') return;
      var t = computeTotals(d.items, state.profile.state, d.placeOfSupply, { roundOff: state.profile.roundOff });
      totals.invoiced += t.grandTotal;
      if (d.status === 'Paid') totals.paid += t.grandTotal; else totals.outstanding += t.grandTotal;
    });
    $('#dashInvoiced').textContent = '₹' + fmtMoney(totals.invoiced);
    $('#dashPaid').textContent = '₹' + fmtMoney(totals.paid);
    $('#dashOut').textContent = '₹' + fmtMoney(totals.outstanding);
    $('#dashCount').textContent = totals.count;

    var body = $('#savedBody');
    body.innerHTML = '';
    if (!docs.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="7">No saved documents yet. Create one and press “Save document”.</td></tr>';
      return;
    }
    docs.forEach(function (d) {
      var t = computeTotals(d.items, state.profile.state, d.placeOfSupply, { roundOff: state.profile.roundOff });
      var tr = el('tr');
      tr.innerHTML =
        '<td><strong>' + esc(d.number) + '</strong><div class="mut">' + esc(d.type) + '</div></td>' +
        '<td>' + esc(fmtDate(d.date)) + '</td>' +
        '<td>' + esc(d.client.name || '—') + '</td>' +
        '<td class="r">₹' + fmtMoney(t.grandTotal) + '</td>' +
        '<td><span class="pill ' + (d.status === 'Paid' ? 'paid' : 'due') + '">' + esc(d.status) + '</span></td>' +
        '<td class="rowacts">' +
        '<button class="icon-btn" data-act="view" data-id="' + d.id + '" title="Open">Open</button>' +
        '<button class="icon-btn" data-act="print" data-id="' + d.id + '" title="Print">Print</button>' +
        '<button class="icon-btn" data-act="paid" data-id="' + d.id + '" title="Toggle paid">' + (d.status === 'Paid' ? 'Mark unpaid' : 'Mark paid') + '</button>' +
        '<button class="icon-btn del" data-act="del" data-id="' + d.id + '" title="Delete">Delete</button>' +
        '</td>';
      body.appendChild(tr);
    });
  }

  /* ================= CLIENTS TAB ================= */
  function renderClients() {
    var body = $('#clientsBody');
    body.innerHTML = '';
    if (!state.clients.length) {
      body.innerHTML = '<tr class="empty-row"><td colspan="4">No saved clients yet.</td></tr>';
      return;
    }
    state.clients.forEach(function (c, i) {
      var tr = el('tr');
      tr.innerHTML =
        '<td><strong>' + esc(c.name) + '</strong></td>' +
        '<td>' + esc(c.gstin || '—') + '</td>' +
        '<td>' + esc(stateName(c.state) || '—') + '</td>' +
        '<td class="rowacts">' +
        '<button class="icon-btn" data-act="use" data-idx="' + i + '">Use</button>' +
        '<button class="icon-btn del" data-act="del" data-idx="' + i + '">Delete</button>' +
        '</td>';
      body.appendChild(tr);
    });
  }

  function refreshClientSelect() {
    var sel = $('#clientPicker');
    sel.innerHTML = '<option value="">— New / typed client —</option>' +
      state.clients.map(function (c, i) { return '<option value="' + i + '">' + esc(c.name) + '</option>'; }).join('');
  }

  /* ================= SETTINGS TAB ================= */
  function fillSettings() {
    var p = state.profile;
    $('#bizName').value = p.name; $('#bizGstin').value = p.gstin;
    $('#bizAddress').value = p.address; $('#bizState').value = p.state;
    $('#bizPhone').value = p.phone; $('#bizEmail').value = p.email;
    $('#bizBank').value = p.bank; $('#bizUpi').value = p.upi;
    $('#bizPrefix').value = p.prefix; $('#bizNext').value = p.nextNumber;
    $('#bizDefaultGst').value = p.defaultGst; $('#bizTerms').value = p.terms;
    $('#bizRound').checked = !!p.roundOff; $('#bizShowLogo').checked = !!p.showLogo;
    $('#logoState').textContent = p.logo ? 'Logo set' : 'No logo';
    if (p.state) $('#placeOfSupply').value = p.state;
  }

  function readSettings() {
    var p = state.profile;
    p.name = $('#bizName').value.trim();
    p.gstin = $('#bizGstin').value.trim().toUpperCase();
    p.address = $('#bizAddress').value.trim();
    p.state = $('#bizState').value;
    p.phone = $('#bizPhone').value.trim();
    p.email = $('#bizEmail').value.trim();
    p.bank = $('#bizBank').value.trim();
    p.upi = $('#bizUpi').value.trim();
    p.prefix = $('#bizPrefix').value.trim() || 'INV-';
    p.nextNumber = num($('#bizNext').value) || 1;
    p.defaultGst = num($('#bizDefaultGst').value);
    p.terms = $('#bizTerms').value;
    p.roundOff = $('#bizRound').checked;
    p.showLogo = $('#bizShowLogo').checked;
    var g = p.gstin;
    if (g && !validateGSTIN(g).valid) toast('Heads-up: that GSTIN does not look valid — check it.', 'warn');
    save(KEY.profile, p);
    toast('Business details saved.', 'ok');
  }

  function exportBackup() {
    var data = { app: 'gst-invoice-generator-pro', version: 1, exportedAt: new Date().toISOString(), profile: state.profile, clients: state.clients, docs: state.docs };
    var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'gst-invoice-backup-' + todayISO() + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    toast('Backup downloaded.', 'ok');
  }

  function importBackup(file) {
    var r = new FileReader();
    r.onload = function () {
      try {
        var data = JSON.parse(r.result);
        if (data.profile) state.profile = data.profile;
        if (Array.isArray(data.clients)) state.clients = data.clients;
        if (Array.isArray(data.docs)) state.docs = data.docs;
        save(KEY.profile, state.profile); save(KEY.clients, state.clients); save(KEY.docs, state.docs);
        refreshClientSelect(); fillSettings(); renderSaved(); renderClients();
        toast('Backup restored.', 'ok');
      } catch (e) { toast('That file could not be read as a backup.', 'warn'); }
    };
    r.readAsText(file);
  }

  function readLogo(file) {
    if (file.size > 400 * 1024) { toast('Please use a logo under 400 KB.', 'warn'); return; }
    var r = new FileReader();
    r.onload = function () { state.profile.logo = r.result; save(KEY.profile, state.profile); $('#logoState').textContent = 'Logo set'; toast('Logo added.', 'ok'); };
    r.readAsDataURL(file);
  }

  /* ================= WIRING ================= */
  function wire() {
    $$('.navtab').forEach(function (b) { b.addEventListener('click', function () { showTab(b.dataset.tab); }); });
    $$('input[name="docType"]').forEach(function (r) {
      r.addEventListener('change', function () { if (!state.editingId) $('#invNumber').value = suggestedNumber(r.value); });
    });
    $('#addLine').addEventListener('click', function () { syncItemsFromDOM(); addItemRow(); });
    $('#itemsBody').addEventListener('input', function (e) {
      if (e.target.classList.contains('in-gst') || e.target.classList.contains('in-qty') ||
        e.target.classList.contains('in-rate') || e.target.classList.contains('in-disc')) recalc();
    });
    $('#itemsBody').addEventListener('click', function (e) {
      var btn = e.target.closest('.del');
      if (!btn) return;
      var tr = btn.closest('tr'); syncItemsFromDOM();
      state.items.splice(parseInt(tr.dataset.idx, 10), 1); renderItems();
    });
    ['#placeOfSupply', '#invDate', '#dueDate', '#notes', '#terms'].forEach(function (s) {
      $(s).addEventListener('change', recalc); $(s).addEventListener('input', recalc);
    });
    $('#saveDoc').addEventListener('click', saveInvoice);
    $('#printDoc').addEventListener('click', function () { syncItemsFromDOM(); printDoc(currentDoc()); });
    $('#newDoc').addEventListener('click', newInvoice);
    $('#sampleBtn').addEventListener('click', loadSample);
    $('#clientPicker').addEventListener('change', function () {
      var i = this.value;
      if (i === '') return;
      writeClientForm(state.clients[parseInt(i, 10)]);
      recalc();
    });
    $('#saveClientBtn').addEventListener('click', function () {
      var c = readClientForm();
      if (!c.name) { toast('Client name is required to save.', 'warn'); return; }
      state.clients.push(c); save(KEY.clients, state.clients); refreshClientSelect(); renderClients();
      toast('Client saved.', 'ok');
    });
    $('#savedBody').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-act]'); if (!b) return;
      var id = b.dataset.id, act = b.dataset.act, d = findDoc(id); if (!d) return;
      if (act === 'view') loadDocIntoForm(id);
      else if (act === 'print') printDoc(d);
      else if (act === 'paid') { d.status = d.status === 'Paid' ? 'Unpaid' : 'Paid'; save(KEY.docs, state.docs); renderSaved(); }
      else if (act === 'del') { if (confirm('Delete ' + d.number + '? This cannot be undone.')) { state.docs = state.docs.filter(function (x) { return x.id !== id; }); save(KEY.docs, state.docs); renderSaved(); } }
    });
    $('#clientsBody').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-act]'); if (!b) return;
      var i = parseInt(b.dataset.idx, 10);
      if (b.dataset.act === 'use') { writeClientForm(state.clients[i]); showTab('create'); toast('Client loaded into the form.', 'ok'); }
      else if (b.dataset.act === 'del') { state.clients.splice(i, 1); save(KEY.clients, state.clients); refreshClientSelect(); renderClients(); }
    });
    $('#saveSettings').addEventListener('click', function () { readSettings(); refreshClientSelect(); });
    $('#exportBtn').addEventListener('click', exportBackup);
    $('#importInput').addEventListener('change', function () { if (this.files[0]) importBackup(this.files[0]); this.value = ''; });
    $('#logoInput').addEventListener('change', function () { if (this.files[0]) readLogo(this.files[0]); this.value = ''; });
    $('#clearLogo').addEventListener('click', function () { state.profile.logo = ''; save(KEY.profile, state.profile); $('#logoState').textContent = 'No logo'; toast('Logo removed.', 'ok'); });
    $('#gstinCheck').addEventListener('click', function () {
      var v = validateGSTIN($('#bizGstin').value);
      toast(v.valid ? 'GSTIN format looks valid.' : 'GSTIN problem: ' + v.reason + '.', v.valid ? 'ok' : 'warn');
    });
    $('#clGstinCheck').addEventListener('click', function () {
      var v = validateGSTIN($('#clGstin').value);
      toast(v.valid ? 'Client GSTIN format looks valid.' : 'Client GSTIN problem: ' + v.reason + '.', v.valid ? 'ok' : 'warn');
    });
    document.addEventListener('keydown', function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key === 'p') { /* let the print stylesheet handle it */ }
    });
    window.addEventListener('afterprint', function () { document.body.classList.remove('printing'); });
  }

  /* ================= BOOT ================= */
  function init() {
    var stateOpts = STATES.map(function (s) { return '<option value="' + s[0] + '">' + esc(s[1]) + '</option>'; }).join('');
    $('#bizState').innerHTML = '<option value="">— Select state —</option>' + stateOpts;
    $('#clState').innerHTML = '<option value="">— Select state —</option>' + stateOpts;
    $('#placeOfSupply').innerHTML = '<option value="">— Select place of supply —</option>' + stateOpts;
    $('#bizDefaultGst').innerHTML = GST_RATES.map(function (r) { return '<option value="' + r + '">' + r + '%</option>'; }).join('');
    $('#year').textContent = new Date().getFullYear();
    refreshClientSelect();
    wire();
    newInvoice();
    showTab('create');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
