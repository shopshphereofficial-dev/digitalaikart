# GST Invoice Generator Pro

**Offline invoicing for Indian freelancers, consultants and small businesses.**
Create GST-compliant tax invoices and quotations, print them, or save them as PDF — all
inside your own browser, with no sign-up, no server and no monthly fee.

Version 1.0 · © 2026 Digitalaikart · Sold as a digital product.

---

## 1. What is in this pack

```
gst-invoice-generator-pro/
├── index.html                     ← open this to start (double-click it)
├── assets/
│   ├── app.js                     ← the application logic
│   └── styles.css                 ← the design
├── sample-client-data.json        ← an optional example backup you can import
├── README.md                      ← this file
└── LICENSE.txt                    ← your licence to use the tool
```

Everything is plain HTML, CSS and JavaScript. There is no installer, no admin rights,
and no internet connection is required.

---

## 2. Getting started (2 minutes)

1. **Unzip** the folder somewhere you will keep it (for example `Documents/GST Invoicing`).
2. **Double-click `index.html`.** It opens in your default browser (Chrome, Edge, Firefox or Safari).
3. Click **Settings** and fill in your business details — name, address, home state, GSTIN
   (if you are registered), phone, email, bank/UPI details and your invoice number prefix.
   Click **Save business details**.
4. Go to **Create**, add your line items, and press **Save document**, then
   **Print / Save as PDF**.

That is it. You can keep the tab open like an app, or bookmark the file.

> **Keep the folder together.** `index.html` needs the `assets` folder next to it. If you
> move `index.html` on its own, the page will open unstyled and empty.

---

## 3. Creating an invoice step by step

1. **Type** — choose *Tax Invoice* or *Quotation*. The number updates automatically from
   your settings (for example `INV-001`).
2. **Date / Due date** — today's date is filled in. A quotation shows “Valid till” instead of “Due date”.
3. **Place of supply** — pick the state the supply is for. The tool then decides the tax:
   - **Same state as you → CGST + SGST** (split equally), or
   - **Different state → IGST**.
   You will see an *Intra-state* or *Inter-state* badge confirm it.
4. **Bill to** — type the client's details, or load a saved client. If you type a new client
   you can press **Save this client** to reuse them next time.
5. **Line items** — add a row per item or service:
   - **Description** — what you supplied.
   - **HSN/SAC** — the code (SAC for services, e.g. `998314`; HSN for goods).
   - **Qty** and **Rate ₹**.
   - **Disc %** — a percentage discount on that line.
   - **GST** — the rate for that line (0, 0.25, 3, 5, 12, 18 or 28%).
6. **Summary panel** shows the taxable value, the tax split, the round-off and the grand
   total, plus the **amount in words** in the Indian lakh/crore style.
7. Press **Save document** to store it, then **Print / Save as PDF**.

### Getting a PDF
Click **Print / Save as PDF**, then in the browser's print dialog set the destination to
**Save as PDF** (Chrome/Edge) or **Save to PDF** (Firefox/Safari). The print layout is a
clean white A4 invoice — the coloured app interface is not printed.

---

## 4. Documents, clients and the dashboard

- **Documents** tab lists everything you saved, with a dashboard of total invoiced, paid
  and outstanding amounts.
- Use **Mark paid / Mark unpaid** to track collections. Only *Tax Invoices* count towards
  the money totals; quotations are listed but not counted.
- **Open** loads a document back into the form to edit or reprint; **Delete** removes it
  (you will be asked to confirm).
- **Clients** tab holds your client book — **Use** drops a client into a new document.

---

## 5. Your data and backups

Your business details, clients and documents are stored in **your browser's local storage**.
Nothing is uploaded anywhere — the tool works with the internet switched off.

Because there is no cloud copy, **take a backup**:

- Go to **Settings → Export backup (JSON)** and keep the file somewhere safe.
- To restore, use **Settings → Import backup** and pick that JSON file.
- A sample backup (`sample-client-data.json`) is included — import it to see the tool with
  example data before you enter your own. **Its contents are clearly-labelled examples only.**

Two honest caveats:

- Browser storage is per browser and per device, and clearing site data or using a private
  window can empty it. Your JSON export is the recovery plan.
- There is no sync between devices. Move data with the JSON export/import.

---

## 6. Validation, rates and rules

- The **Check** buttons validate the *format* of a GSTIN (15 characters, correct pattern).
  They do not check live registration status with the GST portal.
- Standard GST slabs are built in: 0%, 0.25%, 3%, 5%, 12%, 18%, 28%.
- This tool prepares invoices and quotations. It does **not** file GST returns, generate
  e-invoices or connect to the GST portal.
- GST rates and rules change. Verify the current position on the GST portal or with your
  chartered accountant before you rely on any figure for filing.

---

## 7. Compatibility

| | |
|---|---|
| Browsers | Current Chrome, Edge, Firefox, Safari (desktop and mobile) |
| Operating systems | Windows, macOS, Linux, Android, iOS |
| Internet | Not required after download |
| File formats | Opens from `index.html`; prints to PDF |

---

## 8. Support

Questions or a problem with the files? Email **lonefaisal977@gmail.com** and we will help.
See `LICENSE.txt` for the terms of use.
