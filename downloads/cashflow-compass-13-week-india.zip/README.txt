CashFlow Compass — 13-Week Cash Flow Forecast & Runway Planner
================================================================
For Indian small businesses, agencies, traders, clinics, studios and
service firms. Excel (.xlsx) and Google Sheets. No macros. No sign-in.
One-time purchase, no subscription.


WHAT IS IN THIS ZIP
-------------------
1. CashFlow-Compass-Template.xlsx   — the blank workbook. Start here.
2. CashFlow-Compass-Example.xlsx    — the same workbook filled in with a
                                      sample business ("Sunrise Traders"),
                                      so you can see how the numbers move
                                      before you touch your own.
3. START-HERE.txt                   — a 10-minute quick start.
4. README.txt                       — this file: how the model works, how
                                      to read it, how to fix things.
5. LICENSE.txt                      — what you may and may not do.


THE PROBLEM THIS SOLVES
-----------------------
A monthly P&L can look fine while week 3 of the month is empty. Salaries go
out on the 1st, the biggest customer pays on the 20th, GST goes out three
weeks after month end. Cash timing, not profitability, is what closes small
businesses in India — and timing is invisible on a monthly statement.

Thirteen weeks is the horizon that matters. It is one quarter, long enough to
see a squeeze coming and short enough to be roughly true. This workbook turns
your monthly sales and costs into a week-by-week bank balance, with the
collection lags and payment lags that actually decide whether you make payroll.


THE SEVEN TABS
--------------
START HERE          Read once, four minutes.
Setup               Nine inputs: business name, start Monday, opening cash,
                    buffer, OD limit, GST settings.
Assumptions         Six revenue lines, twelve cost lines, six one-off items.
                    Each line carries its own growth rate and its own lag.
Forecast-13W        Read-only engine. Week numbers, dates, sales, collections,
                    costs, payments, GST, one-offs, and the answer rows:
                    opening, closing, buffer, headroom, status.
Dashboard           One plain-English signal line, twelve numbers, five
                    health checks, two charts.
Scenarios           Base, Slow and Stress cases side by side. Each is a full
                    13-week engine, not an estimate.
Actual vs forecast  Ten minutes every Monday: type what really hit the bank,
                    get the variance and a forecast-accuracy score.


HOW THE MATHS WORKS (so you can trust it or change it)
-----------------------------------------------------
Monthly to weekly.  Each monthly figure is divided by 4.33, then grown at
the annual rate you entered, week by week:
      weekly = monthly / 4.33 * (1 + growth)^(week / 52)
This is why week 1 and week 13 differ slightly for a line with growth.

Collection lag.  A revenue line with a 3-week lag contributes nothing in
weeks 1 to 3, and in week 4 collects what was invoiced in week 1, less the
bad-debt percentage. Same idea for payments, using the payment lag.

GST.  Output GST = sales invoiced x your sales rate. Input GST = the cost
lines you marked "YES" x your purchase rate. Net = output minus input, and
the positive part is paid after your GST lag. Negative weeks (a credit
month) are held at zero rather than carried forward — deliberately simple.
Your real liability comes from your returns, not from this sheet.

Headroom.  Closing cash + undrawn OD/CC limit - buffer. This is the number a
lender or your own nerve cares about: how much you could absorb before you
break your own floor.

The status row.  OK, BELOW BUFFER or NEGATIVE, per week, colour-coded.


HOW TO READ THE DASHBOARD SIGNAL
--------------------------------
The gold line at the top is generated from your own numbers and is always one
of four things:

  Nothing to forecast yet   No revenue lines entered. Fill the Assumptions tab.
  ALERT                     A week closes negative. It names the week and the
                            size of the gap you must cover before then.
  WATCH                     A week closes below your buffer. You have room,
                            but you should act in the next seven days.
  CLEAR                     Every week stays above your buffer. The lowest
                            point and its week are named.

What to do on a WATCH or ALERT week, in the order that usually works:
chase the three largest overdue invoices; offer a 1-2% early-payment discount
on the biggest one; move a non-critical payment run by seven days (never
statutory dues or payroll); draw the OD line before you need it; then, and
only then, delay growth spend.


SETUP IN TEN MINUTES
--------------------
1. Open CashFlow-Compass-Template.xlsx. If Excel asks about macros, there
   are none — the file is macro-free.
2. Setup tab: business name, the coming Monday, opening bank balance, the
   buffer you refuse to go below (a month of rent plus payroll is a sane
   first guess), and your undrawn OD limit (0 if none).
3. Assumptions tab, revenue: your 3-6 biggest revenue lines, monthly amount,
   growth, and how many weeks until that money reaches the bank.
4. Assumptions tab, costs: your biggest 6-12 cost lines the same way.
5. Anything that is not monthly — a machine, a refund, a client advance —
   goes in the one-off table with its week number.
6. Look at the Dashboard. Read the signal line. Look at the chart.
7. Open Scenarios, drop sales to 85% and add two weeks to collections. If the
   stress case is survivable, you know your levers.


THE WEEKLY RITUAL (TEN MINUTES, EVERY MONDAY)
---------------------------------------------
1. Actual vs forecast tab: type last week's real money in and money out.
2. Glance at the accuracy column. Below 85% on the inflow side means your
   collection lags are optimistic — raise them on Assumptions.
3. Move the forecast start date forward one Monday on Setup.
4. Read the new signal line. If it says WATCH or ALERT, act this week.
That is the whole discipline. Four weeks of doing this and your forecast
starts being right, which is when it becomes worth something.


GOOGLE SHEETS
-------------
Upload the .xlsx to Google Drive, open it, then File > Save as Google Sheets.
Formulas, number formats, dropdown validation and both charts carry over.
Two things to check after import: the rupee number format on a few cells
(Format > Number > Custom, enter  #,##,##0 ) and the chart titles, which
Google sometimes renames. No macros are involved, so nothing breaks.


NUMBER FORMAT AND UNITS
-----------------------
Every amount is in whole rupees, displayed with Indian grouping
(12,50,000). Enter 450000, not 4.5 lakh. If you prefer lakh, divide every
input by 100000 and read the outputs as lakh — do not mix the two.


TROUBLESHOOTING
---------------
A week shows 0 money in even though I entered sales.
   Check the collection lag. A lag of 3 means nothing arrives until week 4.
   That is the model working, not a bug.

The forecast looks too good — collections nearly equal invoiced sales.
   Your lags are too short. If a customer pays 45 days after invoice, that is
   about 6 weeks. Set it to 6 and watch what happens.

GST rows are all zero.
   Setup tab, "GST registered?" must say YES. Also make sure the cost lines
   you want credited are marked YES in the input-GST column.

The chart is empty after I edited the file.
   Charts read the Forecast-13W sheet by row. If you inserted rows on that
   sheet, re-point the chart (right-click > Select data).

I want a monthly view.
   Change nothing structural: sum any four consecutive columns of the closing
   row. The engine is additive.

Cells look wrong in Google Sheets after import.
   Re-apply the custom number format, and re-select the chart range once.
   Data is intact; only presentation is affected.

Do not type in the Forecast-13W sheet.
   It is all formulas. If you overwrite a formula cell, close without saving
   or re-download the file — it takes a minute.


WHAT THIS WORKBOOK IS NOT
-------------------------
It is a planning tool. It is not accounting software, not a filing tool, and
not financial, tax or legal advice. It does not compute your GST returns, your
TDS, your PF/ESI or your loan covenants, and it does not replace your CA.
Forecast outputs are only as good as the assumptions you type. Anything you
present to a lender should be checked with your accountant first.


SUPPORT
-------
Email lonefaisal977@gmail.com. Include the tab name and the cell reference if
something looks wrong — that is usually enough to fix it in one reply.

(c) 2026 Digitalaikart, a brand of UTILITYNEST. See LICENSE.txt.
