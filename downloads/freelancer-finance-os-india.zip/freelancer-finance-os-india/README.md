# Freelancer Finance OS — India

**A ready-to-use money system for Indian freelancers, consultants and one-person businesses.**
Track invoices, payments, TDS, expenses and profit, and estimate your advance tax under the
FY 2026-27 new regime — all in one Excel / Google Sheets workbook with live formulas.

Version 1.0 · © 2026 Digitalaikart · Sold as a digital product.

---

## 1. What is in this pack

```
freelancer-finance-os-india/
├── Freelancer-Finance-OS-India.xlsx   ← the workbook (open this)
├── README.md                          ← this file
└── LICENSE.txt                        ← your licence to use the workbook
```

There are **no macros** and nothing to install. The workbook works offline in
Microsoft Excel 2016+, Microsoft 365, Google Sheets and LibreOffice Calc.

---

## 2. The sheets

| Sheet | What it does |
|---|---|
| **Start Here** | A 10-minute setup guide and the colour key. |
| **Dashboard** | Your headline numbers — invoiced, received, outstanding, expenses, profit, margin, TDS, GST and the estimated tax — plus two live charts. |
| **Invoices** | One row per invoice: amount, GST, TDS, net to bank, due date, payment date and an automatic status (**Paid / Due / Overdue**). 200 rows. |
| **Clients** | Who owes you what, how many invoices, average days to pay and each client's share of your income. |
| **Expenses** | Your business costs with an input-GST column and a deductible flag. 200 rows. |
| **Monthly Summary** | April to March: invoiced, received, expenses, net profit, cumulative profit and a suggested tax set-aside. |
| **Tax Planner** | Presumptive (44ADA / 44AD) vs regular books, the new-regime tax for FY 2026-27 (₹12L rebate and marginal relief included), your TDS credit and the advance-tax instalments. |
| **Settings** | Your details (name, payment terms, tax set-aside %, GST status) and the dropdown lists you can edit. |
| **Tax Rates (Reference)** | The slabs, rebate, cess, surcharge, presumptive limits, advance-tax dates and GST slabs — for reference. |

---

## 3. Setup (about 10 minutes)

1. **Open the workbook.** In Excel, double-click the `.xlsx` file. In Google Sheets, upload
   it to Drive and open it (see section 7).
2. Go to the **Settings** sheet and fill the **yellow** cells: your name, default payment
   terms (30 days is pre-filled), the tax set-aside % you want to keep aside, and whether
   you are GST registered.
3. Go to **Invoices** and **Expenses**. There are **clearly-labelled example rows**
   (Invoices rows 4–15, Expenses rows 4–13). Look at how they work, then **delete the
   example rows** and enter your own.
4. Open **Tax Planner**, choose *Regular* or *Presumptive*, and enter any advance tax you
   have already paid.
5. Read the **Dashboard**. Everything updates by itself.

> **Colour key:** **Yellow** = you type here. **Grey / white** = automatic formulas, do not
> type over them. **Gold** = totals and headings. **Red banner** = warning or example data.

---

## 4. How the automatic columns work

On the **Invoices** sheet you only type: date, invoice number, client, description, amount
(ex-GST), GST %, TDS %, due date and (when it arrives) the payment date. Everything else is
calculated:

- **GST ₹** = amount × GST % ÷ 100
- **Invoice Total ₹** = amount + GST
- **TDS ₹** = amount × TDS % ÷ 100
- **Net to Bank ₹** = invoice total − TDS
- **Due Date** = invoice date + your payment terms (from Settings)
- **Status** = *Paid* if a payment date is entered, otherwise *Overdue* if today is past the
  due date, otherwise *Due*
- **Days to Pay** = payment date − invoice date

Overdue rows turn red, due rows amber and paid rows green, automatically.

**Clients** and **Monthly Summary** are driven entirely by the Invoices and Expenses sheets —
all on the same ex-GST basis, so on the Clients sheet *Received + Outstanding = Invoiced*.

---

## 5. The tax engine

The **Tax Planner** compares two ways of being taxed:

- **Regular books** — gross receipts minus your deductible expenses.
- **Presumptive** — 44ADA (professionals, 50% of gross, receipts up to ₹75 lakh) or
  44AD (business, 8% of turnover, 6% for digital receipts).

It then applies the **new-regime slabs for FY 2026-27**:

| Taxable income | Rate |
|---|---|
| Up to ₹4,00,000 | Nil |
| ₹4,00,001 – ₹8,00,000 | 5% |
| ₹8,00,001 – ₹12,00,000 | 10% |
| ₹12,00,001 – ₹16,00,000 | 15% |
| ₹16,00,001 – ₹20,00,000 | 20% |
| ₹20,00,001 – ₹24,00,000 | 25% |
| Above ₹24,00,000 | 30% |

…with the **₹60,000 rebate under section 87A** (which makes tax nil up to ₹12,00,000 of
taxable income), **marginal relief** just above ₹12 lakh so earning ₹1 more never costs you
more, and **4% health & education cess**. Surcharge (only above ₹50 lakh) is not included.

It finishes with your **TDS credit** (from paid invoices), any advance tax you have already
paid, the **balance payable or refund likely**, and the **four advance-tax instalments**
(15% by 15 Jun, 45% by 15 Sep, 75% by 15 Dec, 100% by 15 Mar; presumptive payers pay 100%
by 15 March).

> This is a **tracking and planning tool, not tax or accounting advice**. Figures are
> indicative. Tax rates, rebate limits and GST thresholds can change — verify the current
> position at **incometax.gov.in** / **gst.gov.in** or with your chartered accountant before
> you file or pay.

---

## 6. Everyday tips

- **Add rows** by inserting a whole row in the middle of the table — the formulas copy down.
  The 200 rows should last most freelancers a full year; extend the ranges if you need more.
- **Dropdowns** (clients, categories, GST %, TDS %) come from the Settings sheet. Rename or
  add entries there and they appear in the lists.
- **Keep it backed up.** Save the file to OneDrive or Google Drive so it is safe and synced.
- **Each financial year**, save a copy as last year's file and clear the data for the new year.

---

## 7. Using it in Google Sheets

1. Go to **drive.google.com** → **New → File upload** and pick
   `Freelancer-Finance-OS-India.xlsx`.
2. Right-click the uploaded file → **Open with → Google Sheets** → **File → Save as Google
   Sheets**.
3. The formulas, charts and dropdowns carry over. If a dropdown ever looks empty, re-point it
   at the Settings sheet (**Data → Data validation**).
4. Google Sheets has no `EDATE` issues and recalculates automatically.

---

## 8. Compatibility

| | |
|---|---|
| Apps | Microsoft Excel 2016+, Microsoft 365, Google Sheets, LibreOffice Calc |
| Macros | None — safe to open, nothing to enable |
| Systems | Windows, macOS, Linux, Android, iOS |
| Internet | Not required after download |
| Currency | Indian rupee, lakh / crore grouping |

---

## 9. Support

Questions or a problem with the file? Email **lonefaisal977@gmail.com** and we will help.
See `LICENSE.txt` for the terms of use.
