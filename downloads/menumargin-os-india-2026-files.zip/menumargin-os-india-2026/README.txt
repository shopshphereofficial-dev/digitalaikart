MENUMARGIN OS — INDIA EDITION 2026
Recipe costing, menu pricing and margin control
Digitalaikart · digitalkartai.shop
================================================================

WHAT'S IN THIS ZIP
------------------
1. MenuMargin-OS-India-2026.xlsx
   The system. Seven sheets, macro-free, opens in Excel 2016+, Excel for Mac,
   WPS Office, LibreOffice Calc and Google Sheets.
     - Start Here        : colour key, set-up order, the money maths
     - Settings          : GST, commission, gateway fee, packaging, targets
     - Ingredients       : 200 rows, pack price -> cost per usable gram/ml/piece
     - Recipe Lines      : 400 rows, ingredient and quantity per dish
     - Dishes            : 50 dishes, cost per portion to contribution per order
     - Menu Engineering  : Star / Plowhorse / Puzzle / Dog from last month's sales
     - Break-Even        : fixed costs, orders needed, operating profit

2. START-HERE.html
   Open it in any browser (double-click). Print or save as PDF from the browser
   if you want a paper copy. It contains the 15-minute set-up, the margin stack
   worked line by line on the example cake, and the sources behind the tax and
   commission defaults.

3. LICENSE.txt
   What you may and may not do with the file.

4. README.txt
   This file.


START IN 15 MINUTES
-------------------
1. Open the .xlsx. Read the Start Here sheet once.
2. Settings sheet: confirm GST 5%, your real commission %, gateway fee,
   packaging per order, target food cost.
3. Ingredients sheet: delete the rows tagged EXAMPLE, enter what you buy.
   Pack size in grams or millilitres (5 kg = 5000, 1 L = 1000) or in pieces.
4. Recipe Lines sheet: delete the EXAMPLE lines, then one row per ingredient
   per dish. Same dish code on every line of a dish.
5. Dishes sheet: delete the EXAMPLE rows, one row per dish. Enter portions per
   batch, packaging cost per portion and the menu price excluding GST.
6. Menu Engineering: enter last month's units sold per dish.
7. Break-Even: enter your monthly fixed costs.


THE ONE NUMBER THAT MATTERS
---------------------------
Contribution per order = what you receive from the platform, minus food cost
and packaging. That is the money that pays rent, salaries and you. A dish with
a 55% "gross margin" on paper can leave you 8% after commission, GST on that
commission, gateway fees and packaging. The Dishes sheet shows both.


REQUIREMENTS
------------
- Excel 2016 or later / Microsoft 365, Excel for Mac 2016+, LibreOffice Calc 7+,
  WPS Office, or Google Sheets (upload to Drive, open with Google Sheets).
- No macros, no add-ins, no login, no internet connection.
- Nothing is uploaded anywhere. Your cost data stays in your file.


IF SOMETHING LOOKS WRONG
------------------------
- A dish shows food cost 0: its dish code on Recipe Lines does not match the
  code on Dishes, or it has no recipe lines yet.
- "Not found" in the ingredient name column: that ingredient code is not on the
  Ingredients sheet.
- A calculated cell shows 0 after you deleted rows: that cell's formula was
  overwritten. Re-download the file and copy the formula down from a row above.
- Break-Even shows 0 orders: Menu Engineering has no units sold yet.

Support: lonefaisal977@gmail.com · WhatsApp +91 96826 00301
Refunds and terms: https://digitalkartai.shop/refund-policy.html
