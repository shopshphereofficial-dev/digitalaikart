# The ATS Checklist + 120 Action Verbs

Print this page, keep it next to your resume while you edit. Nothing here needs an
account, an app or a subscription.

---

## Part 1 — The 12-point checklist

Tick every line before you send the resume.

- [ ] **File name** is `Firstname-Lastname-Role.pdf`, not `resume_final.pdf`.
- [ ] **One page** if you have under 5 years of experience; two pages maximum otherwise.
- [ ] **Name, phone, email and city** are in the body of page one — not in a header or footer.
- [ ] **A target role line** sits under your name, matching the job you are applying to.
- [ ] **Summary is 3–4 lines** with one concrete result and a number in it.
- [ ] **Every bullet starts with an action verb** (list below), not "Responsible for".
- [ ] **At least three bullets contain a number**: %, ₹, hours, headcount, count, marks.
- [ ] **No tables, columns, text boxes, photos or icons.** Single column, plain text.
- [ ] **Section headings are standard**: Summary, Experience, Education, Skills, Projects, Certifications.
- [ ] **Dates are month + year**, identical in style on every entry, newest first.
- [ ] **Skills match the job post's wording** wherever it is honestly true.
- [ ] **Spell-check done**, and the file opened once to confirm the PDF is not blank.

---

## Part 2 — How the score in the app maps to this list

| Check in ResumeCraft | Weight | What it is really testing |
|---|---|---|
| Name, email, phone | 12 | Can the parser create a candidate record at all? |
| Target role line | 6 | Will you be filed under the right role? |
| Summary length | 10 | Can a human decide in 10 seconds? |
| Experience present | 10 | Is there substance behind the headline? |
| Education present | 8 | Does it meet the basic filter? |
| Skills, 6+ items | 10 | Does the keyword filter pass? |
| Action-verb bullets | 16 | Are you describing outcomes or duties? |
| Numbers in bullets | 12 | Is the impact measurable? |
| Overall length | 6 | Is it readable in the time a recruiter gives it? |
| Job-description keywords | 10 | Will you survive the automated shortlist? |

A score of 85+ means the document is ready. A score of 100 is not required — a
resume that reads like a person beats a resume that reads like a keyword dump.

---

## Part 3 — 120 action verbs

Swap a weak opening ("Responsible for", "Worked on", "Helped with") for one of these.
Pick the verb that is true, not the one that sounds biggest.

**Built and created (18)**
built · created · designed · developed · engineered · assembled · drafted · wrote ·
composed · produced · prototyped · launched · established · founded · initiated ·
introduced · set up · rolled out

**Improved and grew (18)**
improved · increased · grew · expanded · scaled · boosted · accelerated · upgraded ·
modernised · optimised · streamlined · simplified · refined · strengthened · revived ·
transformed · redesigned · rebuilt

**Cut and saved (12)**
reduced · cut · saved · eliminated · removed · consolidated · merged · shortened ·
decreased · prevented · avoided · recovered

**Ran and delivered (18)**
managed · led · owned · ran · delivered · executed · coordinated · scheduled ·
planned · organised · supervised · directed · oversaw · drove · handled · processed ·
maintained · monitored

**Analysed and decided (18)**
analysed · audited · assessed · evaluated · researched · investigated · forecast ·
modelled · measured · mapped · tested · validated · verified · reconciled · diagnosed ·
benchmarked · reviewed · interpreted

**Sold and served (12)**
sold · negotiated · converted · closed · onboarded · retained · upsold · pitched ·
presented · advised · consulted · supported

**Communicated and taught (12)**
trained · mentored · coached · taught · explained · documented · reported · published ·
translated · coordinated · briefed · facilitated

**Fixed and automated (12)**
automated · fixed · resolved · debugged · repaired · migrated · integrated ·
deployed · configured · implemented · installed · restored

---

## Part 4 — Bullet formulas that work

1. **Verb + what + result**
   *Automated the weekly sales report in SQL, cutting preparation from 6 hours to 45 minutes.*
2. **Verb + scale + result**
   *Built 6 Power BI dashboards used weekly by 40 store managers across 12 cities.*
3. **Verb + problem + method + outcome**
   *Analysed 1.2 lakh order rows to find the 5 SKUs driving 60% of returns; packaging fix cut returns by 18%.*
4. **Verb + people + outcome** (for leads)
   *Trained 4 new joiners on the ticketing tool; their average first-response time was 30% faster than the team's.*

If you cannot find a number, use a scale instead: number of clients, records, students,
cities, branches, SKUs, tickets, pages, campaigns.

---

## Part 5 — Words to delete

Responsible for · Worked on · Helped with · Duties included · Involved in ·
Assisted in · Familiar with · Hard worker · Team player · Think outside the box ·
Go-getter · Detail-oriented · Results-driven (on its own) · Dynamic professional ·
Seeking a challenging position

Each of these says nothing a recruiter can check. Replace them with what you actually did.

---

© 2026 UTILITYNEST / Digitalaikart · Included with ResumeCraft India. Personal use.
