# ResumeCraft India — Offline ATS Resume & Cover Letter Builder

Version 1.0 · November 2026 · © UTILITYNEST / Digitalaikart

A single HTML file that builds ATS-friendly resumes and matching cover letters in your
browser. No install, no sign-up, no internet connection, no subscription.

---

## Start here (2 minutes)

1. **Unzip** this folder somewhere you can find it, e.g. `Documents/ResumeCraft`.
2. **Double-click `index.html`.** It opens in your browser (Chrome, Edge, Firefox or Safari).
   Do not open it from inside the ZIP preview — extract first.
3. Fill the **Editor** tab on the left. The preview on the right updates as you type.
4. Open **ATS score** and fix the red items, then the amber ones.
5. Click **Print / Save PDF** at the top right.
   In the print dialog choose:
   - Destination: **Save as PDF**
   - Paper size: **A4**
   - Margins: **None**
   - Scale: **100%**
   - **Uncheck** "Headers and footers"
6. Save the file as `Firstname-Lastname-Role.pdf` — for example `Ananya-Sharma-Data-Analyst.pdf`.

That is the whole workflow. Everything else is optional.

---

## What is in this folder

| File | What it is |
|---|---|
| `index.html` | The whole app. Works offline. Double-click to run. |
| `README.md` | This file. |
| `LICENSE.txt` | Your licence — read once. |
| `sample-resume.json` | Clearly-labelled example data you can import to see a finished resume. |
| `ats-checklist-and-action-verbs.md` | One-page printable checklist plus 120 action verbs. |

---

## The four tabs

**Editor** — header, summary, work experience, education, skills, projects,
certifications, achievements, languages. Use `+ Add` to add a second job, degree or
project; `Remove` deletes it. Bullets are typed one per line — each line becomes one
bullet on the resume.

**ATS score** — a 0–100 readiness score across nine checks (ten when you paste a job
description). Each check tells you what to fix and why it matters. Paste a job post
and the tool shows which of its key terms appear in your resume and which are missing.
Only add the missing ones that are genuinely true for you.

**Cover letter** — fill in company, role and (optionally) the hiring manager's name,
choose a tone, and generate a letter built from your own resume content. Edit it
before sending: add one line about why that company specifically.

**Guide** — the ATS rules the templates follow, printing tips and troubleshooting.

---

## Templates and styling

- **Classic ATS** — single column, black text, maximum parser compatibility.
- **Modern** — coloured header band, same single-column body. Still parser-safe.
- **Compact** — tighter spacing for dense resumes or a two-page career.
- **Font** — Sans or Serif. **Accent** — five colours for the Modern header and headings.

All three templates are single-column with real selectable text, standard section
headings and no tables, images or text boxes.

---

## Your data and privacy

- The app has **no server, no analytics, no tracking and no network calls**. You can
  unplug the internet and it still works.
- Resumes are saved in your browser's **local storage on this device**, automatically,
  about a third of a second after you stop typing.
- **Export JSON** writes the whole resume to a file. Use it to back up, or to move to
  another computer: **Import** reads it back.
- **Export .txt** gives a plain-text version for portals that ask you to paste a resume.
- Clearing browser data, or using a private/incognito window, deletes saved resumes.
  Export JSON for anything you want to keep.

---

## Keyboard shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl/Cmd + S` | Export the current resume as JSON (does not save the web page) |
| `Ctrl/Cmd + P` | Open the print dialog (the app's own Print button is more reliable) |

---

## Tips that actually move the score

1. **Start every bullet with a verb.** Built, reduced, led, automated — not "Responsible for".
2. **Put a number in at least three bullets.** %, ₹, hours saved, team size, count, marks.
3. **Mirror the job post's words** where they are true. If the post says "stakeholder
   management" and that is what you did, use that phrase, not "dealing with people".
4. **One page** under five years of experience. Two pages maximum after that.
5. **No photo, no tables, no columns, no icons** — the ATS reads text, not design.
6. **Send a PDF**, unless the portal explicitly asks for .docx or a pasted text version.
7. **Name the file properly.** `resume_final_final.pdf` tells a recruiter nothing.

---

## Troubleshooting

**Nothing happens when I click Print / Save PDF.**
Use Chrome, Edge or Firefox, and open `index.html` by double-clicking it. Some browsers
block printing from a file opened inside a ZIP viewer.

**The PDF has two pages and I wanted one.**
Shorten bullets to one or two lines, drop the oldest role, or switch to the Compact
template. Reduce education details to degree, institute, years and score.

**My saved resumes disappeared.**
You are in a different browser, a private window, or browser data was cleared. Import
your JSON backup to restore.

**The PDF has a URL and date at the top or bottom.**
In the print dialog, uncheck "Headers and footers".

**Text looks cramped or cut off at the edge.**
Set margins to **None** and scale to **100%**. The page is already laid out for A4.

---

## Support

Email lonefaisal977@gmail.com with your order reference and a description of the
problem. Include your browser name and version if the app misbehaves.
