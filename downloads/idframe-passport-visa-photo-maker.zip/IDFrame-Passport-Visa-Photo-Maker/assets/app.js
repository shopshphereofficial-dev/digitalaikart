/* ==========================================================================
   IDFrame — app.js
   The interface: photo loading, crop editor with guides, sheet renderer,
   printing and exports. Everything runs locally in the browser.
   ========================================================================== */
(function () {
  'use strict';

  var SP = window.IDFrameSpecs;
  var DPI = 300;

  var S = {
    img: null,
    imgName: '',
    imgW: 0,
    imgH: 0,
    presetId: 'in-forms',
    w: 35,
    h: 45,
    zoom: 1,
    ox: 0,
    oy: 0,
    pageId: 'a4',
    margin: 6,
    gap: 2,
    copiesMode: 'max',
    copies: 0,
    marks: true,
    guides: true,
    quality: 0.92,
    bg: null
  };

  var el = {};
  function $(id) { return document.getElementById(id); }

  function preset() {
    for (var i = 0; i < SP.PRESETS.length; i++) { if (SP.PRESETS[i].id === S.presetId) return SP.PRESETS[i]; }
    return SP.PRESETS[0];
  }
  function page() {
    for (var i = 0; i < SP.PAGES.length; i++) { if (SP.PAGES[i].id === S.pageId) return SP.PAGES[i]; }
    return SP.PAGES[0];
  }
  function outPx() {
    return { w: Math.round(SP.mmToPx(S.w, DPI)), h: Math.round(SP.mmToPx(S.h, DPI)) };
  }

  /* ------------------------------------------------------------------ setup */
  function init() {
    el.crop = $('cropCanvas');
    el.cropCtx = el.crop.getContext('2d');
    el.sheet = $('sheetCanvas');
    el.sheetCtx = el.sheet.getContext('2d');
    el.cropWrap = $('cropWrap');
    el.empty = $('emptyState');

    buildPresetOptions();
    buildPageOptions();
    bindControls();
    bindDropAndPaste();
    bindDragCrop();

    syncSpecFields();
    refresh();
    renderSheet();
  }

  function buildPresetOptions() {
    var sel = $('preset');
    var groups = {};
    SP.PRESETS.forEach(function (p) {
      if (!groups[p.group]) {
        groups[p.group] = document.createElement('optgroup');
        groups[p.group].label = p.group;
        sel.appendChild(groups[p.group]);
      }
      var o = document.createElement('option');
      o.value = p.id;
      o.textContent = p.label;
      groups[p.group].appendChild(o);
    });
    sel.value = S.presetId;
  }

  function buildPageOptions() {
    var sel = $('page');
    SP.PAGES.forEach(function (p) {
      var o = document.createElement('option');
      o.value = p.id;
      o.textContent = p.label;
      sel.appendChild(o);
    });
    sel.value = S.pageId;
  }

  function bindControls() {
    $('preset').addEventListener('change', function () {
      S.presetId = this.value;
      var p = preset();
      S.w = p.w;
      S.h = p.h;
      S.zoom = 1; S.ox = 0; S.oy = 0;
      syncSpecFields();
      refresh();
      renderSheet();
    });

    ['wmm', 'hmm'].forEach(function (id) {
      $(id).addEventListener('input', function () {
        var v = parseFloat(this.value);
        if (!isFinite(v) || v <= 0) return;
        if (id === 'wmm') { S.w = Math.min(300, v); } else { S.h = Math.min(400, v); }
        if (S.presetId !== 'custom') {
          S.presetId = 'custom';
          $('preset').value = 'custom';
        }
        refresh();
        renderSheet();
      });
    });

    $('zoom').addEventListener('input', function () {
      S.zoom = parseFloat(this.value) / 100;
      $('zoomOut').textContent = Math.round(S.zoom * 100) + '%';
      refresh();
    });
    $('offx').addEventListener('input', function () {
      S.ox = parseFloat(this.value) / 100;
      refresh();
    });
    $('offy').addEventListener('input', function () {
      S.oy = parseFloat(this.value) / 100;
      refresh();
    });
    $('resetCrop').addEventListener('click', function () {
      S.zoom = 1; S.ox = 0; S.oy = 0;
      $('zoom').value = 100; $('offx').value = 0; $('offy').value = 0;
      $('zoomOut').textContent = '100%';
      refresh();
    });

    $('page').addEventListener('change', function () { S.pageId = this.value; renderSheet(); });
    $('margin').addEventListener('input', function () {
      var v = parseFloat(this.value);
      if (isFinite(v)) { S.margin = SP.clamp(v, 0, 40); renderSheet(); }
    });
    $('gap').addEventListener('input', function () {
      var v = parseFloat(this.value);
      if (isFinite(v)) { S.gap = SP.clamp(v, 0, 20); renderSheet(); }
    });
    $('copiesMode').addEventListener('change', function () {
      S.copiesMode = this.value;
      $('copiesRow').style.display = S.copiesMode === 'manual' ? 'block' : 'none';
      renderSheet();
    });
    $('copies').addEventListener('input', function () {
      var v = parseInt(this.value, 10);
      if (isFinite(v)) { S.copies = Math.max(1, Math.min(200, v)); renderSheet(); }
    });
    $('marks').addEventListener('change', function () { S.marks = this.checked; renderSheet(); });
    $('guides').addEventListener('change', function () { S.guides = this.checked; refresh(); });

    $('quality').addEventListener('input', function () {
      S.quality = parseInt(this.value, 10) / 100;
      $('qualityOut').textContent = Math.round(S.quality * 100) + '%';
      updateExportInfo();
    });

    $('btnPrint').addEventListener('click', printSheet);
    $('btnSheetPng').addEventListener('click', downloadSheetPng);
    $('btnPhotoJpg').addEventListener('click', downloadPhotoJpg);
    $('btnPhotoPng').addEventListener('click', downloadPhotoPng);
    $('btnSample').addEventListener('click', makeSample);
  }

  function bindDropAndPaste() {
    var zone = $('dropZone');
    ['dragenter', 'dragover'].forEach(function (ev) {
      zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.add('over'); });
    });
    ['dragleave', 'drop'].forEach(function (ev) {
      zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.remove('over'); });
    });
    zone.addEventListener('drop', function (e) {
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
        loadFile(e.dataTransfer.files[0]);
      }
    });
    $('file').addEventListener('change', function () {
      if (this.files && this.files[0]) loadFile(this.files[0]);
    });
    document.addEventListener('paste', function (e) {
      if (!e.clipboardData) return;
      var items = e.clipboardData.items || [];
      for (var i = 0; i < items.length; i++) {
        if (items[i].type && items[i].type.indexOf('image') === 0) {
          var f = items[i].getAsFile();
          if (f) { loadFile(f); e.preventDefault(); }
          return;
        }
      }
    });
  }

  function bindDragCrop() {
    var dragging = false, lastX = 0, lastY = 0;
    el.crop.addEventListener('pointerdown', function (e) {
      if (!S.img) return;
      dragging = true; lastX = e.clientX; lastY = e.clientY;
      el.crop.setPointerCapture(e.pointerId);
      el.crop.style.cursor = 'grabbing';
    });
    el.crop.addEventListener('pointermove', function (e) {
      if (!dragging || !S.img) return;
      var o = outPx();
      var rect = el.crop.getBoundingClientRect();
      var scale = rect.width / o.w;
      S.ox = SP.clamp(S.ox + (e.clientX - lastX) / scale / o.w, -0.5, 0.5);
      S.oy = SP.clamp(S.oy + (e.clientY - lastY) / scale / o.h, -0.5, 0.5);
      lastX = e.clientX; lastY = e.clientY;
      $('offx').value = Math.round(S.ox * 100);
      $('offy').value = Math.round(S.oy * 100);
      refresh();
    });
    function stop(e) {
      dragging = false;
      el.crop.style.cursor = S.img ? 'grab' : 'default';
      if (e && e.pointerId != null && el.crop.hasPointerCapture && el.crop.hasPointerCapture(e.pointerId)) {
        el.crop.releasePointerCapture(e.pointerId);
      }
    }
    el.crop.addEventListener('pointerup', stop);
    el.crop.addEventListener('pointercancel', stop);
    el.crop.addEventListener('wheel', function (e) {
      if (!S.img) return;
      e.preventDefault();
      S.zoom = SP.clamp(S.zoom + (e.deltaY < 0 ? 0.05 : -0.05), 1, 3);
      $('zoom').value = Math.round(S.zoom * 100);
      $('zoomOut').textContent = Math.round(S.zoom * 100) + '%';
      refresh();
    }, { passive: false });
  }

  /* -------------------------------------------------------------- photo load */
  function loadFile(file) {
    if (!/^image\//.test(file.type || '')) {
      note('That file is not an image. Use a JPG, PNG or WEBP photograph.', 'bad');
      return;
    }
    var reader = new FileReader();
    reader.onload = function () {
      var img = new Image();
      img.onload = function () {
        S.img = img;
        S.imgName = file.name || 'photo';
        S.imgW = img.naturalWidth;
        S.imgH = img.naturalHeight;
        S.zoom = 1; S.ox = 0; S.oy = 0;
        $('zoom').value = 100; $('offx').value = 0; $('offy').value = 0;
        S.bg = sampleBackground(img);
        el.empty.style.display = 'none';
        el.crop.style.display = 'block';
        el.crop.style.cursor = 'grab';
        $('photoMeta').textContent = S.imgName + ' · ' + S.imgW + ' × ' + S.imgH + ' px';
        refresh();
        renderSheet();
        updateExportInfo();
      };
      img.onerror = function () { note('That image could not be opened. Try a JPG or PNG.', 'bad'); };
      img.src = reader.result;
    };
    reader.onerror = function () { note('The file could not be read. Try again with a different copy.', 'bad'); };
    reader.readAsDataURL(file);
  }

  /* Four corner patches, luminance mean and standard deviation. */
  function sampleBackground(img) {
    var size = 320;
    var c = document.createElement('canvas');
    var ratio = Math.min(size / img.naturalWidth, size / img.naturalHeight, 1);
    c.width = Math.max(8, Math.round(img.naturalWidth * ratio));
    c.height = Math.max(8, Math.round(img.naturalHeight * ratio));
    var x = c.getContext('2d');
    x.drawImage(img, 0, 0, c.width, c.height);

    /* patches along the left and right edges, at head and shoulder height —
       that is where the background of a portrait actually is */
    var pw = Math.max(4, Math.round(c.width * 0.14));
    var ph = Math.max(4, Math.round(c.height * 0.12));
    var corners = [
      [0, Math.round(c.height * 0.04)], [c.width - pw, Math.round(c.height * 0.04)],
      [0, Math.round(c.height * 0.28)], [c.width - pw, Math.round(c.height * 0.28)]
    ];
    var stats = [];
    corners.forEach(function (pt) {
      var d;
      try { d = x.getImageData(pt[0], pt[1], pw, ph).data; } catch (err) { return; }
      var sum = 0, sum2 = 0, n = 0;
      for (var i = 0; i < d.length; i += 4) {
        var lum = 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2];
        sum += lum; sum2 += lum * lum; n++;
      }
      var mean = sum / n;
      var sd = Math.sqrt(Math.max(0, sum2 / n - mean * mean));
      stats.push({ mean: mean, sd: sd });
    });
    return stats;
  }

  /* ------------------------------------------------------------------ render */
  function syncSpecFields() {
    var p = preset();
    $('wmm').value = S.w;
    $('hmm').value = S.h;
    $('specNote').textContent = p.note;
    $('specSource').textContent = p.src;
    $('specBg').textContent = p.bg;
    var o = outPx();
    $('specChip').textContent = S.w + ' × ' + S.h + ' mm · ' + o.w + ' × ' + o.h + ' px @ ' + DPI + ' DPI';
  }

  function refresh() {
    syncSpecFields();
    if (!S.img) return;
    var o = outPx();
    el.crop.width = o.w;
    el.crop.height = o.h;
    var ctx = el.cropCtx;
    ctx.clearRect(0, 0, o.w, o.h);

    var d = SP.cropDrawParams(S.imgW, S.imgH, o.w, o.h, S.zoom, S.ox, S.oy);
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(S.img, d.dx, d.dy, d.dw, d.dh);

    if (S.guides) drawGuides(ctx, o.w, o.h);

    /* fit the canvas into the stage without distortion */
    var maxH = 380;
    var cssW = el.cropWrap.clientWidth - 24;
    if (cssW > 0) {
      el.crop.style.width = Math.min(cssW, o.w * (maxH / o.h)) + 'px';
      el.crop.style.height = 'auto';
    }

    /* resolution + background read-out */
    var eff = SP.effectiveSourcePx(S.imgW, S.imgH, o.w, o.h, S.zoom, S.ox, S.oy);
    var resBox = $('resWarn');
    if (!eff.ok) {
      resBox.className = 'note bad';
      resBox.textContent = 'This crop is using only ' + Math.round(eff.w) + ' × ' + Math.round(eff.h) + ' source pixels but the print needs ' +
        o.w + ' × ' + o.h + '. The photo will look soft at this size. Use a larger original or zoom out.';
      resBox.style.display = 'block';
    } else if (eff.w < eff.needW * 1.1) {
      resBox.className = 'note warn';
      resBox.textContent = 'Resolution is just enough (' + Math.round(eff.w) + ' × ' + Math.round(eff.h) + ' px for ' + o.w + ' × ' + o.h + '). It will print, but a bigger original is safer.';
      resBox.style.display = 'block';
    } else {
      resBox.style.display = 'none';
    }

    var bgBox = $('bgWarn');
    var verdict = SP.judgeBackground(S.bg);
    bgBox.className = 'note ' + (verdict.level === 'good' ? 'ok' : verdict.level === 'fair' ? 'warn' : 'bad');
    bgBox.textContent = verdict.text;
    bgBox.style.display = 'block';
  }

  function drawGuides(ctx, w, h) {
    var g = SP.guideGeometry(preset(), w, h, DPI);
    var unit = w / 200;
    ctx.save();

    /* keep-clear border */
    var inset = SP.mmToPx(1.5, DPI);
    ctx.strokeStyle = 'rgba(255,255,255,0.45)';
    ctx.lineWidth = Math.max(1, unit * 0.7);
    ctx.setLineDash([unit * 3, unit * 3]);
    ctx.strokeRect(inset, inset, w - inset * 2, h - inset * 2);
    ctx.setLineDash([]);

    if (g) {
      /* head band */
      ctx.fillStyle = 'rgba(245,197,66,0.16)';
      ctx.fillRect(0, g.bandTop, w, g.bandBottom - g.bandTop);
      ctx.strokeStyle = '#f5c542';
      ctx.lineWidth = Math.max(1.5, unit * 1.1);
      [g.bandTop, g.bandBottom].forEach(function (y) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
      });
      /* chin line */
      ctx.beginPath();
      ctx.moveTo(0, g.chin); ctx.lineTo(w, g.chin);
      ctx.stroke();
      /* eye line */
      ctx.strokeStyle = 'rgba(226,232,240,0.9)';
      ctx.setLineDash([unit * 5, unit * 4]);
      ctx.lineWidth = Math.max(1, unit * 0.9);
      ctx.beginPath(); ctx.moveTo(0, g.eye); ctx.lineTo(w, g.eye); ctx.stroke();
      ctx.setLineDash([]);

      /* labels */
      var fs = Math.max(10, Math.round(w * 0.052));
      ctx.font = '700 ' + fs + 'px system-ui, -apple-system, Segoe UI, Roboto, sans-serif';
      ctx.shadowColor = 'rgba(0,0,0,0.7)';
      ctx.shadowBlur = fs * 0.6;
      ctx.textBaseline = 'bottom';
      ctx.fillStyle = '#f5c542';
      ctx.fillText('top of head', fs * 0.5, g.bandTop - fs * 0.3);
      ctx.fillText('chin', fs * 0.5, g.chin - fs * 0.3);
      ctx.fillStyle = '#e2e8f0';
      ctx.textBaseline = 'top';
      ctx.fillText('eye level ≈', fs * 0.5, g.eye + fs * 0.35);
      ctx.textAlign = 'right';
      ctx.fillText('head ' + preset().headMin + '–' + preset().headMax + ' mm', w - fs * 0.5, g.bandTop + fs * 0.35);
      ctx.textAlign = 'start';
      ctx.shadowBlur = 0;
    } else {
      var fs2 = Math.max(10, Math.round(w * 0.06));
      ctx.font = '600 ' + fs2 + 'px system-ui, sans-serif';
      ctx.fillStyle = 'rgba(226,232,240,0.9)';
      ctx.shadowColor = 'rgba(0,0,0,0.7)'; ctx.shadowBlur = fs2 * 0.5;
      ctx.textBaseline = 'bottom';
      ctx.fillText('custom size — no head guides', fs2 * 0.5, h - fs2 * 0.6);
      ctx.shadowBlur = 0;
    }
    ctx.restore();
  }

  /* -------------------------------------------------------------- the sheet */
  function renderSheet() {
    var pg = page();
    var o = outPx();
    var sw = Math.round(SP.mmToPx(pg.w, DPI));
    var sh = Math.round(SP.mmToPx(pg.h, DPI));
    el.sheet.width = sw;
    el.sheet.height = sh;
    var ctx = el.sheetCtx;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, sw, sh);

    var layout = SP.sheetLayout({
      pageW: pg.w, pageH: pg.h, photoW: S.w, photoH: S.h,
      margin: S.margin, gap: S.gap,
      copies: S.copiesMode === 'manual' ? S.copies : 0
    });

    var pxPerMm = DPI / SP.MM_PER_INCH;

    if (!S.img) {
      /* a labelled guide sheet so the empty state still shows the maths */
      ctx.strokeStyle = '#d7dde8';
      ctx.lineWidth = Math.max(1, pxPerMm * 0.2);
      layout.items.forEach(function (it) {
        ctx.strokeRect(it.x * pxPerMm, it.y * pxPerMm, o.w, o.h);
      });
      ctx.fillStyle = '#9aa7ba';
      ctx.font = '600 ' + Math.round(sw * 0.018) + 'px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(layout.total + ' photos of ' + S.w + ' × ' + S.h + ' mm fit on this page',
        sw / 2, sh / 2 + Math.round(sw * 0.02));
      ctx.textAlign = 'start';
    } else {
      var d = SP.cropDrawParams(S.imgW, S.imgH, o.w, o.h, S.zoom, S.ox, S.oy);
      layout.items.forEach(function (it) {
        var x = it.x * pxPerMm;
        var y = it.y * pxPerMm;
        ctx.save();
        ctx.beginPath();
        ctx.rect(x, y, o.w, o.h);
        ctx.clip();
        ctx.drawImage(S.img, x + d.dx, y + d.dy, d.dw, d.dh);
        ctx.restore();
        if (S.marks) {
          ctx.strokeStyle = 'rgba(0,0,0,0.18)';
          ctx.lineWidth = Math.max(1, pxPerMm * 0.15);
          ctx.strokeRect(x + ctx.lineWidth / 2, y + ctx.lineWidth / 2, o.w - ctx.lineWidth, o.h - ctx.lineWidth);
        }
      });
    }

    $('sheetCount').textContent = layout.total + ' on this sheet';
    $('sheetInfo').textContent = 'Sheet ' + pg.w.toFixed(0) + ' × ' + pg.h.toFixed(0) + ' mm · grid ' +
      layout.cols + ' × ' + layout.rows + ' · max ' + layout.maxTotal + ' photos';
    updateExportInfo();
  }

  function updateExportInfo() {
    var o = outPx();
    var txt = o.w + ' × ' + o.h + ' px at ' + DPI + ' DPI';
    if (S.img) {
      var c = document.createElement('canvas');
      c.width = o.w; c.height = o.h;
      var x = c.getContext('2d');
      x.fillStyle = '#ffffff'; x.fillRect(0, 0, o.w, o.h);
      var d = SP.cropDrawParams(S.imgW, S.imgH, o.w, o.h, S.zoom, S.ox, S.oy);
      x.drawImage(S.img, d.dx, d.dy, d.dw, d.dh);
      var url = c.toDataURL('image/jpeg', S.quality);
      var bytes = Math.round((url.length - 'data:image/jpeg;base64,'.length) * 3 / 4);
      txt += ' · about ' + SP.fileSizeText(bytes) + ' as JPG at ' + Math.round(S.quality * 100) + '%';
    }
    $('exportInfo').textContent = txt;
  }

  /* --------------------------------------------------------------- printing */
  function printSheet() {
    var pg = page();
    var url = el.sheet.toDataURL('image/jpeg', 0.96);
    var st = $('printPageStyle');
    st.textContent = '@page{size:' + pg.w.toFixed(1) + 'mm ' + pg.h.toFixed(1) + 'mm;margin:0}' +
      'html,body{background:#fff!important}' +
      '#printRoot{display:block!important;width:' + pg.w.toFixed(1) + 'mm;height:' + pg.h.toFixed(1) + 'mm}' +
      '#printRoot img{width:100%;height:100%;display:block}';
    $('printImg').src = url;
    document.body.classList.add('is-printing');
    window.setTimeout(function () {
      window.print();
      window.setTimeout(function () { document.body.classList.remove('is-printing'); }, 400);
    }, 120);
  }

  /* ---------------------------------------------------------------- exports */
  function download(blobOrUrl, name) {
    var a = document.createElement('a');
    if (typeof blobOrUrl === 'string') { a.href = blobOrUrl; }
    else { a.href = URL.createObjectURL(blobOrUrl); }
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    if (typeof blobOrUrl !== 'string') { window.setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000); }
  }

  function downloadSheetPng() {
    if (!S.img) { note('Add a photograph first — the sheet is empty.', 'bad'); return; }
    var name = 'idframe-sheet-' + preset().id + '-' + S.w + 'x' + S.h + 'mm-' + page().id + '.png';
    download(el.sheet.toDataURL('image/png'), name);
    note('Sheet saved as a ' + DPI + ' DPI PNG. Print it at 100% with no margins, or take it to any print shop.', 'ok');
  }

  function downloadPhotoJpg() {
    if (!S.img) { note('Add a photograph first.', 'bad'); return; }
    var o = outPx();
    var c = document.createElement('canvas');
    c.width = o.w; c.height = o.h;
    var x = c.getContext('2d');
    x.fillStyle = '#ffffff'; x.fillRect(0, 0, o.w, o.h);
    var d = SP.cropDrawParams(S.imgW, S.imgH, o.w, o.h, S.zoom, S.ox, S.oy);
    x.drawImage(S.img, d.dx, d.dy, d.dw, d.dh);
    c.toBlob(function (blob) {
      if (!blob) { note('The JPEG could not be created in this browser. Try the PNG button.', 'bad'); return; }
      var name = 'idframe-' + SP.safeName(S.imgName) + '-' + S.w + 'x' + S.h + 'mm.jpg';
      download(blob, name);
      note('Saved ' + name + ' · ' + o.w + ' × ' + o.h + ' px · ' + SP.fileSizeText(blob.size) + '. Most online forms accept this as it is.', 'ok');
    }, 'image/jpeg', S.quality);
  }

  function downloadPhotoPng() {
    if (!S.img) { note('Add a photograph first.', 'bad'); return; }
    var o = outPx();
    var c = document.createElement('canvas');
    c.width = o.w; c.height = o.h;
    var x = c.getContext('2d');
    x.fillStyle = '#ffffff'; x.fillRect(0, 0, o.w, o.h);
    var d = SP.cropDrawParams(S.imgW, S.imgH, o.w, o.h, S.zoom, S.ox, S.oy);
    x.drawImage(S.img, d.dx, d.dy, d.dw, d.dh);
    var name = 'idframe-' + SP.safeName(S.imgName) + '-' + S.w + 'x' + S.h + 'mm.png';
    download(c.toDataURL('image/png'), name);
    note('Saved ' + name + ' · ' + o.w + ' × ' + o.h + ' px PNG.', 'ok');
  }

  function note(text, kind) {
    var box = $('status');
    box.textContent = text;
    box.className = 'status ' + (kind || 'ok');
    box.style.display = 'block';
  }

  /* A drawn demo portrait, clearly labelled as an example, so the tool can be
     tried without a photograph. Never used in a real export. */
  function makeSample() {
    var c = document.createElement('canvas');
    c.width = 900; c.height = 1200;
    var x = c.getContext('2d');
    x.fillStyle = '#f2f4f7'; x.fillRect(0, 0, c.width, c.height);
    var g = x.createLinearGradient(0, 0, 0, c.height);
    g.addColorStop(0, '#f7f8fa'); g.addColorStop(1, '#e6e9ee');
    x.fillStyle = g; x.fillRect(0, 0, c.width, c.height);

    /* shoulders */
    x.fillStyle = '#2b3a55';
    x.beginPath();
    x.moveTo(120, 1200);
    x.bezierCurveTo(150, 880, 330, 800, 450, 800);
    x.bezierCurveTo(570, 800, 750, 880, 780, 1200);
    x.closePath(); x.fill();

    /* neck */
    x.fillStyle = '#d9b28c';
    x.fillRect(390, 690, 120, 140);

    /* head */
    x.fillStyle = '#e8c4a2';
    x.beginPath();
    x.ellipse(450, 520, 170, 215, 0, 0, Math.PI * 2);
    x.fill();

    /* hair */
    x.fillStyle = '#241c17';
    x.beginPath();
    x.ellipse(450, 390, 176, 130, 0, Math.PI, Math.PI * 2);
    x.fill();
    x.fillRect(274, 380, 352, 45);

    /* ears */
    x.fillStyle = '#e0bb98';
    x.beginPath(); x.ellipse(283, 540, 22, 40, 0, 0, Math.PI * 2); x.fill();
    x.beginPath(); x.ellipse(617, 540, 22, 40, 0, 0, Math.PI * 2); x.fill();

    /* eyes */
    x.fillStyle = '#ffffff';
    x.beginPath(); x.ellipse(385, 505, 34, 20, 0, 0, Math.PI * 2); x.fill();
    x.beginPath(); x.ellipse(515, 505, 34, 20, 0, 0, Math.PI * 2); x.fill();
    x.fillStyle = '#3b2a1e';
    x.beginPath(); x.arc(385, 507, 13, 0, Math.PI * 2); x.fill();
    x.beginPath(); x.arc(515, 507, 13, 0, Math.PI * 2); x.fill();

    /* brows, nose, mouth */
    x.strokeStyle = '#3b2a1e'; x.lineWidth = 9; x.lineCap = 'round';
    x.beginPath(); x.moveTo(352, 462); x.lineTo(416, 456); x.stroke();
    x.beginPath(); x.moveTo(484, 456); x.lineTo(548, 462); x.stroke();
    x.strokeStyle = '#cfa179'; x.lineWidth = 8;
    x.beginPath(); x.moveTo(450, 520); x.lineTo(444, 590); x.lineTo(462, 596); x.stroke();
    x.strokeStyle = '#a5654f'; x.lineWidth = 10;
    x.beginPath(); x.moveTo(410, 645); x.quadraticCurveTo(450, 668, 490, 645); x.stroke();

    /* label so nobody mistakes it for a real person */
    x.fillStyle = 'rgba(10,22,40,0.06)';
    x.fillRect(0, 1130, 900, 70);
    x.fillStyle = '#5b6675';
    x.font = '600 30px system-ui, sans-serif';
    x.textAlign = 'center';
    x.fillText('EXAMPLE PORTRAIT — NOT A REAL PERSON', 450, 1175);

    var img = new Image();
    img.onload = function () {
      S.img = img;
      S.imgName = 'example-portrait';
      S.imgW = img.naturalWidth;
      S.imgH = img.naturalHeight;
      S.zoom = 1; S.ox = 0; S.oy = 0;
      $('zoom').value = 100; $('offx').value = 0; $('offy').value = 0;
      S.bg = sampleBackground(img);
      el.empty.style.display = 'none';
      el.crop.style.display = 'block';
      el.crop.style.cursor = 'grab';
      $('photoMeta').textContent = 'example-portrait · drawn example, not a real person';
      refresh();
      renderSheet();
      note('Loaded a drawn example portrait so you can see the guides. Replace it with your own photograph before you print.', 'warn');
    };
    img.src = c.toDataURL('image/png');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  /* exposed for the smoke test in /tests */
  window.IDFrameApp = { state: S, outPx: outPx, renderSheet: renderSheet, preset: preset };
})();
