/* TagCraft — UI controller
   Reads and writes nothing but the browser's own storage and local files.
   All barcode, QR and label maths lives in assets/engine.js. */
(function () {
  'use strict';

  var E = window.TagCraftEngine;
  if (!E) { alert('engine.js did not load. Keep the assets folder next to index.html.'); return; }

  var STORAGE_KEY = 'tagcraft.state.v1';

  /* ------------------------------------------------------------------ *
   * State
   * ------------------------------------------------------------------ */

  var DEMO_PRODUCTS = [
    { name: 'Tata Salt 1 kg (example)', price: 28, mrp: 30, code: 'TATA-SALT-1KG', size: '1 kg', copies: 4 },
    { name: 'Colgate Strong Teeth 100 g (example)', price: 62, mrp: 70, code: 'COLG-100', size: '100 g', copies: 3 },
    { name: 'Surf Excel Easy Wash 500 g (example)', price: 55, mrp: 65, code: 'SURF-500', size: '500 g', copies: 3 },
    { name: 'Amul Butter 100 g (example)', price: 58, mrp: 60, code: 'AMUL-BTR-100', size: '100 g', copies: 2 }
  ];

  function emptyProduct() {
    return { name: '', price: '', mrp: '', code: '', size: '', copies: 1 };
  }

  function defaultState() {
    return {
      profile: { shopName: 'Example Shop', vpa: '', phone: '' },
      sheet: 'a4-24',
      startAt: 0,
      design: {
        barcode: true, qr: true, mrp: true, discount: true, size: true,
        shop: true, phone: false, tax: true,
        symbology: 'code128', qrMode: 'upi', qrText: ''
      },
      products: [
        { name: 'Tata Salt 1 kg (example)', price: 28, mrp: 30, code: 'TATA-SALT-1KG', size: '1 kg', copies: 2 },
        { name: 'Colgate Strong Teeth 100 g (example)', price: 62, mrp: 70, code: 'COLG-100', size: '100 g', copies: 2 }
      ]
    };
  }

  var state = loadState() || defaultState();

  function loadState() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      if (!parsed || !parsed.products) return null;
      return normalise(parsed);
    } catch (err) { return null; }
  }

  function normalise(s) {
    var d = defaultState();
    var out = {
      profile: Object.assign({}, d.profile, s.profile || {}),
      sheet: E.SHEETS[s.sheet] ? s.sheet : d.sheet,
      startAt: Math.max(0, parseInt(s.startAt, 10) || 0),
      design: Object.assign({}, d.design, s.design || {}),
      products: (s.products || []).map(function (p) {
        return {
          name: String(p.name || ''),
          price: p.price === 0 ? 0 : (p.price || ''),
          mrp: p.mrp === 0 ? 0 : (p.mrp || ''),
          code: String(p.code || ''),
          size: String(p.size || ''),
          copies: Math.max(1, Math.min(500, parseInt(p.copies, 10) || 1))
        };
      })
    };
    if (!out.products.length) out.products = [emptyProduct()];
    return out;
  }

  var saveTimer = null;
  function persist() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (err) { /* private mode */ }
    }, 250);
  }

  /* ------------------------------------------------------------------ *
   * Element refs
   * ------------------------------------------------------------------ */

  var $ = function (id) { return document.getElementById(id); };

  var el = {
    shopName: $('shopName'), vpa: $('vpa'), phone: $('phone'),
    vpaHint: $('vpaHint'),
    sheetSelect: $('sheetSelect'), sheetHint: $('sheetHint'), startAt: $('startAt'),
    symbology: $('symbology'),
    optBarcode: $('optBarcode'), optQr: $('optQr'), optMrp: $('optMrp'),
    optDiscount: $('optDiscount'), optSize: $('optSize'), optShop: $('optShop'),
    optPhone: $('optPhone'), optTax: $('optTax'),
    qrMode: $('qrMode'), qrText: $('qrText'), qrTextWrap: $('qrTextWrap'),
    body: $('productsBody'), issues: $('issues'),
    stage: $('stage'),
    meta: $('previewMeta'), foot: $('previewFoot'),
    printRoot: $('printRoot')
  };

  /* ------------------------------------------------------------------ *
   * Build the sheet markup
   * ------------------------------------------------------------------ */

  var svgCache = {};
  function cached(key, make) {
    if (svgCache[key]) return svgCache[key];
    var v = make();
    svgCache[key] = v;
    return v;
  }

  function barcodeHeightMm() {
    var h = E.SHEETS[state.sheet].label.h;
    return Math.max(3.5, Math.min(7, h * 0.16));
  }

  function barcodeFor(code) {
    var sym = state.design.symbology;
    var key = sym + '|' + code + '|' + state.sheet;
    return cached(key, function () {
      try {
        var opts = { heightMm: barcodeHeightMm() };
        if (sym === 'ean13') return { ok: true, svg: E.ean13Svg(code, opts).svg };
        return { ok: true, svg: E.code128Svg(code, opts).svg };
      } catch (err) {
        return { ok: false, error: err.message };
      }
    });
  }

  function qrFor(text) {
    return cached('qr|' + text, function () {
      try {
        return { ok: true, svg: E.qrSvg(text, { sizeMm: 20 }).svg };
      } catch (err) {
        return { ok: false, error: err.message };
      }
    });
  }

  /** Everything that can go wrong with one product row. */
  function productIssues(p, index) {
    var out = [];
    var label = p.name ? '"' + p.name + '"' : 'Row ' + (index + 1);
    if (!p.name.trim()) out.push({ row: index, msg: 'Row ' + (index + 1) + ': give the product a name.' });
    if (!(E.toAmount(p.price) > 0)) out.push({ row: index, msg: label + ': enter a selling price above 0.' });
    if (state.design.barcode) {
      if (!p.code.trim()) {
        out.push({ row: index, msg: label + ': add a code / SKU, or the barcode cannot be printed.' });
      } else {
        var res = barcodeFor(p.code.trim());
        if (!res.ok) out.push({ row: index, msg: label + ': ' + res.error });
      }
    }
    return out;
  }

  function qrTextFor(p) {
    var mode = state.design.qrMode;
    if (mode === 'text') return (state.design.qrText || '').trim();
    try {
      return E.upiUri(
        { vpa: state.profile.vpa, shopName: state.profile.shopName },
        mode === 'upi' ? E.toAmount(p.price) : 0,
        ''
      );
    } catch (err) {
      return '';
    }
  }

  function labelHTML(p, sizePx, warn) {
    var d = state.design;
    var parts = [];
    var shop = (state.profile.shopName || '').trim();
    var price = E.toAmount(p.price);
    var mrp = E.toAmount(p.mrp);
    var disc = E.discountPct(mrp, price);

    if (d.shop && shop) {
      parts.push('<div class="lbl-top"><span class="lbl-shop">' + E.esc(shop) + '</span>' +
        (d.discount && disc > 0 ? '<span class="lbl-disc">' + disc + '% OFF</span>' : '') + '</div>');
    } else if (d.discount && disc > 0) {
      parts.push('<div class="lbl-top"><span></span><span class="lbl-disc">' + disc + '% OFF</span></div>');
    }

    parts.push('<div class="lbl-name">' + E.esc(p.name || 'Product name') + '</div>');
    if (d.size && p.size) parts.push('<div class="lbl-size">' + E.esc(p.size) + '</div>');

    var priceLine = '<div class="lbl-price-row"><span class="lbl-price">' + E.formatINR(price) + '</span>';
    if (d.mrp && mrp > price) priceLine += '<span class="lbl-mrp">' + E.formatINR(mrp) + '</span>';
    priceLine += '</div>';
    parts.push(priceLine);

    if (d.tax) parts.push('<div class="lbl-tax">M.R.P. inclusive of all taxes</div>');

    var codes = '';
    if (d.barcode && p.code) {
      var bc = barcodeFor(p.code.trim());
      if (bc.ok) {
        codes += '<div class="lbl-bar">' + bc.svg + '<div class="lbl-code">' + E.esc(p.code.trim()) + '</div></div>';
      }
    }
    if (d.qr) {
      var qrText = qrTextFor(p);
      if (qrText) {
        var qr = qrFor(qrText);
        if (qr.ok) {
          var qrMm = Math.max(6, Math.min(16, sizePx.label.h * 0.38));
          var payCaption = state.design.qrMode !== 'text' && sizePx.label.h >= 28
            ? '<div class="lbl-pay">SCAN &amp; PAY</div>' : '';
          codes += '<div class="lbl-qr-wrap" style="width:' + qrMm + 'mm">' +
            '<div class="lbl-qr" style="width:' + qrMm + 'mm;height:' + qrMm + 'mm">' + qr.svg + '</div>' +
            payCaption + '</div>';
        }
      }
    }
    if (codes) parts.push('<div class="lbl-codes">' + codes + '</div>');

    if (d.phone && (state.profile.phone || '').trim()) {
      parts.push('<div class="lbl-foot">' + E.esc(state.profile.phone.trim()) + '</div>');
    }

    return '<div class="label' + (warn ? ' warn' : '') + '">' + parts.join('') + '</div>';
  }

  function blankHTML() { return '<div class="label blank"></div>'; }

  /** Build one sheet of labels for the chosen layout. */
  function buildSheetHTML(items, sheet, startAt) {
    var cells = [];
    for (var i = 0; i < startAt; i++) cells.push(blankHTML());
    items.forEach(function (item) { cells.push(labelHTML(item.p, sheet, item.warn)); });
    var total = sheet.cols * sheet.rows;
    while (cells.length < total) cells.push(blankHTML());

    var style = '--lh:' + sheet.label.h + ';' +
      'width:' + sheet.page.w + 'mm;height:' + sheet.page.h + 'mm;' +
      'padding:' + sheet.margin.t + 'mm 0 0 ' + sheet.margin.l + 'mm;';
    var inner = 'display:grid;' +
      'grid-template-columns:repeat(' + sheet.cols + ',' + sheet.label.w + 'mm);' +
      'grid-template-rows:repeat(' + sheet.rows + ',' + sheet.label.h + 'mm);' +
      'column-gap:' + sheet.gap.x + 'mm;row-gap:' + sheet.gap.y + 'mm;';

    return '<div class="sheet" style="' + style + '"><div class="sheet-inner" style="' + inner + '">' +
      cells.join('') + '</div></div>';
  }

  /* ------------------------------------------------------------------ *
   * Render
   * ------------------------------------------------------------------ */

  function usableProducts() {
    return state.products.filter(function (p) { return String(p.name || '').trim() !== ''; });
  }

  function collectIssues() {
    var issues = [];
    state.products.forEach(function (p, i) {
      if (!String(p.name || '').trim() && !String(p.price || '').trim() && !String(p.code || '').trim()) return;
      issues = issues.concat(productIssues(p, i));
    });
    if (state.design.qr) {
      if (state.design.qrMode === 'text') {
        if (!(state.design.qrText || '').trim()) {
          issues.push({ msg: 'QR is switched on but the custom text is empty — the QR code will be left off the labels.' });
        }
      } else {
        try { E.upiUri({ vpa: state.profile.vpa, shopName: state.profile.shopName }, 10, ''); }
        catch (err) { issues.push({ msg: 'UPI QR: ' + err.message + ' The QR code is left off until this is fixed.' }); }
      }
    }
    return issues;
  }

  function renderPreview() {
    var sheet = E.SHEETS[state.sheet];
    var items = E.expandLabels(usableProducts(), null).map(function (p) {
      var bad = state.design.barcode && p.code && !barcodeFor(String(p.code).trim()).ok;
      return { p: p, warn: bad };
    });
    var per = sheet.cols * sheet.rows;
    var total = items.length;
    var sheetsNeeded = Math.max(1, Math.ceil((total + state.startAt) / per));
    var first = items.slice(0, Math.max(0, per - state.startAt));

    var oldFrame = el.stage.querySelector('.sheet-frame');
    if (oldFrame) oldFrame.remove();
    var wrap = document.createElement('div');
    wrap.className = 'sheet-frame';
    wrap.innerHTML = buildSheetHTML(first, sheet, state.startAt);
    el.stage.appendChild(wrap);
    var sheetEl = wrap.querySelector('.sheet');
    sheetEl.style.display = 'block';

    fitSheet(sheetEl, wrap, sheet);

    el.meta.textContent = sheet.name + ' · ' + per + ' labels per sheet';
    el.foot.textContent = total
      ? total + ' label' + (total === 1 ? '' : 's') + ' for ' + usableProducts().length + ' product' +
        (usableProducts().length === 1 ? '' : 's') + ' · ' + sheetsNeeded + ' sheet' + (sheetsNeeded === 1 ? '' : 's') +
        ' when you print' + (state.startAt ? ' · first ' + state.startAt + ' slot(s) left blank' : '')
      : 'Add a product to see labels here.';
    el.foot.style.color = total ? '' : 'var(--muted)';
  }

  var MM_TO_PX = 96 / 25.4;

  function fitSheet(sheetEl, wrap, sheet) {
    var sheetWpx = sheet.page.w * MM_TO_PX;
    var sheetHpx = sheet.page.h * MM_TO_PX;
    sheetEl.style.width = sheet.page.w + 'mm';
    sheetEl.style.height = sheet.page.h + 'mm';
    var available = el.stage.clientWidth - 2 * parseFloat(getComputedStyle(el.stage).paddingLeft || '0') - 4;
    var scale = available / sheetWpx;
    scale = Math.max(0.12, Math.min(scale, 2.2));
    sheetEl.style.transform = 'scale(' + scale + ')';
    wrap.style.width = (sheetWpx * scale) + 'px';
    wrap.style.height = (sheetHpx * scale) + 'px';
  }

  function renderIssues() {
    var issues = collectIssues();
    if (!issues.length) { el.issues.hidden = true; el.issues.innerHTML = ''; return; }
    el.issues.hidden = false;
    el.issues.innerHTML = '<strong>' + issues.length + ' thing' + (issues.length === 1 ? '' : 's') +
      ' to fix before printing</strong><ul>' +
      issues.slice(0, 8).map(function (i) { return '<li>' + E.esc(i.msg) + '</li>'; }).join('') +
      (issues.length > 8 ? '<li>…and ' + (issues.length - 8) + ' more.</li>' : '') + '</ul>';
  }

  function renderProducts() {
    var html = state.products.map(function (p, i) {
      var bad = state.design.barcode && String(p.code || '').trim() && !barcodeFor(String(p.code).trim()).ok;
      return '<tr class="' + (bad ? 'row-bad' : '') + '" data-row="' + i + '">' +
        '<td class="c-name"><input type="text" data-field="name" value="' + E.esc(p.name) + '" placeholder="Product name" aria-label="Product name row ' + (i + 1) + '"></td>' +
        '<td class="c-num"><input type="text" inputmode="decimal" data-field="price" value="' + E.esc(p.price) + '" placeholder="0" aria-label="Price row ' + (i + 1) + '"></td>' +
        '<td class="c-num"><input type="text" inputmode="decimal" data-field="mrp" value="' + E.esc(p.mrp) + '" placeholder="0" aria-label="MRP row ' + (i + 1) + '"></td>' +
        '<td class="c-code"><input type="text" data-field="code" value="' + E.esc(p.code) + '" placeholder="SKU / barcode" aria-label="Code row ' + (i + 1) + '"></td>' +
        '<td class="c-size"><input type="text" data-field="size" value="' + E.esc(p.size) + '" placeholder="1 kg" aria-label="Size row ' + (i + 1) + '"></td>' +
        '<td class="c-copies"><input type="text" inputmode="numeric" data-field="copies" value="' + E.esc(p.copies) + '" aria-label="Copies row ' + (i + 1) + '"></td>' +
        '<td class="c-del"><button type="button" class="del" data-del="' + i + '" title="Remove this product" aria-label="Remove row ' + (i + 1) + '">×</button></td>' +
        '</tr>';
    }).join('');
    el.body.innerHTML = html;
  }

  function renderAll() {
    renderProducts();
    renderPreview();
    renderIssues();
    syncControls();
  }

  function syncControls() {
    el.shopName.value = state.profile.shopName || '';
    el.vpa.value = state.profile.vpa || '';
    el.phone.value = state.profile.phone || '';
    el.sheetSelect.value = state.sheet;
    el.startAt.value = String(state.startAt);
    el.symbology.value = state.design.symbology;
    el.qrMode.value = state.design.qrMode;
    el.qrText.value = state.design.qrText || '';
    el.qrTextWrap.hidden = state.design.qrMode !== 'text';
    el.optBarcode.checked = !!state.design.barcode;
    el.optQr.checked = !!state.design.qr;
    el.optMrp.checked = !!state.design.mrp;
    el.optDiscount.checked = !!state.design.discount;
    el.optSize.checked = !!state.design.size;
    el.optShop.checked = !!state.design.shop;
    el.optPhone.checked = !!state.design.phone;
    el.optTax.checked = !!state.design.tax;
    updateSheetHint();
    updateVpaHint();
  }

  function updateSheetHint() {
    var s = E.SHEETS[state.sheet];
    el.sheetHint.textContent = s.note + ' Label size ' + s.label.w + ' × ' + s.label.h + ' mm.';
    el.sheetHint.className = 'hint';
  }

  function updateVpaHint() {
    var vpa = (state.profile.vpa || '').trim();
    if (!vpa) {
      el.vpaHint.className = 'hint';
      el.vpaHint.innerHTML = 'Look at your bank app or any UPI app: your ID looks like <code>name@bank</code>. Leave it blank to print labels without a QR code.';
      return;
    }
    try {
      E.upiUri({ vpa: vpa, shopName: state.profile.shopName }, 1, '');
      el.vpaHint.className = 'hint good';
      el.vpaHint.textContent = 'Looks right — the QR will pay into ' + vpa + '.';
    } catch (err) {
      el.vpaHint.className = 'hint bad';
      el.vpaHint.textContent = err.message;
    }
  }

  /* ------------------------------------------------------------------ *
   * Printing
   * ------------------------------------------------------------------ */

  function buildPrintSheets() {
    var sheet = E.SHEETS[state.sheet];
    var per = sheet.cols * sheet.rows;
    var items = E.expandLabels(usableProducts(), null).map(function (p) {
      var bad = state.design.barcode && p.code && !barcodeFor(String(p.code).trim()).ok;
      return { p: p, warn: bad };
    });
    if (!items.length) return 0;

    var html = '';
    var index = 0;
    var first = true;
    while (index < items.length) {
      var startAt = first ? state.startAt : 0;
      var room = per - startAt;
      var chunk = items.slice(index, index + room);
      html += buildSheetHTML(chunk, sheet, startAt);
      index += chunk.length;
      first = false;
    }
    el.printRoot.innerHTML = html;
    applyPageSize(sheet);
    return Math.ceil((items.length + state.startAt) / per);
  }

  function applyPageSize(sheet) {
    var styleEl = document.getElementById('pageStyle');
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = 'pageStyle';
      document.head.appendChild(styleEl);
    }
    styleEl.textContent = '@page{size:' + sheet.page.w + 'mm ' + sheet.page.h + 'mm;margin:0}';
  }

  function doPrint() {
    var issues = collectIssues();
    var blocking = issues.filter(function (i) { return /price above 0|give the product a name/.test(i.msg); });
    if (blocking.length) {
      renderIssues();
      el.issues.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    var n = buildPrintSheets();
    if (!n) { alert('Add at least one product with a name before printing.'); return; }
    window.print();
  }

  /* ------------------------------------------------------------------ *
   * Files in and out
   * ------------------------------------------------------------------ */

  function download(filename, text, mime) {
    var blob = new Blob([text], { type: mime || 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
  }

  function stamp() {
    var d = new Date();
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  /* ------------------------------------------------------------------ *
   * Wiring
   * ------------------------------------------------------------------ */

  // sheet options
  Object.keys(E.SHEETS).forEach(function (id) {
    var o = document.createElement('option');
    o.value = id;
    o.textContent = E.SHEETS[id].name;
    el.sheetSelect.appendChild(o);
  });

  function fillStartAt() {
    var per = E.perSheet(state.sheet);
    var keep = state.startAt;
    el.startAt.innerHTML = '';
    for (var i = 0; i < per; i++) {
      var o = document.createElement('option');
      o.value = String(i);
      o.textContent = i === 0 ? 'First label (normal)' : 'Skip first ' + i;
      el.startAt.appendChild(o);
    }
    state.startAt = Math.min(keep, per - 1);
    el.startAt.value = String(state.startAt);
  }

  el.shopName.addEventListener('input', function () {
    state.profile.shopName = el.shopName.value;
    updateVpaHint(); renderPreview(); persist();
  });
  el.vpa.addEventListener('input', function () {
    state.profile.vpa = el.vpa.value.trim();
    updateVpaHint(); renderPreview(); renderIssues(); persist();
  });
  el.phone.addEventListener('input', function () {
    state.profile.phone = el.phone.value;
    renderPreview(); persist();
  });

  el.sheetSelect.addEventListener('change', function () {
    state.sheet = el.sheetSelect.value;
    fillStartAt();
    updateSheetHint();
    renderAll();
    persist();
  });

  el.startAt.addEventListener('change', function () {
    state.startAt = parseInt(el.startAt.value, 10) || 0;
    renderPreview(); persist();
  });

  el.symbology.addEventListener('change', function () {
    state.design.symbology = el.symbology.value;
    renderAll();
    persist();
  });

  [['optBarcode', 'barcode'], ['optQr', 'qr'], ['optMrp', 'mrp'], ['optDiscount', 'discount'],
    ['optSize', 'size'], ['optShop', 'shop'], ['optPhone', 'phone'], ['optTax', 'tax']]
    .forEach(function (pair) {
      el[pair[0]].addEventListener('change', function () {
        state.design[pair[1]] = el[pair[0]].checked;
        renderPreview(); renderIssues(); persist();
      });
    });

  el.qrMode.addEventListener('change', function () {
    state.design.qrMode = el.qrMode.value;
    el.qrTextWrap.hidden = state.design.qrMode !== 'text';
    renderPreview(); renderIssues(); persist();
  });

  el.qrText.addEventListener('input', function () {
    state.design.qrText = el.qrText.value;
    renderPreview(); renderIssues(); persist();
  });

  // product table: typing
  el.body.addEventListener('input', function (ev) {
    var input = ev.target;
    if (!input || input.tagName !== 'INPUT') return;
    var tr = input.closest('tr');
    if (!tr) return;
    var row = parseInt(tr.getAttribute('data-row'), 10);
    var field = input.getAttribute('data-field');
    if (!state.products[row] || !field) return;
    var value = input.value;
    if (field === 'copies') {
      var n = parseInt(value.replace(/[^0-9]/g, ''), 10);
      value = isNaN(n) ? 1 : Math.max(1, Math.min(500, n));
    }
    state.products[row][field] = value;
    if (field === 'code' || field === 'name') {
      var bad = state.design.barcode && String(state.products[row].code || '').trim() &&
        !barcodeFor(String(state.products[row].code).trim()).ok;
      tr.classList.toggle('row-bad', !!bad);
    }
    renderPreview();
    renderIssues();
    persist();
  });

  el.body.addEventListener('change', function (ev) {
    var input = ev.target;
    if (input && input.getAttribute && input.getAttribute('data-field') === 'copies') {
      input.value = String(state.products[parseInt(input.closest('tr').getAttribute('data-row'), 10)].copies);
    }
  });

  // product table: remove
  el.body.addEventListener('click', function (ev) {
    var btn = ev.target.closest('[data-del]');
    if (!btn) return;
    var row = parseInt(btn.getAttribute('data-del'), 10);
    state.products.splice(row, 1);
    if (!state.products.length) state.products.push(emptyProduct());
    renderAll();
    persist();
  });

  $('btnAdd').addEventListener('click', function () {
    state.products.push(emptyProduct());
    renderAll();
    persist();
    var rows = el.body.querySelectorAll('tr');
    var last = rows[rows.length - 1];
    if (last) last.querySelector('input').focus();
  });

  $('btnClear').addEventListener('click', function () {
    if (!confirm('Remove every product from this list? Your shop details and label settings stay as they are.')) return;
    state.products = [emptyProduct()];
    renderAll();
    persist();
  });

  $('btnDemo').addEventListener('click', function () {
    state.products = DEMO_PRODUCTS.map(function (p) { return Object.assign({}, p); });
    if (!state.profile.shopName || state.profile.shopName === 'Example Shop') state.profile.shopName = 'Sharma General Store';
    renderAll();
    persist();
  });

  $('btnPrint').addEventListener('click', doPrint);

  $('btnSave').addEventListener('click', function () {
    download('tagcraft-' + stamp() + '.json', JSON.stringify(state, null, 2), 'application/json');
  });

  $('btnLoad').addEventListener('click', function () { $('fileInput').click(); });

  $('fileInput').addEventListener('change', function (ev) {
    var file = ev.target.files && ev.target.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var parsed = JSON.parse(String(reader.result));
        state = normalise(parsed);
        fillStartAt();
        renderAll();
        persist();
      } catch (err) {
        alert('That file is not a TagCraft save file (JSON expected).');
      }
    };
    reader.readAsText(file);
    ev.target.value = '';
  });

  $('btnCsv').addEventListener('click', function () { $('csvInput').click(); });

  $('csvInput').addEventListener('change', function (ev) {
    var file = ev.target.files && ev.target.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var rows = E.csvToProducts(String(reader.result));
        if (!rows.length) { alert('No products found. The first line must be a header such as: name,price,mrp,code,size,copies'); return; }
        var existing = state.products.filter(function (p) { return String(p.name || '').trim() !== ''; });
        state.products = existing.concat(rows);
        renderAll();
        persist();
        alert(rows.length + ' product' + (rows.length === 1 ? '' : 's') + ' imported.');
      } catch (err) {
        alert('Could not read that CSV: ' + err.message);
      }
    };
    reader.readAsText(file);
    ev.target.value = '';
  });

  $('btnCsvOut').addEventListener('click', function () {
    var rows = usableProducts();
    if (!rows.length) { alert('There is nothing to export yet.'); return; }
    download('tagcraft-products-' + stamp() + '.csv', E.productsToCSV(rows), 'text/csv;charset=utf-8');
  });

  // keep the preview scaled on resize
  var resizeTimer = null;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      var frame = el.stage.querySelector('.sheet-frame');
      var sheetEl = frame && frame.querySelector('.sheet');
      if (sheetEl) fitSheet(sheetEl, frame, E.SHEETS[state.sheet]);
    }, 120);
  });

  window.addEventListener('beforeprint', function () {
    buildPrintSheets();
  });

  window.addEventListener('afterprint', function () {
    el.printRoot.innerHTML = '';
  });

  // go
  fillStartAt();
  renderAll();
})();
