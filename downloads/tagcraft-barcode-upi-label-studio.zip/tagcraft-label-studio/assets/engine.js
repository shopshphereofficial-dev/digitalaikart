/*!
 * TagCraft — Label Studio engine
 * Code 128 barcodes, EAN-13 barcodes, QR codes (byte mode, versions 1-10, ECC M),
 * UPI payment URIs, Indian currency formatting, CSV import and A4 label sheet layout.
 *
 * No dependencies. No network calls. Works in the browser (window.TagCraftEngine)
 * and in Node.js (module.exports) so the maths can be unit-tested.
 *
 * Licence: see LICENSE.txt in this package.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.TagCraftEngine = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ------------------------------------------------------------------ *
   * 1. Code 128
   * ------------------------------------------------------------------ */

  // Width patterns for the 107 Code 128 symbols. Each string is the run of
  // bar/space widths (bar first) in modules; every symbol is 11 modules,
  // except the stop symbol (106) which is 13 modules including the final bar.
  var C128 = [
    '212222', '222122', '222221', '121223', '121322', '131222', '122213',
    '122312', '132212', '221213', '221312', '231212', '112232', '122132',
    '122231', '113222', '123122', '123221', '223211', '221132', '221231',
    '213212', '223112', '312131', '311222', '321122', '321221', '312212',
    '322112', '322211', '212123', '212321', '232121', '111323', '131123',
    '131321', '112313', '132113', '132311', '211313', '231113', '231311',
    '112133', '112331', '132131', '113123', '113321', '133121', '313121',
    '211331', '231131', '213113', '213311', '213131', '311123', '311321',
    '331121', '312113', '312311', '332111', '314111', '221411', '431111',
    '111224', '111422', '121124', '121421', '141122', '141221', '112214',
    '112412', '122114', '122411', '142112', '142211', '241211', '221114',
    '413111', '241112', '134111', '111242', '121142', '121241', '114212',
    '124112', '124211', '411212', '421112', '421211', '212141', '214121',
    '412121', '111143', '111341', '131141', '114113', '114311', '411113',
    '411311', '113141', '114131', '311141', '411131', '211412', '211214',
    '211232', '2331112'
  ];

  var START_B = 104, START_C = 105, STOP = 106;

  function widthsToBits(seq) {
    var out = '';
    for (var i = 0; i < seq.length; i++) {
      var w = parseInt(seq.charAt(i), 10);
      var bit = (i % 2 === 0) ? '1' : '0'; // even index = bar
      for (var k = 0; k < w; k++) out += bit;
    }
    return out;
  }

  /**
   * Encode a string as Code 128 (subset B, or subset C when the value is all
   * digits and an even length of 4 or more, which halves the width).
   * Returns { bits, text, subset, symbols }.
   */
  function code128Bits(text) {
    var value = String(text == null ? '' : text);
    // Code 128 B covers printable ASCII 32-126 only.
    for (var i = 0; i < value.length; i++) {
      var c = value.charCodeAt(i);
      if (c < 32 || c > 126) {
        throw new Error('Code 128 supports printable ASCII only. Remove "' + value.charAt(i) + '" from "' + value + '".');
      }
    }
    if (!value.length) throw new Error('Barcode value is empty.');

    var symbols = [];
    var useC = /^[0-9]{4,}$/.test(value) && value.length % 2 === 0;
    if (useC) {
      symbols.push(START_C);
      for (var j = 0; j < value.length; j += 2) {
        symbols.push(parseInt(value.substr(j, 2), 10));
      }
    } else {
      symbols.push(START_B);
      for (var k = 0; k < value.length; k++) {
        symbols.push(value.charCodeAt(k) - 32);
      }
    }

    // Modulo-103 check symbol: start value + sum(position * value).
    var sum = symbols[0];
    for (var p = 1; p < symbols.length; p++) sum += p * symbols[p];
    symbols.push(sum % 103);
    symbols.push(STOP);

    var bits = '';
    for (var s = 0; s < symbols.length; s++) bits += widthsToBits(C128[symbols[s]]);
    return { bits: bits, text: value, subset: useC ? 'C' : 'B', symbols: symbols };
  }

  /* ------------------------------------------------------------------ *
   * 2. EAN-13
   * ------------------------------------------------------------------ */

  var EAN_L = ['0001101', '0011001', '0010011', '0111101', '0100011',
    '0110001', '0101111', '0111011', '0110111', '0001011'];
  var EAN_G = ['0100111', '0110011', '0011011', '0100001', '0011101',
    '0111001', '0000101', '0010001', '0001001', '0010111'];
  var EAN_R = ['1110010', '1100110', '1101100', '1000010', '1011100',
    '1001110', '1010000', '1000100', '1001000', '1110100'];
  // Parity of the left six digits, selected by the first digit.
  var EAN_PARITY = ['LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', 'LGLLGG',
    'LGGLLG', 'LGGGLL', 'LGLGLG', 'LGLGGL', 'LGGLGL'];

  function ean13CheckDigit(first12) {
    var sum = 0;
    for (var i = 0; i < 12; i++) {
      sum += parseInt(first12.charAt(i), 10) * (i % 2 === 0 ? 1 : 3);
    }
    return (10 - (sum % 10)) % 10;
  }

  /** Accepts 12 or 13 digits; returns { bits, text, check } with 95 modules. */
  function ean13Bits(input) {
    var digits = String(input == null ? '' : input).replace(/[^0-9]/g, '');
    if (digits.length === 12) {
      digits += String(ean13CheckDigit(digits));
    } else if (digits.length === 13) {
      var expected = ean13CheckDigit(digits.substr(0, 12));
      if (parseInt(digits.charAt(12), 10) !== expected) {
        throw new Error('EAN-13 check digit should be ' + expected + ', not ' + digits.charAt(12) + '.');
      }
    } else {
      throw new Error('EAN-13 needs 12 digits (check digit is added) or 13 digits.');
    }

    var parity = EAN_PARITY[parseInt(digits.charAt(0), 10)];
    var bits = '101';
    for (var i = 1; i <= 6; i++) {
      var d = parseInt(digits.charAt(i), 10);
      bits += parity.charAt(i - 1) === 'L' ? EAN_L[d] : EAN_G[d];
    }
    bits += '01010';
    for (var j = 7; j <= 12; j++) {
      bits += EAN_R[parseInt(digits.charAt(j), 10)];
    }
    bits += '101';
    return { bits: bits, text: digits, check: digits.charAt(12) };
  }

  /* ------------------------------------------------------------------ *
   * 3. QR code — byte mode, versions 1-10, error correction level M
   * ------------------------------------------------------------------ */

  // [ecCodewordsPerBlock, blocksGroup1, dataCodewordsGroup1, blocksGroup2, dataCodewordsGroup2]
  var QR_M = {
    1: [10, 1, 16, 0, 0],
    2: [16, 1, 28, 0, 0],
    3: [26, 1, 44, 0, 0],
    4: [18, 2, 32, 0, 0],
    5: [24, 2, 43, 0, 0],
    6: [16, 4, 27, 0, 0],
    7: [18, 4, 31, 0, 0],
    8: [22, 2, 38, 2, 39],
    9: [22, 3, 36, 2, 37],
    10: [26, 4, 43, 1, 44]
  };

  var QR_ALIGN = {
    1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30],
    6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]
  };

  function qrDataCapacity(version) {
    var t = QR_M[version];
    return t[1] * t[2] + t[3] * t[4];
  }

  function utf8Bytes(str) {
    var out = [];
    for (var i = 0; i < str.length; i++) {
      var c = str.charCodeAt(i);
      if (c < 0x80) {
        out.push(c);
      } else if (c < 0x800) {
        out.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f));
      } else if (c >= 0xd800 && c <= 0xdbff && i + 1 < str.length) {
        var c2 = str.charCodeAt(i + 1);
        if (c2 >= 0xdc00 && c2 <= 0xdfff) {
          var cp = 0x10000 + ((c - 0xd800) << 10) + (c2 - 0xdc00);
          out.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3f), 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
          i++;
          continue;
        }
        out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f));
      } else {
        out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f));
      }
    }
    return out;
  }

  // Reed-Solomon over GF(256), primitive polynomial 0x11d.
  var GF_EXP = new Array(512), GF_LOG = new Array(256);
  (function () {
    var x = 1;
    for (var i = 0; i < 255; i++) {
      GF_EXP[i] = x;
      GF_LOG[x] = i;
      x <<= 1;
      if (x & 0x100) x ^= 0x11d;
    }
    for (var j = 255; j < 512; j++) GF_EXP[j] = GF_EXP[j - 255];
  })();

  function gfMul(a, b) {
    if (a === 0 || b === 0) return 0;
    return GF_EXP[GF_LOG[a] + GF_LOG[b]];
  }

  function rsGenerator(degree) {
    var poly = [1];
    for (var i = 0; i < degree; i++) {
      var next = new Array(poly.length + 1);
      for (var k = 0; k < next.length; k++) next[k] = 0;
      for (var p = 0; p < poly.length; p++) {
        next[p] ^= poly[p];
        next[p + 1] ^= gfMul(poly[p], GF_EXP[i]);
      }
      poly = next;
    }
    return poly;
  }

  function rsRemainder(data, degree) {
    var gen = rsGenerator(degree);
    var rem = new Array(degree);
    for (var i = 0; i < degree; i++) rem[i] = 0;
    for (var d = 0; d < data.length; d++) {
      var factor = data[d] ^ rem[0];
      rem.shift();
      rem.push(0);
      for (var j = 0; j < degree; j++) rem[j] ^= gfMul(gen[j + 1], factor);
    }
    return rem;
  }

  function qrBitStream(bytes, version) {
    var bits = [];
    var push = function (val, len) {
      for (var i = len - 1; i >= 0; i--) bits.push((val >> i) & 1);
    };
    push(0x4, 4); // byte mode
    push(bytes.length, version <= 9 ? 8 : 16);
    for (var i = 0; i < bytes.length; i++) push(bytes[i], 8);

    var capacityBits = qrDataCapacity(version) * 8;
    if (bits.length > capacityBits) {
      throw new Error('Data too long for QR version ' + version + '.');
    }
    var terminator = Math.min(4, capacityBits - bits.length);
    for (var t = 0; t < terminator; t++) bits.push(0);
    while (bits.length % 8 !== 0) bits.push(0);

    var codewords = [];
    for (var b = 0; b < bits.length; b += 8) {
      var byteVal = 0;
      for (var k = 0; k < 8; k++) byteVal = (byteVal << 1) | bits[b + k];
      codewords.push(byteVal);
    }
    var pad = [0xec, 0x11], pi = 0;
    while (codewords.length < qrDataCapacity(version)) {
      codewords.push(pad[pi % 2]);
      pi++;
    }
    return codewords;
  }

  function qrCodewords(str, version) {
    var data = qrBitStream(utf8Bytes(str), version);
    var t = QR_M[version];
    var ecLen = t[0], g1 = t[1], d1 = t[2], g2 = t[3], d2 = t[4];
    var blocks = [], offset = 0, i;
    for (i = 0; i < g1; i++) {
      blocks.push(data.slice(offset, offset + d1));
      offset += d1;
    }
    for (i = 0; i < g2; i++) {
      blocks.push(data.slice(offset, offset + d2));
      offset += d2;
    }
    var ecBlocks = blocks.map(function (blk) { return rsRemainder(blk, ecLen); });

    var maxLen = Math.max(d1, d2);
    var out = [];
    for (var c = 0; c < maxLen; c++) {
      for (var b = 0; b < blocks.length; b++) {
        if (c < blocks[b].length) out.push(blocks[b][c]);
      }
    }
    for (var e = 0; e < ecLen; e++) {
      for (var f = 0; f < ecBlocks.length; f++) out.push(ecBlocks[f][e]);
    }
    return out;
  }

  function bchFormat(data) {
    // data = 5 bits (2 EC level bits + 3 mask bits)
    var d = data << 10;
    for (var i = 14; i >= 10; i--) {
      if ((d >> i) & 1) d ^= 0x537 << (i - 10);
    }
    return ((data << 10) | d) ^ 0x5412;
  }

  function bchVersion(version) {
    var d = version << 12;
    for (var i = 17; i >= 12; i--) {
      if ((d >> i) & 1) d ^= 0x1f25 << (i - 12);
    }
    return (version << 12) | d;
  }

  function buildMatrix(version, codewords, mask) {
    var size = version * 4 + 17;
    var m = [], reserved = [];
    for (var r = 0; r < size; r++) {
      m.push(new Array(size).fill(0));
      reserved.push(new Array(size).fill(0));
    }

    function setFunc(r, c, dark) {
      m[r][c] = dark ? 1 : 0;
      reserved[r][c] = 1;
    }

    // Finder patterns + separators
    function finder(row, col) {
      for (var dr = -1; dr <= 7; dr++) {
        for (var dc = -1; dc <= 7; dc++) {
          var rr = row + dr, cc = col + dc;
          if (rr < 0 || rr >= size || cc < 0 || cc >= size) continue;
          var inSquare = dr >= 0 && dr <= 6 && dc >= 0 && dc <= 6;
          var dark = inSquare && (dr === 0 || dr === 6 || dc === 0 || dc === 6 ||
            (dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4));
          setFunc(rr, cc, dark);
        }
      }
    }
    finder(0, 0);
    finder(0, size - 7);
    finder(size - 7, 0);

    // Timing patterns
    for (var i = 8; i < size - 8; i++) {
      setFunc(6, i, i % 2 === 0);
      setFunc(i, 6, i % 2 === 0);
    }

    // Alignment patterns
    var align = QR_ALIGN[version];
    for (var a = 0; a < align.length; a++) {
      for (var b = 0; b < align.length; b++) {
        var ar = align[a], ac = align[b];
        if ((ar <= 8 && ac <= 8) || (ar <= 8 && ac >= size - 9) || (ar >= size - 9 && ac <= 8)) continue;
        for (var dr2 = -2; dr2 <= 2; dr2++) {
          for (var dc2 = -2; dc2 <= 2; dc2++) {
            var dark2 = Math.max(Math.abs(dr2), Math.abs(dc2)) !== 1;
            setFunc(ar + dr2, ac + dc2, dark2);
          }
        }
      }
    }

    // Dark module
    setFunc(size - 8, 8, true);

    // Reserve format areas
    for (var f = 0; f <= 8; f++) {
      if (!reserved[8][f]) { reserved[8][f] = 1; }
      if (!reserved[f][8]) { reserved[f][8] = 1; }
    }
    for (var g = 0; g < 8; g++) {
      reserved[8][size - 1 - g] = 1;
      reserved[size - 1 - g][8] = 1;
    }

    // Version information (versions 7+)
    if (version >= 7) {
      var vBits = bchVersion(version);
      for (var v = 0; v < 18; v++) {
        var bit = (vBits >> v) & 1;
        var rr2 = Math.floor(v / 3), cc2 = size - 11 + (v % 3);
        setFunc(rr2, cc2, bit);
        setFunc(cc2, rr2, bit);
      }
    }

    // Place data bits in the zigzag
    var bitIndex = 0;
    var totalBits = codewords.length * 8;
    var upward = true;
    for (var col = size - 1; col > 0; col -= 2) {
      if (col === 6) col--;
      for (var step = 0; step < size; step++) {
        var row = upward ? size - 1 - step : step;
        for (var k = 0; k < 2; k++) {
          var c3 = col - k;
          if (reserved[row][c3]) continue;
          var bitVal = 0;
          if (bitIndex < totalBits) {
            bitVal = (codewords[bitIndex >> 3] >> (7 - (bitIndex & 7))) & 1;
          }
          m[row][c3] = bitVal;
          bitIndex++;
        }
      }
      upward = !upward;
    }

    // Apply mask
    for (var mr = 0; mr < size; mr++) {
      for (var mc = 0; mc < size; mc++) {
        if (reserved[mr][mc]) continue;
        var invert = false;
        switch (mask) {
          case 0: invert = (mr + mc) % 2 === 0; break;
          case 1: invert = mr % 2 === 0; break;
          case 2: invert = mc % 3 === 0; break;
          case 3: invert = (mr + mc) % 3 === 0; break;
          case 4: invert = (Math.floor(mr / 2) + Math.floor(mc / 3)) % 2 === 0; break;
          case 5: invert = ((mr * mc) % 2) + ((mr * mc) % 3) === 0; break;
          case 6: invert = (((mr * mc) % 2) + ((mr * mc) % 3)) % 2 === 0; break;
          case 7: invert = (((mr + mc) % 2) + ((mr * mc) % 3)) % 2 === 0; break;
        }
        if (invert) m[mr][mc] ^= 1;
      }
    }

    // Format information (EC level M = 00), both copies, per ISO/IEC 18004.
    var fmt = bchFormat((0 << 3) | mask);
    for (var q = 0; q <= 5; q++) m[q][8] = (fmt >> q) & 1;          // column 8, rows 0-5
    m[7][8] = (fmt >> 6) & 1;
    m[8][8] = (fmt >> 7) & 1;
    m[8][7] = (fmt >> 8) & 1;
    for (var q2 = 9; q2 <= 14; q2++) m[8][14 - q2] = (fmt >> q2) & 1; // row 8, columns 5-0
    for (var q3 = 0; q3 <= 7; q3++) m[8][size - 1 - q3] = (fmt >> q3) & 1;
    for (var q4 = 8; q4 <= 14; q4++) m[size - 15 + q4][8] = (fmt >> q4) & 1;
    m[size - 8][8] = 1; // the always-dark module

    return m;
  }

  function penalty(m) {
    var size = m.length, score = 0, r, c, i;
    // Rule 1: runs of five or more
    for (r = 0; r < size; r++) {
      var runRow = 1, runCol = 1;
      for (c = 1; c < size; c++) {
        if (m[r][c] === m[r][c - 1]) runRow++; else { if (runRow >= 5) score += runRow - 2; runRow = 1; }
        if (m[c][r] === m[c - 1][r]) runCol++; else { if (runCol >= 5) score += runCol - 2; runCol = 1; }
      }
      if (runRow >= 5) score += runRow - 2;
      if (runCol >= 5) score += runCol - 2;
    }
    // Rule 2: 2x2 blocks of one colour
    for (r = 0; r < size - 1; r++) {
      for (c = 0; c < size - 1; c++) {
        var v = m[r][c];
        if (v === m[r][c + 1] && v === m[r + 1][c] && v === m[r + 1][c + 1]) score += 3;
      }
    }
    // Rule 3: finder-like patterns 1:1:3:1:1 with 4 light modules on either side
    var patA = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0];
    var patB = [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1];
    function matches(get, start, pat) {
      for (var k = 0; k < 11; k++) if (get(start + k) !== pat[k]) return false;
      return true;
    }
    for (r = 0; r < size; r++) {
      for (c = 0; c <= size - 11; c++) {
        var getRow = (function (row) { return function (x) { return m[row][x]; }; })(r);
        if (matches(getRow, c, patA)) score += 40;
        if (matches(getRow, c, patB)) score += 40;
      }
    }
    for (c = 0; c < size; c++) {
      for (r = 0; r <= size - 11; r++) {
        var getCol = (function (col) { return function (y) { return m[y][col]; }; })(c);
        if (matches(getCol, r, patA)) score += 40;
        if (matches(getCol, r, patB)) score += 40;
      }
    }
    // Rule 4: dark module proportion
    var dark = 0;
    for (r = 0; r < size; r++) for (c = 0; c < size; c++) dark += m[r][c];
    var pct = (dark * 100) / (size * size);
    score += Math.floor(Math.abs(pct - 50) / 5) * 10;
    return score;
  }

  /** Encode text as a QR module matrix (array of rows of 0/1). */
  function qrMatrix(text) {
    var str = String(text == null ? '' : text);
    if (!str.length) throw new Error('QR value is empty.');
    var bytes = utf8Bytes(str);
    var version = 0;
    for (var v = 1; v <= 10; v++) {
      var headerBits = 4 + (v <= 9 ? 8 : 16);
      if (headerBits + bytes.length * 8 <= qrDataCapacity(v) * 8) { version = v; break; }
    }
    if (!version) {
      throw new Error('Text is too long for this QR encoder (about 200 characters maximum). Shorten the UPI note or the text.');
    }

    var codewords = qrCodewords(str, version);
    var best = null, bestScore = Infinity;
    for (var mask = 0; mask < 8; mask++) {
      var candidate = buildMatrix(version, codewords, mask);
      var s = penalty(candidate);
      if (s < bestScore) { bestScore = s; best = candidate; }
    }
    return { matrix: best, version: version, size: best.length };
  }

  /* ------------------------------------------------------------------ *
   * 4. SVG builders
   * ------------------------------------------------------------------ */

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /**
   * Code 128 as SVG. Bars only by default: width fills the container and the
   * height is fixed in mm, so the label keeps a constant bar height while the
   * module widths scale together (which is what a scanner needs). The
   * human-readable line is rendered by the UI as text, so it is never stretched.
   */
  function code128Svg(text, opts) {
    opts = opts || {};
    var enc = code128Bits(text);
    var quiet = 10;
    var modules = enc.bits.length + quiet * 2;
    var heightMm = opts.heightMm || 8;
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + modules + ' 100"' +
      ' width="100%" height="' + heightMm + 'mm" preserveAspectRatio="none"' +
      ' shape-rendering="crispEdges" role="img" aria-label="Barcode ' + esc(enc.text) + '"' +
      ' data-barcode="' + esc(enc.text) + '" data-subset="' + enc.subset + '">';
    svg += '<rect width="' + modules + '" height="100" fill="#ffffff"/>';
    var x = quiet, i = 0;
    while (i < enc.bits.length) {
      if (enc.bits.charAt(i) === '1') {
        var run = 1;
        while (i + run < enc.bits.length && enc.bits.charAt(i + run) === '1') run++;
        svg += '<rect x="' + x + '" y="0" width="' + run + '" height="100" fill="#000000"/>';
        x += run;
        i += run;
      } else {
        x += 1;
        i += 1;
      }
    }
    svg += '</svg>';
    return { svg: svg, text: enc.text, subset: enc.subset, modules: modules };
  }

  /**
   * EAN-13 as SVG. Bars only, same scaling rule as Code 128; the digits are
   * shown by the UI underneath the bars.
   */
  function ean13Svg(input, opts) {
    opts = opts || {};
    var enc = ean13Bits(input);
    var heightMm = opts.heightMm || 10;
    var quiet = 9;
    var modules = 95 + quiet * 2;
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + modules + ' 100"' +
      ' width="100%" height="' + heightMm + 'mm" preserveAspectRatio="none"' +
      ' shape-rendering="crispEdges" role="img" aria-label="EAN-13 ' + enc.text + '"' +
      ' data-barcode="' + enc.text + '" data-symbology="EAN13">';
    svg += '<rect width="' + modules + '" height="100" fill="#ffffff"/>';
    var x = quiet, i = 0;
    while (i < enc.bits.length) {
      if (enc.bits.charAt(i) === '1') {
        var run = 1;
        while (i + run < enc.bits.length && enc.bits.charAt(i + run) === '1') run++;
        var guard = (i < 3) || (i >= 45 && i < 50) || (i >= 92);
        var h = guard ? 100 : 92;
        svg += '<rect x="' + x + '" y="0" width="' + run + '" height="' + h + '" fill="#000000"/>';
        x += run;
        i += run;
      } else {
        x += 1;
        i += 1;
      }
    }
    svg += '</svg>';
    return { svg: svg, text: enc.text, check: enc.check, modules: modules };
  }

  /** QR matrix as SVG with a 4-module quiet zone. */
  function qrSvg(text, opts) {
    opts = opts || {};
    var q = qrMatrix(text);
    var quiet = 4;
    var total = q.size + quiet * 2;
    var dark = '#000000', light = '#ffffff';
    var path = '';
    for (var r = 0; r < q.size; r++) {
      var c = 0;
      while (c < q.size) {
        if (q.matrix[r][c] === 1) {
          var run = 1;
          while (c + run < q.size && q.matrix[r][c + run] === 1) run++;
          path += 'M' + (c + quiet) + ' ' + (r + quiet) + 'h' + run + 'v1h-' + run + 'z';
          c += run;
        } else {
          c++;
        }
      }
    }
    var sizeMm = opts.sizeMm || 18;
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + total + ' ' + total + '" width="' + sizeMm + 'mm" height="' + sizeMm + 'mm" shape-rendering="crispEdges" role="img" aria-label="QR code" data-qr="' + esc(text) + '" data-version="' + q.version + '">' +
      '<rect width="' + total + '" height="' + total + '" fill="' + light + '"/>' +
      '<path d="' + path + '" fill="' + dark + '"/></svg>';
    return { svg: svg, version: q.version, size: q.size };
  }

  /* ------------------------------------------------------------------ *
   * 5. UPI helpers
   * ------------------------------------------------------------------ */

  /** Build a UPI deep link. Amount is optional (0 or blank = customer types it). */
  function upiUri(profile, amount, note) {
    var vpa = String((profile && profile.vpa) || '').trim();
    if (!vpa) throw new Error('Add your UPI ID (VPA) first, for example shopname@okhdfcbank.');
    if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]*@[a-zA-Z]{2,}$/.test(vpa)) {
      throw new Error('That UPI ID does not look right. It should look like name@bank, for example mykirana@okaxis.');
    }
    var parts = ['pa=' + encodeURIComponent(vpa)];
    var name = String((profile && profile.shopName) || '').trim();
    if (name) parts.push('pn=' + encodeURIComponent(name.substr(0, 40)));
    var amt = Number(amount);
    if (amt > 0) parts.push('am=' + amt.toFixed(2));
    parts.push('cu=INR');
    var tn = String(note || '').trim();
    if (tn) parts.push('tn=' + encodeURIComponent(tn.substr(0, 40)));
    return 'upi://pay?' + parts.join('&');
  }

  /* ------------------------------------------------------------------ *
   * 6. Money formatting (Indian digit grouping)
   * ------------------------------------------------------------------ */

  function formatINR(value, withSymbol) {
    var n = Number(value);
    if (!isFinite(n)) n = 0;
    var negative = n < 0;
    n = Math.abs(n);
    var fixed = n.toFixed(2);
    var parts = fixed.split('.');
    var whole = parts[0];
    var last3 = whole.slice(-3);
    var rest = whole.slice(0, -3);
    if (rest) last3 = ',' + last3;
    var grouped = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + last3;
    var out = grouped;
    if (parts[1] && parts[1] !== '00') out += '.' + parts[1];
    return (negative ? '-' : '') + (withSymbol === false ? '' : '\u20b9') + out;
  }

  /** Round a rupee string/number to 2 decimals; returns 0 for junk. */
  function toAmount(v) {
    var n = Number(String(v == null ? '' : v).replace(/[^0-9.\-]/g, ''));
    return isFinite(n) ? Math.round(n * 100) / 100 : 0;
  }

  /* ------------------------------------------------------------------ *
   * 7. CSV import / export
   * ------------------------------------------------------------------ */

  /** Minimal RFC-4180 CSV parser: handles quotes, escaped quotes and newlines. */
  function parseCSV(text) {
    var rows = [], row = [], field = '', inQuotes = false;
    var s = String(text || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    for (var i = 0; i < s.length; i++) {
      var ch = s.charAt(i);
      if (inQuotes) {
        if (ch === '"') {
          if (s.charAt(i + 1) === '"') { field += '"'; i++; } else { inQuotes = false; }
        } else {
          field += ch;
        }
      } else if (ch === '"') {
        inQuotes = true;
      } else if (ch === ',') {
        row.push(field); field = '';
      } else if (ch === '\n') {
        row.push(field); field = '';
        if (row.length > 1 || row[0].trim() !== '') rows.push(row);
        row = [];
      } else {
        field += ch;
      }
    }
    row.push(field);
    if (row.length > 1 || row[0].trim() !== '') rows.push(row);
    return rows;
  }

  /**
   * Turn CSV text into product rows. Header names are matched loosely, so
   * "Product Name", "name" and "item" all work.
   */
  function csvToProducts(text) {
    var rows = parseCSV(text);
    if (!rows.length) return [];
    var header = rows[0].map(function (h) { return h.trim().toLowerCase(); });
    function find(names) {
      for (var i = 0; i < names.length; i++) {
        var idx = header.indexOf(names[i]);
        if (idx !== -1) return idx;
      }
      return -1;
    }
    var iName = find(['name', 'product', 'product name', 'item', 'item name', 'title']);
    var iPrice = find(['price', 'selling price', 'sp', 'mrp price', 'rate']);
    var iMrp = find(['mrp', 'list price', 'max retail price']);
    var iCode = find(['code', 'sku', 'barcode', 'product code', 'item code']);
    var iSize = find(['size', 'variant', 'weight', 'pack']);
    var iCopies = find(['copies', 'qty', 'quantity', 'labels']);

    var out = [];
    for (var r = 1; r < rows.length; r++) {
      var cells = rows[r];
      if (!cells.join('').trim()) continue;
      var name = iName >= 0 ? (cells[iName] || '').trim() : (cells[0] || '').trim();
      if (!name) continue;
      out.push({
        name: name,
        price: toAmount(iPrice >= 0 ? cells[iPrice] : ''),
        mrp: toAmount(iMrp >= 0 ? cells[iMrp] : ''),
        code: iCode >= 0 ? (cells[iCode] || '').trim() : '',
        size: iSize >= 0 ? (cells[iSize] || '').trim() : '',
        copies: Math.max(1, Math.min(500, parseInt(iCopies >= 0 ? cells[iCopies] : '1', 10) || 1))
      });
    }
    return out;
  }

  function productsToCSV(products) {
    var head = ['name', 'price', 'mrp', 'code', 'size', 'copies'];
    var lines = [head.join(',')];
    products.forEach(function (p) {
      var cells = [p.name, p.price, p.mrp, p.code, p.size, p.copies].map(function (v) {
        var s = String(v == null ? '' : v);
        return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
      });
      lines.push(cells.join(','));
    });
    return lines.join('\n') + '\n';
  }

  /* ------------------------------------------------------------------ *
   * 8. Label sheet layouts (millimetres)
   * ------------------------------------------------------------------ */

  var SHEETS = {
    'a4-24': {
      name: 'A4 — 24 labels (3 \u00d7 8)',
      note: '63.5 \u00d7 33.9 mm stickers. The common 24-up A4 sheet.',
      page: { w: 210, h: 297 },
      margin: { t: 12.7, l: 4.65 },
      cols: 3, rows: 8,
      label: { w: 63.5, h: 33.9 },
      gap: { x: 2.5, y: 0 }
    },
    'a4-40': {
      name: 'A4 — 40 labels (4 \u00d7 10)',
      note: '48.3 \u00d7 25.4 mm stickers. Small price tags for shelves and boxes.',
      page: { w: 210, h: 297 },
      margin: { t: 10.7, l: 6.4 },
      cols: 4, rows: 10,
      label: { w: 48.3, h: 25.4 },
      gap: { x: 0, y: 0 }
    },
    'a4-14': {
      name: 'A4 — 14 labels (2 \u00d7 7)',
      note: '99 \u00d7 38.1 mm labels. Big shelf labels with room for a QR code.',
      page: { w: 210, h: 297 },
      margin: { t: 12.7, l: 4.65 },
      cols: 2, rows: 7,
      label: { w: 99, h: 38.1 },
      gap: { x: 2.5, y: 0 }
    },
    'roll-50x25': {
      name: 'Label roll — 50 \u00d7 25 mm (one per page)',
      note: 'For thermal label printers. Prints one label per page at the exact roll size.',
      page: { w: 50, h: 25 },
      margin: { t: 0, l: 0 },
      cols: 1, rows: 1,
      label: { w: 50, h: 25 },
      gap: { x: 0, y: 0 }
    },
    'roll-38x25': {
      name: 'Label roll — 38 \u00d7 25 mm (one per page)',
      note: 'For small thermal label printers and handheld label makers.',
      page: { w: 38, h: 25 },
      margin: { t: 0, l: 0 },
      cols: 1, rows: 1,
      label: { w: 38, h: 25 },
      gap: { x: 0, y: 0 }
    }
  };

  /** How many labels fit on one sheet of the chosen layout. */
  function perSheet(sheetId) {
    var s = SHEETS[sheetId] || SHEETS['a4-24'];
    return s.cols * s.rows;
  }

  /** Expand the product list into a flat list of labels, honouring copies. */
  function expandLabels(products, limit) {
    var out = [];
    (products || []).forEach(function (p) {
      var n = Math.max(1, parseInt(p.copies, 10) || 1);
      for (var i = 0; i < n; i++) {
        if (limit && out.length >= limit) return;
        out.push(p);
      }
    });
    return out;
  }

  /* ------------------------------------------------------------------ *
   * 9. Small helpers used by the UI
   * ------------------------------------------------------------------ */

  /** Make a short SKU from a product name when the shop has no codes yet. */
  function suggestCode(name, index) {
    var words = String(name || '').toUpperCase().replace(/[^A-Z0-9 ]/g, '').split(/\s+/).filter(Boolean);
    var initials = words.slice(0, 3).map(function (w) { return w.charAt(0); }).join('');
    if (!initials) initials = 'SKU';
    var n = String((index || 0) + 1);
    while (n.length < 4) n = '0' + n;
    return initials + n;
  }

  /** Percentage discount between MRP and selling price, or 0. */
  function discountPct(mrp, price) {
    var m = Number(mrp) || 0, p = Number(price) || 0;
    if (m <= 0 || p <= 0 || p >= m) return 0;
    return Math.round(((m - p) / m) * 100);
  }

  return {
    // barcodes
    code128Bits: code128Bits,
    code128Svg: code128Svg,
    ean13Bits: ean13Bits,
    ean13Svg: ean13Svg,
    ean13CheckDigit: ean13CheckDigit,
    // qr
    qrMatrix: qrMatrix,
    qrSvg: qrSvg,
    // helpers
    upiUri: upiUri,
    formatINR: formatINR,
    toAmount: toAmount,
    parseCSV: parseCSV,
    csvToProducts: csvToProducts,
    productsToCSV: productsToCSV,
    SHEETS: SHEETS,
    perSheet: perSheet,
    expandLabels: expandLabels,
    suggestCode: suggestCode,
    discountPct: discountPct,
    esc: esc
  };
});
