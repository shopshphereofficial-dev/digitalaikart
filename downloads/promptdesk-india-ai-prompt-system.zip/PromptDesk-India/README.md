# PromptDesk India — 120 business AI prompts

Version 1.0 · 12 November 2026 · works offline · no account, no subscription

## What this is

120 prompts written for Indian small businesses, shops, clinics, freelancers and
service providers. Each one is a complete instruction you can paste into ChatGPT,
Google Gemini, Claude, Microsoft Copilot, Perplexity or any other assistant.
Every prompt has [BRACKETS] where your own details go.

Nothing here talks to the internet by itself. The app is one HTML file that runs
in your browser from your own computer or phone.

## What is in the folder

    index.html          The library app. Double-click to open. Works offline.
    prompts.json        All 120 prompts as structured data (for your own tools).
    prompts.csv         The same prompts in a spreadsheet you can search and sort.
    QUICK-START.txt     One page: how to get a useful answer in five minutes.
    examples/           Three worked examples with real filled-in prompts.
    LICENSE.txt         What you may and may not do with these files.

## Opening the app

1. Unzip the folder somewhere you will find it again (Desktop or Documents).
2. Double-click `index.html`. It opens in your browser — Chrome, Edge, Safari,
   Firefox, on Windows, Mac, Android or iPhone.
3. Bookmark it if you use it daily.

No installation, no login, no internet needed after the file is on your device.
The only thing that needs internet is the AI assistant you paste the prompt into.

## The five-minute routine

1. Search the library for the job in front of you — "price", "review", "GST",
   "reel", "invoice", "supplier".
2. Open the prompt. Fill the boxes. Anything you leave blank stays as a bracket.
3. Tap **Copy prompt**. Paste into your AI assistant. Send.
4. Read the answer and give one instruction to improve it. The second pass is
   where most of the value is.

## Three habits that make every prompt work better

**Give it your numbers.** "Sales are slow" gets you generic advice. "Sales fell
from ₹4.2 lakh in August to ₹3.1 lakh in September, rent is ₹60,000 and I have
three staff" gets you an answer about your business.

**Say what to avoid.** No jargon, no invented statistics, no motivational
endings, under 60 words. Assistants follow exclusions more reliably than they
follow instructions to "be good".

**Ask for the format.** A table, five bullets, a WhatsApp message under 60 words.
The shape of the answer is often more useful than the content, because you can
act on it immediately.

## The Builder tab

When no prompt fits, use **Builder**. Six fields: who the AI should be, the task,
the context it cannot guess, the format you want back, the rules, and the reply
language. The prompt assembles as you type. Save it to your stack and reuse it.

## My stack

Tap **Save to stack** on any prompt. Your stack lives in this browser's local
storage on this device. **Download stack as .txt** gives you a plain text file you
can keep in your notes or move to another device. Nothing is uploaded anywhere.

## Compatibility

- Any modern browser: Chrome, Edge, Firefox, Safari, Samsung Internet, Opera.
- Windows, macOS, Linux, Android, iOS, iPadOS.
- Any AI assistant. Prompts are model-neutral: no vendor-specific syntax.
- The CSV opens in Excel, Google Sheets, LibreOffice or Numbers.

## Honest limits

- An AI answer is a first draft. Check every price, tax figure, legal clause and
  health claim yourself, and use a qualified professional where it matters.
- These prompts do not guarantee sales, ranking, followers or income. They save
  the time you would spend writing instructions.
- AI assistants change. If a prompt returns something odd, add one line: "Follow
  the format exactly and do not add commentary."

## Support

Reply to the email your download link came from, or message the store on WhatsApp
with your order reference. Include the prompt ID (for example F01) if a specific
prompt is not behaving.
