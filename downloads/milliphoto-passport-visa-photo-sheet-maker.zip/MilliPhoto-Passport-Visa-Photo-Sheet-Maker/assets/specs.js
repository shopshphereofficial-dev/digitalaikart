/* ==========================================================================
   MilliPhoto — specs.js
   Pure geometry, size presets and sheet maths. No DOM, no globals besides
   MilliPhotoSpecs, so it can be unit-tested outside the browser.
   All physical units are millimetres unless the name says px.
   ========================================================================== */
var MilliPhotoSpecs = (function () {
  'use strict';

  var MM_PER_INCH = 25.4;

  /* ---------------------------------------------------------------- presets
     headMin / headMax  : acceptable chin-to-crown head height in mm
     chinFromBottom     : where the chin sits, measured up from the bottom edge
     bg                 : the background the receiving authority asks for
     src                : who publishes the rule, so the user can check it
  ------------------------------------------------------------------------ */
  var PRESETS = [
    {
      id: 'in-passport', label: 'Indian passport — 51 × 51 mm (Passport Seva)',
      group: 'India', w: 51, h: 51, headMin: 25, headMax: 35, chinFromBottom: 7,
      bg: 'Plain white, no shadow',
      src: 'Passport Seva / MEA photo specification for physical photographs',
      note: 'The square white-background photo Passport Seva asks for when a physical photograph is required (minors, and forms that still take a pasted photo).'
    },
    {
      id: 'in-forms', label: 'PAN, Aadhaar, exam & job forms — 35 × 45 mm',
      group: 'India', w: 35, h: 45, headMin: 25, headMax: 32, chinFromBottom: 5,
      bg: 'White or very light',
      src: 'Common Indian form size (3.5 × 4.5 cm)',
      note: 'The everyday Indian "passport size" photo: PAN, Aadhaar update, SSC/UPSC and state exam forms, school and college records.'
    },
    {
      id: 'in-stamp', label: 'Stamp size — 20 × 25 mm',
      group: 'India', w: 20, h: 25, headMin: 14, headMax: 19, chinFromBottom: 3,
      bg: 'White',
      src: 'Common Indian stamp-photo size (2 × 2.5 cm)',
      note: 'The small photo pasted on admission forms, ID cards and application sheets.'
    },
    {
      id: 'us-visa', label: 'US visa / US passport — 51 × 51 mm (2 × 2 in)',
      group: 'Visa & passport abroad', w: 51, h: 51, headMin: 25, headMax: 35, chinFromBottom: 7,
      bg: 'Plain white or off-white',
      src: 'US Department of State — DS-160 / passport photo composition',
      note: 'Head 1 inch to 1 3/8 inch (25–35 mm) chin to crown, square 2 × 2 inch frame, white background, taken within the last six months.'
    },
    {
      id: 'schengen', label: 'Schengen / Europe visa — 35 × 45 mm',
      group: 'Visa & passport abroad', w: 35, h: 45, headMin: 32, headMax: 36, chinFromBottom: 4,
      bg: 'Light grey or white',
      src: 'ICAO Doc 9303 composition used by Schengen consulates',
      note: 'Head must fill most of the frame — about 70–80% of the height. Grey or white background depending on the consulate.'
    },
    {
      id: 'uk-passport', label: 'UK passport / visa — 35 × 45 mm',
      group: 'Visa & passport abroad', w: 35, h: 45, headMin: 29, headMax: 34, chinFromBottom: 4,
      bg: 'Plain light grey or cream',
      src: 'HM Passport Office photo rules',
      note: 'Plain light-coloured background, no glasses, neutral expression, mouth closed.'
    },
    {
      id: 'canada-visa', label: 'Canada visa / PR — 35 × 45 mm',
      group: 'Visa & passport abroad', w: 35, h: 45, headMin: 31, headMax: 36, chinFromBottom: 4,
      bg: 'Plain white or light',
      src: 'IRCC temporary resident visa photo specification',
      note: 'Head 31–36 mm chin to crown, and the frame must show the full head and shoulders.'
    },
    {
      id: 'custom', label: 'Custom size (type your own mm)',
      group: 'Custom', w: 35, h: 45, headMin: 0, headMax: 0, chinFromBottom: 0,
      bg: 'Whatever the form asks for',
      src: 'Your own specification',
      note: 'Use this when a form gives you a size in centimetres, inches or pixels. Guides are switched off for custom sizes.'
    }
  ];

  var PAGES = [
    { id: 'a4', label: 'A4 — 210 × 297 mm', w: 210, h: 297 },
    { id: 'a5', label: 'A5 — 148 × 210 mm', w: 148, h: 210 },
    { id: '4x6', label: 'Photo paper 4 × 6 in — 102 × 152 mm', w: 101.6, h: 152.4 },
    { id: '5x7', label: 'Photo paper 5 × 7 in — 127 × 178 mm', w: 127, h: 177.8 },
    { id: 'letter', label: 'US Letter — 216 × 279 mm', w: 215.9, h: 279.4 }
  ];

  /* ------------------------------------------------------------------ maths */
  function mmToPx(mm, dpi) { return mm / MM_PER_INCH * dpi; }
  function pxToMm(px, dpi) { return px * MM_PER_INCH / dpi; }
  function inToMm(inches) { return inches * MM_PER_INCH; }
  function cmToMm(cm) { return cm * 10; }

  function round(n, dp) {
    var f = Math.pow(10, dp == null ? 2 : dp);
    return Math.round(n * f) / f;
  }

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  /* Given a source image and a target output box, work out where to draw the
     image so that it always covers the box (no white edges), with a zoom
     multiplier and an offset expressed as a fraction of the output box. */
  function cropDrawParams(imgW, imgH, outW, outH, zoom, offX, offY) {
    var z = zoom > 0 ? zoom : 1;
    var cover = Math.max(outW / imgW, outH / imgH) * z;
    var dw = imgW * cover;
    var dh = imgH * cover;
    var dx = (outW - dw) / 2 + (offX || 0) * outW;
    var dy = (outH - dh) / 2 + (offY || 0) * outH;
    /* keep the image covering the box */
    if (dw >= outW) { dx = clamp(dx, outW - dw, 0); } else { dx = (outW - dw) / 2; }
    if (dh >= outH) { dy = clamp(dy, outH - dh, 0); } else { dy = (outH - dh) / 2; }
    return { dx: dx, dy: dy, dw: dw, dh: dh, scale: cover };
  }

  /* Effective resolution of the crop: the number of source pixels that land
     inside the output box. Used to warn before printing something soft. */
  function effectiveSourcePx(imgW, imgH, outW, outH, zoom, offX, offY) {
    var p = cropDrawParams(imgW, imgH, outW, outH, zoom, offX, offY);
    var srcW = outW / p.scale;
    var srcH = outH / p.scale;
    return {
      w: Math.min(srcW, imgW), h: Math.min(srcH, imgH),
      needW: outW, needH: outH,
      ok: srcW >= outW - 0.5 && srcH >= outH - 0.5
    };
  }

  /* How many photos fit on the page, and where each one goes (top-left of the
     photo in mm from the top-left of the page). */
  function sheetLayout(o) {
    var pageW = o.pageW, pageH = o.pageH;
    var photoW = o.photoW, photoH = o.photoH;
    var margin = o.margin == null ? 6 : o.margin;
    var gap = o.gap == null ? 2 : o.gap;

    var usableW = pageW - 2 * margin;
    var usableH = pageH - 2 * margin;
    var maxCols = Math.max(0, Math.floor((usableW + gap) / (photoW + gap)));
    var maxRows = Math.max(0, Math.floor((usableH + gap) / (photoH + gap)));
    var maxTotal = maxCols * maxRows;

    var wanted = o.copies == null ? 0 : Math.floor(o.copies);
    var total = wanted > 0 ? Math.min(wanted, maxTotal) : maxTotal;

    var cols = maxCols;
    var rows = maxRows;
    if (wanted > 0 && total < maxTotal) {
      cols = Math.min(maxCols, Math.max(1, total));
      rows = Math.ceil(total / cols);
    }

    var gridW = cols * photoW + (cols - 1) * gap;
    var gridH = rows * photoH + (rows - 1) * gap;
    var startX = (pageW - gridW) / 2;
    var startY = (pageH - gridH) / 2;

    var items = [];
    for (var i = 0; i < total; i++) {
      var c = i % cols;
      var r = Math.floor(i / cols);
      items.push({
        x: startX + c * (photoW + gap),
        y: startY + r * (photoH + gap)
      });
    }

    return {
      cols: cols, rows: rows, total: total, maxCols: maxCols, maxRows: maxRows,
      maxTotal: maxTotal, items: items, pageW: pageW, pageH: pageH,
      photoW: photoW, photoH: photoH, margin: margin, gap: gap,
      startX: startX, startY: startY
    };
  }

  /* Guide geometry for the crop editor, in output pixels. Returns null when
     the preset has no head specification (custom sizes). */
  function guideGeometry(preset, outW, outH, dpi) {
    if (!preset || !preset.headMin || !preset.headMax || !preset.chinFromBottom) return null;
    var chin = outH - mmToPx(preset.chinFromBottom, dpi);
    var bandTop = outH - mmToPx(preset.chinFromBottom + preset.headMax, dpi);
    var bandBottom = outH - mmToPx(preset.chinFromBottom + preset.headMin, dpi);
    var eye = outH - mmToPx(preset.chinFromBottom + 0.45 * (preset.headMin + preset.headMax) / 2, dpi);
    return { chin: chin, bandTop: bandTop, bandBottom: bandBottom, eye: eye };
  }

  /* A quick, honest read on the background: sample four corner patches of the
     source image and look at how even and how bright they are. */
  function judgeBackground(patchStats) {
    if (!patchStats || !patchStats.length) return { level: 'unknown', text: 'Background could not be sampled.' };
    var mean = 0, sd = 0, i;
    for (i = 0; i < patchStats.length; i++) { mean += patchStats[i].mean; sd += patchStats[i].sd; }
    mean = mean / patchStats.length;
    sd = sd / patchStats.length;

    var spread = 0, min = 255, max = 0;
    for (i = 0; i < patchStats.length; i++) {
      if (patchStats[i].mean < min) min = patchStats[i].mean;
      if (patchStats[i].mean > max) max = patchStats[i].mean;
    }
    spread = max - min;

    if (sd <= 12 && spread <= 26 && mean >= 200) {
      return { level: 'good', mean: round(mean, 0), sd: round(sd, 1), text: 'Corners are bright and even — this looks like a plain light background.' };
    }
    if (sd <= 22 && spread <= 45 && mean >= 150) {
      return { level: 'fair', mean: round(mean, 0), sd: round(sd, 1), text: 'Corners are fairly even but a little dark. Most authorities accept light grey; check yours before printing.' };
    }
    return { level: 'poor', mean: round(mean, 0), sd: round(sd, 1), text: 'Corners are uneven or dark, which suggests a busy or shadowed background. Many authorities reject this. A plain wall with even light works better.' };
  }

  function fileSizeText(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  }

  function safeName(s) {
    return String(s || 'photo').replace(/\.[a-z0-9]+$/i, '').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase() || 'photo';
  }

  return {
    MM_PER_INCH: MM_PER_INCH,
    PRESETS: PRESETS,
    PAGES: PAGES,
    mmToPx: mmToPx,
    pxToMm: pxToMm,
    inToMm: inToMm,
    cmToMm: cmToMm,
    round: round,
    clamp: clamp,
    cropDrawParams: cropDrawParams,
    effectiveSourcePx: effectiveSourcePx,
    sheetLayout: sheetLayout,
    guideGeometry: guideGeometry,
    judgeBackground: judgeBackground,
    fileSizeText: fileSizeText,
    safeName: safeName
  };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = MilliPhotoSpecs; }
