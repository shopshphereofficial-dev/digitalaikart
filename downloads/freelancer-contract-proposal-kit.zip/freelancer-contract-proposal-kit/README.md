# Freelancer Contract & Proposal Kit — India Edition

Seven print-ready documents for Indian freelancers and small studios. Fill them in your browser,
print or save as PDF, and sign. No install, no sign-up, no internet needed.

## What's inside

```
START-HERE.html              Open this first — links to every document
documents/
  service-agreement.html     Your master contract
  nda-mutual.html            Mutual NDA
  freelance-proposal.html    Project proposal
  scope-of-work.html         SOW (Annexure A)
  change-request.html        Change request / work order
  payment-receipt.html       Payment receipt
  payment-reminder-scripts.html  4 escalating reminder templates
docx/                        The same documents as editable Word (.docx) files
sample/
  service-agreement-example-filled.html   A fictional, labelled example
LICENSE.txt                  What you may do with these files
```

## How to use

1. Open `START-HERE.html` (double-click it, or open in any browser).
2. Open the document you need, click any highlighted field, and type over it.
   Your typing is saved automatically in that browser.
3. Click **Print / Save as PDF** (or Ctrl/Cmd + P). Choose A4 and enable
   "Background graphics" for the best result.
4. Sign and send. Each document ends with a signature block.

Prefer Word? Use the files in `docx/` in Microsoft Word, Google Docs, Pages or LibreOffice.

## Tips

- Use the **Services Agreement** as your master contract, and attach the **SOW** as Annexure A.
- Never start work without a signed agreement and an advance.
- Log every out-of-scope request in a **Change Request** before doing the work.
- Keep the paper trail: agreement, SOW, change requests, invoices and payment receipts.

## Compatibility

- Browsers: current Chrome, Edge, Firefox, Safari, Brave, Opera — desktop and mobile.
- Works fully offline. Nothing is uploaded; saved drafts stay in your own browser.
- Word files: Microsoft Word 2016+, Google Docs, Apple Pages, LibreOffice.

## Important

These are general-purpose templates for reference and drafting — **not legal advice**.
Confirm GST, TDS and stamp-duty positions with a chartered accountant or advocate, and have a
professional review anything high-value, complex or cross-border.

Support: lonefaisal977@gmail.com
