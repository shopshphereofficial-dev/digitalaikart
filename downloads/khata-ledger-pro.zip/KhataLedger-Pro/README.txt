KHATALEDGER PRO — Udhaar Khata, Ageing & Reminder Studio
India Edition 2026 · v1.0
Digitalaikart, a brand of UTILITYNEST · lonefaisal977@gmail.com

WHAT THIS IS
-----------
An offline web application for keeping a shop's udhaar (credit) khata:
customer balances, ageing of dues, printable statements, WhatsApp
reminders and CSV exports. It runs from a folder on your own computer
in Chrome, Edge, Firefox or Safari. No install, no account, no
subscription, no internet connection after the download, no data
leaving your machine.

FILES
-----
  index.html          The app. Double-click this file.
  app.js              Application logic. Keep beside index.html.
  styles.css          Styling. Keep beside index.html.
  START-HERE.html     Full illustrated guide — read this first.
  example-khata.json  Sample book (6 fake customers, all marked EXAMPLE).
  README.txt          This file.
  LICENSE.txt         Licence terms.

QUICK START (3 minutes)
-----------------------
  1. Extract the ZIP to a folder, e.g. Documents\KhataLedger.
  2. Double-click index.html. The dashboard opens in your browser.
  3. Settings -> fill in shop name, phone, UPI ID -> Save shop profile.
  4. Customers -> + New customer. Enter each customer with their
     current balance as the "Opening balance" (negative if they have
     paid in advance) and the date that balance is from.
  5. + New entry every time you give goods on credit or take money.
  6. Reminders -> press WhatsApp to open the message already written.

FEATURES
--------
- Customer book with phone, area, credit limit and notes
- "You gave" / "You got" entries with date, mode and note
- Running balance and printable A4 statement per customer
- FIFO ageing: payments settle the oldest dues first
- Ageing buckets: not due, 1-30, 31-60, 61-90, 90+ days
- Dashboard: receivable, overdue, collected this month, top debtors
- Reminders screen: WhatsApp message per customer, with your UPI ID
  and a UPI payment link for the exact balance
- Copy message to clipboard when a customer has no phone saved
- Print: customer statement, ageing report, reminder call-list
- CSV export for Excel (customers with ageing, all entries)
- JSON backup and restore
- Indian number formatting (1,23,456.78) and amount in words
- Works offline, remembers everything in the browser

WHAT IT DELIBERATELY DOES NOT DO
--------------------------------
- No GST invoices, e-invoices, e-way bills or GSTR reports.
- No cloud sync and no multi-device sharing (export/restore instead).
- It does not send WhatsApp messages by itself: it writes the message
  and opens WhatsApp, and you press send.
- It does not move money. The UPI link opens the customer's own UPI app.

IMPORTANT — YOUR DATA
---------------------
Everything is stored in this browser's local storage on this computer.
Clearing browsing data, private/incognito windows, a browser profile
reset or a new computer will lose the book. Take a backup weekly:
Settings -> Download backup (JSON), and keep the file somewhere safe.

TESTING NOTE
------------
Before release the app was checked with 54 automated unit tests on the
calculation layer (balances, FIFO ageing boundaries at 30/31, 60/61,
90/91 days, totals, CSV quoting, phone normalisation, amount in words,
date arithmetic) and 51 automated browser tests (navigation, adding and
editing customers and entries, search, sorting, statement printing,
reminder links, CSV export, persistence across reloads, wipe). All
passed. The layout was checked at 1440 px and 420 px wide.

SUPPORT
-------
Email lonefaisal977@gmail.com or WhatsApp +91 96826 00301.
If a file will not open, or a figure is calculated wrongly, send a
screenshot within 7 days and it will be fixed or refunded.
