/* ============================================================
   KhataLedger Pro — offline udhaar khata & receivables ledger
   Digitalaikart (a brand of UTILITYNEST) · India Edition 2026
   Vanilla JavaScript. No libraries, no network, no tracking.
   Data lives in this browser's localStorage only.
   ============================================================ */
(function (root) {
  'use strict';

  var STORE_KEY = 'khataLedgerPro_v1';
  var APP_VERSION = '1.0';

  /* ---------- pure helpers (also used by the test suite) ---------- */

  function pad2(n) { return (n < 10 ? '0' : '') + n; }

  function todayISO(d) {
    var x = d ? new Date(d) : new Date();
    return x.getFullYear() + '-' + pad2(x.getMonth() + 1) + '-' + pad2(x.getDate());
  }

  function parseISO(s) {
    if (!s) return null;
    var p = String(s).split('-');
    if (p.length !== 3) return null;
    var d = new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
    return isNaN(d.getTime()) ? null : d;
  }

  function daysBetween(aISO, bISO) {
    var a = parseISO(aISO), b = parseISO(bISO);
    if (!a || !b) return 0;
    return Math.round((b - a) / 86400000);
  }

  function round2(n) { return Math.round((Number(n) || 0) * 100) / 100; }

  /* Indian digit grouping: 12,34,567.50 */
  function inr(n, opts) {
    var o = opts || {};
    var v = round2(n);
    var neg = v < 0;
    v = Math.abs(v);
    var fixed = o.decimals === 0 ? String(Math.round(v)) : v.toFixed(2);
    var parts = fixed.split('.');
    var whole = parts[0];
    var last3 = whole.slice(-3);
    var rest = whole.slice(0, -3);
    if (rest) { rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ','); last3 = ',' + last3; }
    var out = rest + last3;
    if (parts[1] && o.decimals !== 0) out += '.' + parts[1];
    return (neg ? '-' : '') + out;
  }

  function money(n) { return '\u20b9' + inr(Math.abs(round2(n))); }

  var ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  var TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function twoDigits(n) {
    if (n < 20) return ONES[n];
    return TENS[Math.floor(n / 10)] + (n % 10 ? ' ' + ONES[n % 10] : '');
  }

  function threeDigits(n) {
    var out = '';
    if (n >= 100) { out = ONES[Math.floor(n / 100)] + ' Hundred'; n = n % 100; if (n) out += ' '; }
    if (n) out += twoDigits(n);
    return out;
  }

  /* Indian numbering: crore / lakh / thousand */
  function amountInWords(amount) {
    var v = round2(Math.abs(Number(amount) || 0));
    var rupees = Math.floor(v);
    var paise = Math.round((v - rupees) * 100);
    if (rupees === 0 && paise === 0) return 'Zero Rupees Only';
    var words = [];
    var crore = Math.floor(rupees / 10000000); rupees = rupees % 10000000;
    var lakh = Math.floor(rupees / 100000); rupees = rupees % 100000;
    var thousand = Math.floor(rupees / 1000); rupees = rupees % 1000;
    if (crore) words.push(threeDigits(crore) + ' Crore');
    if (lakh) words.push(threeDigits(lakh) + ' Lakh');
    if (thousand) words.push(threeDigits(thousand) + ' Thousand');
    if (rupees) words.push(threeDigits(rupees));
    var out = words.join(' ');
    if (out) out += ' Rupees';
    if (paise) out += (out ? ' and ' : '') + twoDigits(paise) + ' Paise';
    out += ' Only';
    return (Number(amount) < 0 ? 'Minus ' : '') + out;
  }

  /* ---------- ledger maths ---------- */

  function customerEntries(state, customerId) {
    return state.entries.filter(function (e) { return e.customerId === customerId; });
  }

  /* Positive = the customer owes the shop. */
  function balanceOf(state, customerId) {
    var c = state.customers.filter(function (x) { return x.id === customerId; })[0];
    if (!c) return 0;
    var bal = Number(c.opening) || 0;
    state.entries.forEach(function (e) {
      if (e.customerId !== customerId) return;
      bal += (e.type === 'got' ? -1 : 1) * (Number(e.amount) || 0);
    });
    return round2(bal);
  }

  function sortEntries(list) {
    return list.slice().sort(function (a, b) {
      if (a.date === b.date) return (a.seq || 0) - (b.seq || 0);
      return a.date < b.date ? -1 : 1;
    });
  }

  /* Statement rows with a running balance. */
  function statementRows(state, customerId) {
    var c = state.customers.filter(function (x) { return x.id === customerId; })[0];
    if (!c) return [];
    var rows = [];
    var opening = Number(c.opening) || 0;
    var bal = opening;
    rows.push({
      date: c.openingDate || c.created || '', type: 'opening', mode: '',
      note: 'Opening balance', gave: opening > 0 ? opening : 0,
      got: opening < 0 ? -opening : 0, balance: round2(bal), id: 'opening'
    });
    sortEntries(customerEntries(state, customerId)).forEach(function (e) {
      var amt = Number(e.amount) || 0;
      if (e.type === 'got') bal -= amt; else bal += amt;
      rows.push({
        date: e.date, type: e.type, mode: e.mode || '',
        note: e.note || '', gave: e.type === 'got' ? 0 : amt,
        got: e.type === 'got' ? amt : 0, balance: round2(bal), id: e.id
      });
    });
    return rows;
  }

  /* FIFO ageing: payments settle the oldest unpaid amounts first. */
  function ageingOf(state, customerId, asOfISO) {
    var asOf = asOfISO || todayISO();
    var c = state.customers.filter(function (x) { return x.id === customerId; })[0];
    var buckets = { current: 0, d30: 0, d60: 0, d90: 0, over90: 0, total: 0 };
    if (!c) return buckets;
    var open = [];
    var opening = Number(c.opening) || 0;
    if (opening > 0) {
      open.push({ date: c.openingDate || c.created || asOf, due: '', amount: round2(opening) });
    }
    var events = sortEntries(customerEntries(state, customerId));
    var credit = opening < 0 ? round2(-opening) : 0;

    events.forEach(function (e) {
      var amt = round2(Number(e.amount) || 0);
      if (e.type === 'got') { credit = round2(credit + amt); return; }
      open.push({ date: e.date, due: e.due || '', amount: amt });
    });

    /* Apply available credit to the oldest debits. */
    var i = 0;
    while (credit > 0 && i < open.length) {
      var take = Math.min(credit, open[i].amount);
      open[i].amount = round2(open[i].amount - take);
      credit = round2(credit - take);
      i++;
    }
    open.forEach(function (o) {
      if (o.amount <= 0) return;
      var ref = o.due || o.date;
      var overdue = daysBetween(ref, asOf);
      if (overdue <= 0) buckets.current = round2(buckets.current + o.amount);
      else if (overdue <= 30) buckets.d30 = round2(buckets.d30 + o.amount);
      else if (overdue <= 60) buckets.d60 = round2(buckets.d60 + o.amount);
      else if (overdue <= 90) buckets.d90 = round2(buckets.d90 + o.amount);
      else buckets.over90 = round2(buckets.over90 + o.amount);
      buckets.total = round2(buckets.total + o.amount);
    });
    return buckets;
  }

  function oldestOverdueDays(state, customerId, asOfISO) {
    var asOf = asOfISO || todayISO();
    var c = state.customers.filter(function (x) { return x.id === customerId; })[0];
    if (!c) return 0;
    var oldest = 0;
    var opening = Number(c.opening) || 0;
    if (opening > 0) {
      var d0 = daysBetween(c.openingDate || c.created || asOf, asOf);
      if (d0 > oldest) oldest = d0;
    }
    customerEntries(state, customerId).forEach(function (e) {
      if (e.type !== 'gave') return;
      var d = daysBetween(e.due || e.date, asOf);
      if (d > oldest) oldest = d;
    });
    return balanceOf(state, customerId) > 0 ? oldest : 0;
  }

  function totals(state, asOfISO) {
    var asOf = asOfISO || todayISO();
    var t = {
      receivable: 0, payable: 0, withDues: 0, overdue30: 0, overdue90: 0,
      collectedToday: 0, collectedMonth: 0, gaveMonth: 0,
      buckets: { current: 0, d30: 0, d60: 0, d90: 0, over90: 0, total: 0 }
    };
    var month = asOf.slice(0, 7);
    state.customers.forEach(function (c) {
      var bal = balanceOf(state, c.id);
      if (bal > 0) { t.receivable = round2(t.receivable + bal); t.withDues++; }
      else if (bal < 0) t.payable = round2(t.payable - bal);
      var a = ageingOf(state, c.id, asOf);
      t.buckets.current = round2(t.buckets.current + a.current);
      t.buckets.d30 = round2(t.buckets.d30 + a.d30);
      t.buckets.d60 = round2(t.buckets.d60 + a.d60);
      t.buckets.d90 = round2(t.buckets.d90 + a.d90);
      t.buckets.over90 = round2(t.buckets.over90 + a.over90);
      t.overdue30 = round2(t.overdue30 + a.d30 + a.d60 + a.d90 + a.over90);
      t.overdue90 = round2(t.overdue90 + a.over90);
    });
    t.buckets.total = round2(t.buckets.current + t.buckets.d30 + t.buckets.d60 + t.buckets.d90 + t.buckets.over90);
    state.entries.forEach(function (e) {
      var amt = round2(Number(e.amount) || 0);
      if (e.type === 'got') {
        if (e.date === asOf) t.collectedToday = round2(t.collectedToday + amt);
        if (String(e.date).slice(0, 7) === month) t.collectedMonth = round2(t.collectedMonth + amt);
      } else if (String(e.date).slice(0, 7) === month) {
        t.gaveMonth = round2(t.gaveMonth + amt);
      }
    });
    return t;
  }

  function monthlySummary(state, months) {
    var n = months || 6;
    var out = [];
    var now = new Date();
    for (var i = n - 1; i >= 0; i--) {
      var d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      var key = d.getFullYear() + '-' + pad2(d.getMonth() + 1);
      out.push({
        key: key,
        label: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][d.getMonth()] + ' ' + d.getFullYear(),
        gave: 0, got: 0
      });
    }
    state.entries.forEach(function (e) {
      var key = String(e.date).slice(0, 7);
      var row = out.filter(function (r) { return r.key === key; })[0];
      if (!row) return;
      if (e.type === 'got') row.got = round2(row.got + (Number(e.amount) || 0));
      else row.gave = round2(row.gave + (Number(e.amount) || 0));
    });
    return out;
  }

  /* ---------- phones, links, csv ---------- */

  function normalizePhone(p) {
    var d = String(p || '').replace(/[^0-9]/g, '');
    if (!d) return '';
    if (d.length === 10) d = '91' + d;
    if (d.length === 11 && d.charAt(0) === '0') d = '91' + d.slice(1);
    if (d.length === 12 && d.slice(0, 2) === '91') return d;
    if (d.length === 13 && d.slice(0, 3) === '091') return d.slice(1);
    return d;
  }

  function waLink(phone, text) {
    var p = normalizePhone(phone);
    return 'https://wa.me/' + p + '?text=' + encodeURIComponent(text || '');
  }

  function reminderText(shop, customer, balance, days, asOfISO) {
    var lines = [];
    lines.push('Namaste ' + (customer.name || 'ji') + ',');
    lines.push('');
    if (balance > 0) {
      lines.push('This is a gentle reminder from ' + (shop.name || 'our shop') + '.');
      lines.push('Your khata balance is ' + money(balance) + ' as on ' + fmtDate(asOfISO || todayISO()) + '.');
      if (days > 0) lines.push('The oldest amount has been pending ' + days + ' day' + (days === 1 ? '' : 's') + '.');
      if (shop.upi) lines.push('');
      if (shop.upi) lines.push('You can pay by UPI to: ' + shop.upi);
      if (shop.upi) lines.push('UPI link: ' + upiLink(shop, balance, customer));
    } else {
      lines.push('Thank you for your payment. Your khata with ' + (shop.name || 'our shop') + ' is clear.');
    }
    lines.push('');
    lines.push('If you have already paid, please ignore this message and share the payment reference.');
    if (shop.phone) lines.push('');
    if (shop.phone) lines.push(shop.name + ' \u00b7 ' + shop.phone);
    return lines.join('\n');
  }

  function upiLink(shop, amount, customer) {
    if (!shop.upi) return '';
    var q = 'pa=' + encodeURIComponent(shop.upi) +
      '&pn=' + encodeURIComponent(shop.name || 'Shop') +
      '&am=' + (round2(amount) || 0).toFixed(2) +
      '&cu=INR';
    if (shop.name) q += '&tn=' + encodeURIComponent('Khata payment' + (customer && customer.name ? ' - ' + customer.name : ''));
    return 'upi://pay?' + q;
  }

  function fmtDate(iso) {
    var d = parseISO(iso);
    if (!d) return '';
    var M = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return pad2(d.getDate()) + ' ' + M[d.getMonth()] + ' ' + d.getFullYear();
  }

  function csvCell(v) {
    var s = v === null || v === undefined ? '' : String(v);
    if (/[",\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  function toCsv(header, rows) {
    var out = [header.map(csvCell).join(',')];
    rows.forEach(function (r) { out.push(r.map(csvCell).join(',')); });
    /* BOM so Excel opens Indian characters correctly */
    return '\ufeff' + out.join('\r\n') + '\r\n';
  }

  function customersCsv(state, asOfISO) {
    var asOf = asOfISO || todayISO();
    var rows = state.customers.map(function (c) {
      var a = ageingOf(state, c.id, asOf);
      return [c.name, c.phone || '', c.address || '', balanceOf(state, c.id),
        a.current, a.d30, a.d60, a.d90, a.over90,
        oldestOverdueDays(state, c.id, asOf), c.limit || 0, c.note || ''];
    });
    return toCsv(['Customer', 'Phone', 'Address', 'Balance', 'Not due', '1-30 days', '31-60 days',
      '61-90 days', '90+ days', 'Oldest overdue (days)', 'Credit limit', 'Note'], rows);
  }

  function entriesCsv(state) {
    var byId = {};
    state.customers.forEach(function (c) { byId[c.id] = c; });
    var rows = sortEntries(state.entries).map(function (e) {
      var c = byId[e.customerId] || {};
      return [e.date, c.name || '(deleted)', e.type === 'got' ? 'You got' : 'You gave',
        Number(e.amount) || 0, e.mode || '', e.due || '', e.note || ''];
    });
    return toCsv(['Date', 'Customer', 'Type', 'Amount', 'Mode', 'Due date', 'Note'], rows);
  }

  function newId(prefix) {
    return (prefix || 'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  var api = {
    STORE_KEY: STORE_KEY, APP_VERSION: APP_VERSION,
    todayISO: todayISO, parseISO: parseISO, daysBetween: daysBetween,
    inr: inr, money: money, round2: round2, amountInWords: amountInWords,
    balanceOf: balanceOf, statementRows: statementRows, ageingOf: ageingOf,
    oldestOverdueDays: oldestOverdueDays, totals: totals, monthlySummary: monthlySummary,
    normalizePhone: normalizePhone, waLink: waLink, reminderText: reminderText,
    upiLink: upiLink, fmtDate: fmtDate, toCsv: toCsv, customersCsv: customersCsv,
    entriesCsv: entriesCsv, newId: newId, sortEntries: sortEntries, customerEntries: customerEntries
  };

  root.KhataCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;

  /* ---------- browser application ---------- */
  if (typeof document === 'undefined') return;

  var state = { shop: {}, customers: [], entries: [] };
  var ui = { view: 'dashboard', customerId: null, search: '', from: '', to: '', sort: 'balance' };

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  function esc(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function defaultShop() {
    return { name: 'Your Shop Name', owner: '', phone: '', address: '', upi: '', gstin: '', footer: 'Thank you for your business.' };
  }

  function load() {
    try {
      var raw = localStorage.getItem(STORE_KEY);
      if (!raw) return false;
      var d = JSON.parse(raw);
      state.shop = Object.assign(defaultShop(), d.shop || {});
      state.customers = Array.isArray(d.customers) ? d.customers : [];
      state.entries = Array.isArray(d.entries) ? d.entries : [];
      return true;
    } catch (err) {
      console.warn('Could not read saved data:', err);
      return false;
    }
  }

  function save() {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({
        version: APP_VERSION, shop: state.shop,
        customers: state.customers, entries: state.entries, savedAt: new Date().toISOString()
      }));
      return true;
    } catch (err) {
      alert('Could not save to this browser\'s storage. Take a backup from Settings and keep it safe.\n\n' + err.message);
      return false;
    }
  }

  function customerById(id) {
    return state.customers.filter(function (c) { return c.id === id; })[0];
  }

  function toast(msg) {
    var t = $('#toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, 2600);
  }

  /* ---------- view routing ---------- */
  function go(view, customerId) {
    ui.view = view;
    if (customerId !== undefined) ui.customerId = customerId;
    $$('.nav-item').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-view') === view);
    });
    window.scrollTo(0, 0);
    render();
  }

  function render() {
    var host = $('#view');
    if (!host) return;
    if (ui.view === 'dashboard') host.innerHTML = viewDashboard();
    else if (ui.view === 'customers') host.innerHTML = viewCustomers();
    else if (ui.view === 'ledger') host.innerHTML = viewLedger();
    else if (ui.view === 'reminders') host.innerHTML = viewReminders();
    else if (ui.view === 'reports') host.innerHTML = viewReports();
    else if (ui.view === 'settings') host.innerHTML = viewSettings();
    else host.innerHTML = viewDashboard();
    $('#shopLabel').textContent = state.shop.name || 'Your Shop';
    $('#dataBadge').textContent = state.customers.length + ' customers \u00b7 ' + state.entries.length + ' entries';
  }

  function statCard(label, value, sub, tone) {
    return '<div class="stat-card ' + (tone || '') + '"><div class="stat-label">' + esc(label) + '</div>' +
      '<div class="stat-value">' + value + '</div><div class="stat-sub">' + esc(sub || '') + '</div></div>';
  }

  function viewDashboard() {
    var asOf = todayISO();
    var t = totals(state, asOf);
    var debtors = state.customers.map(function (c) {
      return { c: c, bal: balanceOf(state, c.id), days: oldestOverdueDays(state, c.id, asOf) };
    }).filter(function (x) { return x.bal > 0; })
      .sort(function (a, b) { return b.bal - a.bal; });

    var recent = sortEntries(state.entries).slice(-8).reverse();
    var byId = {};
    state.customers.forEach(function (c) { byId[c.id] = c; });

    var html = '';
    html += '<div class="view-head"><div><h1>Dashboard</h1><p class="muted">' + esc(fmtDate(asOf)) + ' \u00b7 every figure is calculated from your own entries</p></div>' +
      '<div class="head-actions"><button class="btn btn-gold" data-act="new-entry">+ New entry</button>' +
      '<button class="btn" data-act="new-customer">+ Customer</button></div></div>';

    html += '<div class="stats">' +
      statCard('Total receivable', money(t.receivable), t.withDues + ' customer' + (t.withDues === 1 ? '' : 's') + ' owe you', 'primary') +
      statCard('Overdue 31+ days', money(t.overdue30), 'of which 90+ days: ' + money(t.overdue90), t.overdue30 > 0 ? 'warn' : '') +
      statCard('Collected this month', money(t.collectedMonth), 'today: ' + money(t.collectedToday), 'good') +
      statCard('Given on credit this month', money(t.gaveMonth), 'advances held: ' + money(t.payable)) +
      '</div>';

    if (!state.customers.length) {
      html += '<div class="empty"><h2>Start with one customer</h2>' +
        '<p>A khata is only as good as its first page. Add a customer, then record what you gave on credit and what came back. ' +
        'If you want to see how the app behaves first, load the sample book from Settings.</p>' +
        '<button class="btn btn-gold" data-act="new-customer">Add your first customer</button> ' +
        '<button class="btn" data-act="demo">Load sample book</button></div>';
      return html;
    }

    html += '<div class="grid-2">';
    html += '<div class="panel"><div class="panel-head"><h2>Who owes you the most</h2><button class="link" data-view="customers">All customers \u2192</button></div>';
    if (!debtors.length) {
      html += '<p class="muted pad">No pending balances. Every khata is settled.</p>';
    } else {
      html += '<table class="tbl"><thead><tr><th>Customer</th><th class="num">Balance</th><th class="num">Oldest</th><th></th></tr></thead><tbody>';
      debtors.slice(0, 6).forEach(function (x) {
        html += '<tr><td><button class="link strong" data-ledger="' + x.c.id + '">' + esc(x.c.name) + '</button>' +
          (x.c.phone ? '<div class="tiny muted">' + esc(x.c.phone) + '</div>' : '') + '</td>' +
          '<td class="num strong">' + money(x.bal) + '</td>' +
          '<td class="num">' + (x.days > 0 ? '<span class="pill ' + (x.days > 60 ? 'red' : 'amber') + '">' + x.days + ' d</span>' : '<span class="pill grey">not due</span>') + '</td>' +
          '<td class="num"><button class="icon-btn" title="Send WhatsApp reminder" data-remind="' + x.c.id + '">\u2709</button></td></tr>';
      });
      html += '</tbody></table>';
    }
    html += '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>Recent entries</h2><button class="link" data-view="reports">Reports \u2192</button></div>';
    if (!recent.length) {
      html += '<p class="muted pad">No entries yet. Press <strong>+ New entry</strong> to write the first one.</p>';
    } else {
      html += '<table class="tbl"><thead><tr><th>Date</th><th>Customer</th><th class="num">Amount</th></tr></thead><tbody>';
      recent.forEach(function (e) {
        var c = byId[e.customerId] || { name: '(deleted)' };
        html += '<tr><td class="nowrap">' + esc(fmtDate(e.date)) + '</td>' +
          '<td>' + esc(c.name) + '<div class="tiny muted">' + esc(e.note || e.mode || '') + '</div></td>' +
          '<td class="num ' + (e.type === 'got' ? 'good-text' : '') + '">' + (e.type === 'got' ? '\u2190 ' : '\u2192 ') + money(e.amount) + '</td></tr>';
      });
      html += '</tbody></table>';
    }
    html += '</div></div>';

    html += '<div class="panel"><div class="panel-head"><h2>Ageing at a glance</h2><button class="link" data-view="reports">Full report \u2192</button></div>' +
      '<div class="buckets">' + bucketCells(t.buckets) + '</div>' +
      '<p class="tiny muted pad">Payments are applied to the oldest unpaid amount first, so the 90+ column is money that has genuinely been sitting for three months.</p></div>';
    return html;
  }

  function bucketCells(b) {
    var items = [
      ['Not due', b.current, 'grey'],
      ['1\u201330 days', b.d30, 'amber'],
      ['31\u201360 days', b.d60, 'amber'],
      ['61\u201390 days', b.d90, 'red'],
      ['90+ days', b.over90, 'red']
    ];
    return items.map(function (i) {
      return '<div class="bucket ' + i[2] + '"><div class="bucket-label">' + i[0] + '</div><div class="bucket-value">' + money(i[1]) + '</div></div>';
    }).join('');
  }

  function viewCustomers() {
    var asOf = todayISO();
    var q = ui.search.trim().toLowerCase();
    var rows = state.customers.map(function (c) {
      return {
        c: c, bal: balanceOf(state, c.id),
        days: oldestOverdueDays(state, c.id, asOf),
        a: ageingOf(state, c.id, asOf)
      };
    }).filter(function (x) {
      if (!q) return true;
      return (x.c.name || '').toLowerCase().indexOf(q) > -1 ||
        (x.c.phone || '').indexOf(q) > -1 || (x.c.address || '').toLowerCase().indexOf(q) > -1;
    });

    rows.sort(function (a, b) {
      if (ui.sort === 'name') return a.c.name.localeCompare(b.c.name);
      if (ui.sort === 'days') return b.days - a.days;
      return b.bal - a.bal;
    });

    var html = '<div class="view-head"><div><h1>Customers</h1><p class="muted">' + state.customers.length +
      ' in the book \u00b7 ' + rows.length + ' shown</p></div>' +
      '<div class="head-actions"><button class="btn btn-gold" data-act="new-customer">+ New customer</button></div></div>';

    html += '<div class="toolbar">' +
      '<input type="search" id="custSearch" placeholder="Search name, phone or area" value="' + esc(ui.search) + '">' +
      '<select id="custSort"><option value="balance"' + (ui.sort === 'balance' ? ' selected' : '') + '>Highest balance first</option>' +
      '<option value="days"' + (ui.sort === 'days' ? ' selected' : '') + '>Longest overdue first</option>' +
      '<option value="name"' + (ui.sort === 'name' ? ' selected' : '') + '>Name (A\u2013Z)</option></select>' +
      '<button class="btn" data-act="export-customers">Export CSV</button></div>';

    if (!rows.length) {
      html += '<div class="empty"><h2>' + (state.customers.length ? 'No match' : 'No customers yet') + '</h2><p>' +
        (state.customers.length ? 'Try a different search.' : 'Add a customer to open their khata.') + '</p>' +
        '<button class="btn btn-gold" data-act="new-customer">+ New customer</button></div>';
      return html;
    }

    html += '<div class="panel table-wrap"><table class="tbl wide"><thead><tr>' +
      '<th>Customer</th><th class="num">Balance</th><th class="num">Not due</th><th class="num">1\u201330</th>' +
      '<th class="num">31\u201360</th><th class="num">61\u201390</th><th class="num">90+</th><th class="num">Credit limit</th><th></th></tr></thead><tbody>';

    rows.forEach(function (x) {
      var limit = Number(x.c.limit) || 0;
      var usage = limit > 0 ? Math.min(100, Math.round((Math.max(0, x.bal) / limit) * 100)) : 0;
      html += '<tr>' +
        '<td><button class="link strong" data-ledger="' + x.c.id + '">' + esc(x.c.name) + '</button>' +
        '<div class="tiny muted">' + esc(x.c.phone || x.c.address || '') + '</div></td>' +
        '<td class="num strong ' + (x.bal < 0 ? 'good-text' : '') + '">' + money(x.bal) + '</td>' +
        '<td class="num">' + (x.a.current ? money(x.a.current) : '\u2014') + '</td>' +
        '<td class="num">' + (x.a.d30 ? money(x.a.d30) : '\u2014') + '</td>' +
        '<td class="num">' + (x.a.d60 ? money(x.a.d60) : '\u2014') + '</td>' +
        '<td class="num">' + (x.a.d90 ? money(x.a.d90) : '\u2014') + '</td>' +
        '<td class="num ' + (x.a.over90 ? 'red-text strong' : '') + '">' + (x.a.over90 ? money(x.a.over90) : '\u2014') + '</td>' +
        '<td class="num">' + (limit ? money(limit) + '<div class="bar"><span style="width:' + usage + '%"></span></div>' : '\u2014') + '</td>' +
        '<td class="num nowrap"><button class="icon-btn" data-ledger="' + x.c.id + '" title="Open khata">\u2192</button>' +
        '<button class="icon-btn" data-remind="' + x.c.id + '" title="WhatsApp reminder">\u2709</button></td></tr>';
    });
    html += '</tbody></table><p class="scroll-hint">Swipe the table sideways for the ageing and credit-limit columns.</p></div>';
    html += '<p class="tiny muted pad">The credit-limit bar fills as the balance approaches the limit you set for that customer.</p>';
    return html;
  }

  function viewLedger() {
    var c = customerById(ui.customerId);
    if (!c) { ui.view = 'customers'; return viewCustomers(); }
    var asOf = todayISO();
    var bal = balanceOf(state, c.id);
    var a = ageingOf(state, c.id, asOf);
    var days = oldestOverdueDays(state, c.id, asOf);
    var rows = statementRows(state, c.id);
    var filtered = rows.filter(function (r) {
      if (ui.from && r.date && r.date < ui.from) return false;
      if (ui.to && r.date && r.date > ui.to) return false;
      return true;
    });

    var html = '<div class="view-head"><div><button class="link" data-view="customers">\u2190 All customers</button>' +
      '<h1>' + esc(c.name) + '</h1><p class="muted">' + esc([c.phone, c.address].filter(Boolean).join(' \u00b7 ') || 'No phone or address saved') + '</p></div>' +
      '<div class="head-actions"><button class="btn btn-gold" data-act="entry-for">+ Entry</button>' +
      '<button class="btn" data-act="print-statement">Print statement</button>' +
      '<button class="btn" data-act="remind">WhatsApp reminder</button>' +
      '<button class="btn btn-quiet" data-act="edit-customer">Edit</button></div></div>';

    html += '<div class="stats">' +
      statCard('Balance', money(bal) + (bal < 0 ? ' <span class="tiny">advance</span>' : ''), bal > 0 ? 'customer owes you' : (bal < 0 ? 'you hold their advance' : 'settled'), 'primary') +
      statCard('Oldest pending', days > 0 ? days + ' days' : 'Not due', days > 0 ? 'since ' + esc(fmtDate(oldestDateFor(c.id))) : 'nothing overdue', days > 60 ? 'warn' : '') +
      statCard('Credit limit', Number(c.limit) ? money(c.limit) : 'Not set', Number(c.limit) ? (bal > Number(c.limit) ? 'over the limit' : 'within limit') : 'set one in Edit') +
      statCard('Entries', String(customerEntries(state, c.id).length), 'in this khata') +
      '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>Ageing</h2>' +
      '<div class="toolbar tight"><input type="date" id="fromDate" value="' + esc(ui.from) + '" title="From date">' +
      '<input type="date" id="toDate" value="' + esc(ui.to) + '" title="To date">' +
      '<button class="btn btn-sm" data-act="clear-dates">Clear</button></div></div>' +
      '<div class="buckets">' + bucketCells(a) + '</div></div>';

    html += '<div class="panel table-wrap"><div class="panel-head"><h2>Statement</h2><span class="tiny muted">' + filtered.length + ' rows</span></div>' +
      '<table class="tbl wide"><thead><tr><th>Date</th><th>Particulars</th><th>Mode</th>' +
      '<th class="num">You gave</th><th class="num">You got</th><th class="num">Balance</th><th></th></tr></thead><tbody>';
    filtered.forEach(function (r) {
      var isOpening = r.type === 'opening';
      html += '<tr class="' + (isOpening ? 'opening-row' : '') + '">' +
        '<td class="nowrap">' + esc(fmtDate(r.date) || '\u2014') + '</td>' +
        '<td>' + esc(isOpening ? 'Opening balance' : (r.note || (r.type === 'got' ? 'Payment received' : 'Goods on credit'))) + '</td>' +
        '<td class="tiny">' + esc(r.mode || '\u2014') + '</td>' +
        '<td class="num">' + (r.gave ? money(r.gave) : '\u2014') + '</td>' +
        '<td class="num good-text">' + (r.got ? money(r.got) : '\u2014') + '</td>' +
        '<td class="num strong">' + money(r.balance) + '</td>' +
        '<td class="num nowrap">' + (isOpening ? '' :
          '<button class="icon-btn" data-edit-entry="' + r.id + '" title="Edit">\u270e</button>' +
          '<button class="icon-btn danger" data-del-entry="' + r.id + '" title="Delete">\u2715</button>') + '</td></tr>';
    });
    html += '</tbody><tfoot><tr><td colspan="5" class="num strong">Closing balance</td><td class="num strong">' + money(bal) + '</td><td></td></tr></tfoot></table><p class="scroll-hint">Swipe the statement sideways to see the Balance column.</p></div>';

    if (bal > 0) {
      html += '<div class="panel"><div class="panel-head"><h2>In words</h2></div><p class="pad">' + esc(amountInWords(bal)) + '</p>' +
        (state.shop.upi ? '<p class="pad tiny muted">UPI payment link for this balance: <code>' + esc(upiLink(state.shop, bal, c)) + '</code></p>' : '') + '</div>';
    }
    return html;
  }

  function oldestDateFor(id) {
    var c = customerById(id);
    if (!c) return '';
    var list = customerEntries(state, id).filter(function (e) { return e.type === 'gave'; });
    var dates = list.map(function (e) { return e.due || e.date; });
    if (Number(c.opening) > 0) dates.push(c.openingDate || c.created || '');
    dates = dates.filter(Boolean).sort();
    return dates[0] || '';
  }

  function viewReminders() {
    var asOf = todayISO();
    var rows = state.customers.map(function (c) {
      return { c: c, bal: balanceOf(state, c.id), days: oldestOverdueDays(state, c.id, asOf) };
    }).filter(function (x) { return x.bal > 0; })
      .sort(function (a, b) { return (b.days - a.days) || (b.bal - a.bal); });

    var html = '<div class="view-head"><div><h1>Reminders</h1><p class="muted">One tap opens WhatsApp on your phone with the message already written. You press send \u2014 the app never messages anyone by itself.</p></div>' +
      '<div class="head-actions"><button class="btn" data-act="copy-all">Copy all as list</button>' +
      '<button class="btn" data-act="print-reminders">Print reminder list</button></div></div>';

    if (!rows.length) {
      html += '<div class="empty"><h2>Nothing to chase</h2><p>No customer has a pending balance right now.</p></div>';
      return html;
    }

    html += '<div class="panel table-wrap"><table class="tbl wide"><thead><tr><th>Customer</th><th class="num">Balance</th>' +
      '<th class="num">Oldest pending</th><th>Message preview</th><th></th></tr></thead><tbody>';
    rows.forEach(function (x) {
      var text = reminderText(state.shop, x.c, x.bal, x.days, asOf);
      html += '<tr><td><button class="link strong" data-ledger="' + x.c.id + '">' + esc(x.c.name) + '</button>' +
        '<div class="tiny muted">' + esc(x.c.phone || 'no phone saved') + '</div></td>' +
        '<td class="num strong">' + money(x.bal) + '</td>' +
        '<td class="num">' + (x.days > 0 ? '<span class="pill ' + (x.days > 60 ? 'red' : 'amber') + '">' + x.days + ' d</span>' : '<span class="pill grey">not due</span>') + '</td>' +
        '<td class="preview">' + esc(text.split('\n').slice(0, 3).join(' ')).slice(0, 130) + '\u2026</td>' +
        '<td class="num nowrap"><button class="btn btn-sm" data-remind="' + x.c.id + '">WhatsApp</button>' +
        '<button class="icon-btn" data-copy="' + x.c.id + '" title="Copy message">\u29c9</button></td></tr>';
    });
    html += '</tbody></table></div>';
    html += '<p class="tiny muted pad">Message text: "Namaste [name], your khata balance is \u20b9X as on [date]..." with your UPI ID and a UPI payment link when one is saved in Settings.</p>';
    return html;
  }

  function viewReports() {
    var asOf = todayISO();
    var t = totals(state, asOf);
    var months = monthlySummary(state, 6);
    var max = Math.max.apply(null, months.map(function (m) { return Math.max(m.gave, m.got); }).concat([1]));

    var html = '<div class="view-head"><div><h1>Reports</h1><p class="muted">As on ' + esc(fmtDate(asOf)) + ' \u00b7 built from your entries, nothing estimated</p></div>' +
      '<div class="head-actions"><button class="btn" data-act="print-ageing">Print ageing report</button>' +
      '<button class="btn" data-act="export-customers">Customers CSV</button>' +
      '<button class="btn" data-act="export-entries">Entries CSV</button></div></div>';

    html += '<div class="stats">' +
      statCard('Receivable', money(t.receivable), 'across ' + t.withDues + ' customers', 'primary') +
      statCard('Overdue 31+ days', money(t.overdue30), 'older than a month', 'warn') +
      statCard('Overdue 90+ days', money(t.overdue90), 'recovery at risk', 'warn') +
      statCard('Advances held', money(t.payable), 'customer money with you') +
      '</div>';

    html += '<div class="panel"><div class="panel-head"><h2>Ageing summary</h2></div>' +
      '<table class="tbl wide"><thead><tr><th>Bucket</th><th class="num">Amount</th><th class="num">Share</th></tr></thead><tbody>';
    [['Not due yet', t.buckets.current], ['1\u201330 days', t.buckets.d30], ['31\u201360 days', t.buckets.d60],
    ['61\u201390 days', t.buckets.d90], ['More than 90 days', t.buckets.over90]].forEach(function (b) {
      var share = t.buckets.total > 0 ? Math.round((b[1] / t.buckets.total) * 100) : 0;
      html += '<tr><td>' + b[0] + '</td><td class="num strong">' + money(b[1]) + '</td>' +
        '<td class="num"><div class="bar wide"><span style="width:' + share + '%"></span></div><span class="tiny muted">' + share + '%</span></td></tr>';
    });
    html += '<tr class="total-row"><td class="strong">Total outstanding</td><td class="num strong">' + money(t.buckets.total) + '</td><td></td></tr>';
    html += '</tbody></table></div>';

    html += '<div class="panel"><div class="panel-head"><h2>Credit given and money received</h2><span class="tiny muted">last 6 months</span></div>' +
      '<table class="tbl wide"><thead><tr><th>Month</th><th class="num">You gave</th><th class="num">You got</th><th>Trend</th></tr></thead><tbody>';
    months.forEach(function (m) {
      html += '<tr><td>' + esc(m.label) + '</td><td class="num">' + money(m.gave) + '</td><td class="num good-text">' + money(m.got) + '</td>' +
        '<td><div class="mini-bars"><span class="b1" style="height:' + Math.round((m.gave / max) * 100) + '%"></span>' +
        '<span class="b2" style="height:' + Math.round((m.got / max) * 100) + '%"></span></div></td></tr>';
    });
    html += '</tbody></table><p class="tiny muted pad">Gold bar = credit given that month. Green bar = money received.</p></div>';

    var top = state.customers.map(function (c) { return { c: c, bal: balanceOf(state, c.id) }; })
      .filter(function (x) { return x.bal > 0; }).sort(function (a, b) { return b.bal - a.bal; }).slice(0, 10);
    html += '<div class="panel"><div class="panel-head"><h2>Top 10 balances</h2></div>';
    if (!top.length) html += '<p class="muted pad">No outstanding balances.</p>';
    else {
      html += '<table class="tbl"><thead><tr><th>#</th><th>Customer</th><th class="num">Balance</th></tr></thead><tbody>';
      top.forEach(function (x, i) {
        html += '<tr><td class="muted">' + (i + 1) + '</td><td><button class="link" data-ledger="' + x.c.id + '">' + esc(x.c.name) + '</button></td>' +
          '<td class="num strong">' + money(x.bal) + '</td></tr>';
      });
      html += '</tbody></table>';
    }
    html += '</div>';
    return html;
  }

  function viewSettings() {
    var s = state.shop;
    var html = '<div class="view-head"><div><h1>Settings</h1><p class="muted">Your shop details print on every statement. They are stored in this browser only.</p></div></div>';

    html += '<div class="panel"><div class="panel-head"><h2>Shop profile</h2></div><div class="form-grid pad">' +
      field('s-name', 'Shop name', s.name) +
      field('s-owner', 'Owner name', s.owner) +
      field('s-phone', 'Phone / WhatsApp', s.phone) +
      field('s-upi', 'UPI ID for reminders', s.upi, 'e.g. shopname@okhdfcbank') +
      field('s-gstin', 'GSTIN (optional)', s.gstin) +
      field('s-footer', 'Statement footer', s.footer) +
      '<div class="field full"><label for="s-address">Address</label><textarea id="s-address" rows="2">' + esc(s.address) + '</textarea></div>' +
      '<div class="field full"><button class="btn btn-gold" data-act="save-shop">Save shop profile</button></div>' +
      '</div></div>';

    html += '<div class="panel"><div class="panel-head"><h2>Backup and restore</h2></div><div class="pad">' +
      '<p class="muted">Everything lives in this browser. Clearing browsing data, using private mode, or a new laptop will lose it. ' +
      'Take a backup file once a week and keep it in your email or Drive.</p>' +
      '<div class="head-actions"><button class="btn btn-gold" data-act="backup">Download backup (JSON)</button>' +
      '<label class="btn" for="restoreFile">Restore from backup</label>' +
      '<input type="file" id="restoreFile" accept=".json,application/json" hidden></div>' +
      '<p class="tiny muted">Restoring replaces the book in this browser with the file you choose.</p></div></div>';

    html += '<div class="panel"><div class="panel-head"><h2>Sample book</h2></div><div class="pad">' +
      '<p class="muted">Load six example customers with entries marked <strong>EXAMPLE</strong> to see the reports working. ' +
      'Your current book is replaced, so take a backup first if you have real data.</p>' +
      '<div class="head-actions"><button class="btn" data-act="demo">Load sample book</button>' +
      '<button class="btn btn-quiet" data-act="wipe">Erase all data</button></div></div></div>';

    html += '<div class="panel"><div class="panel-head"><h2>About</h2></div><div class="pad">' +
      '<p class="muted">KhataLedger Pro v' + APP_VERSION + ' \u00b7 India Edition 2026 \u00b7 \u00a9 Digitalaikart, a brand of UTILITYNEST.</p>' +
      '<p class="muted">One HTML file and one JavaScript file. No server, no account, no analytics, no internet connection needed after the download. ' +
      'Amounts are stored as plain numbers in your browser; the app does no accounting beyond arithmetic you can check on the statement.</p>' +
      '<p class="muted">Not a GST billing or e-invoice tool, and not a substitute for a chartered accountant. For statutory books, invoices and returns, keep your existing billing software.</p>' +
      '</div></div>';
    return html;
  }

  function field(id, label, value, placeholder) {
    return '<div class="field"><label for="' + id + '">' + esc(label) + '</label>' +
      '<input id="' + id + '" type="text" value="' + esc(value || '') + '"' +
      (placeholder ? ' placeholder="' + esc(placeholder) + '"' : '') + '></div>';
  }

  /* ---------- modals ---------- */
  function openModal(title, bodyHtml) {
    var m = $('#modal');
    $('#modalTitle').textContent = title;
    $('#modalBody').innerHTML = bodyHtml;
    m.classList.add('open');
    var first = $('#modalBody input, #modalBody select, #modalBody textarea');
    if (first) setTimeout(function () { first.focus(); }, 60);
  }

  function closeModal() {
    $('#modal').classList.remove('open');
    $('#modalBody').innerHTML = '';
  }

  function customerForm(c) {
    var isNew = !c;
    c = c || { name: '', phone: '', address: '', opening: 0, openingDate: todayISO(), limit: '', note: '' };
    var html = '<form id="customerForm" class="form-grid">' +
      '<div class="field full"><label for="c-name">Customer name *</label><input id="c-name" required value="' + esc(c.name) + '"></div>' +
      '<div class="field"><label for="c-phone">Phone (with WhatsApp)</label><input id="c-phone" inputmode="tel" value="' + esc(c.phone) + '" placeholder="98765 43210"></div>' +
      '<div class="field"><label for="c-limit">Credit limit (\u20b9, optional)</label><input id="c-limit" type="number" min="0" step="1" value="' + esc(c.limit === 0 ? '' : c.limit) + '"></div>' +
      '<div class="field full"><label for="c-address">Area / address</label><input id="c-address" value="' + esc(c.address) + '"></div>' +
      '<div class="field"><label for="c-opening">Opening balance (\u20b9)</label><input id="c-opening" type="number" step="0.01" value="' + esc(c.opening || '') + '" placeholder="0">' +
      '<span class="hint">Positive = they already owe you. Negative = you hold their advance.</span></div>' +
      '<div class="field"><label for="c-opening-date">Opening as on</label><input id="c-opening-date" type="date" value="' + esc(c.openingDate || todayISO()) + '"></div>' +
      '<div class="field full"><label for="c-note">Note</label><input id="c-note" value="' + esc(c.note) + '" placeholder="Shop in the next lane, pays on Sunday"></div>' +
      '<div class="field full modal-actions"><button type="button" class="btn btn-quiet" data-act="close-modal">Cancel</button>' +
      '<button type="submit" class="btn btn-gold">' + (isNew ? 'Add customer' : 'Save changes') + '</button></div>' +
      '</form>';
    openModal(isNew ? 'New customer' : 'Edit customer', html);
    $('#customerForm').addEventListener('submit', function (ev) {
      ev.preventDefault();
      var data = {
        name: $('#c-name').value.trim(),
        phone: $('#c-phone').value.trim(),
        address: $('#c-address').value.trim(),
        opening: Number($('#c-opening').value) || 0,
        openingDate: $('#c-opening-date').value || todayISO(),
        limit: Number($('#c-limit').value) || 0,
        note: $('#c-note').value.trim()
      };
      if (!data.name) { alert('A name is needed to open a khata.'); return; }
      if (isNew) {
        data.id = newId('c');
        data.created = todayISO();
        state.customers.push(data);
        save(); closeModal();
        toast('Customer added');
        go('ledger', data.id);
      } else {
        Object.assign(customerById(c.id), data);
        save(); closeModal(); toast('Customer updated'); render();
      }
    });
  }

  function entryForm(customerId, entryId) {
    var entry = entryId ? state.entries.filter(function (e) { return e.id === entryId; })[0] : null;
    var cid = entry ? entry.customerId : (customerId || '');
    var custOptions = state.customers.map(function (c) {
      return '<option value="' + c.id + '"' + (c.id === cid ? ' selected' : '') + '>' + esc(c.name) + '</option>';
    }).join('');
    var e = entry || { date: todayISO(), type: 'gave', amount: '', mode: 'Cash', note: '', due: '' };
    var html = '<form id="entryForm" class="form-grid">' +
      '<div class="field full"><label for="e-customer">Customer *</label><select id="e-customer" required>' +
      '<option value="">Choose a customer</option>' + custOptions + '</select></div>' +
      '<div class="field"><label for="e-date">Date</label><input id="e-date" type="date" value="' + esc(e.date) + '"></div>' +
      '<div class="field"><label for="e-amount">Amount (\u20b9) *</label><input id="e-amount" type="number" step="0.01" min="0.01" required value="' + esc(e.amount) + '"></div>' +
      '<div class="field full"><label>What happened?</label><div class="radio-row">' +
      '<label class="radio' + (e.type !== 'got' ? ' on' : '') + '"><input type="radio" name="e-type" value="gave"' + (e.type !== 'got' ? ' checked' : '') + '> You gave (udhaar)</label>' +
      '<label class="radio' + (e.type === 'got' ? ' on' : '') + '"><input type="radio" name="e-type" value="got"' + (e.type === 'got' ? ' checked' : '') + '> You got (payment)</label>' +
      '</div></div>' +
      '<div class="field"><label for="e-mode">Mode</label><select id="e-mode">' +
      ['Cash', 'UPI', 'Bank transfer', 'Cheque', 'Card', 'Credit note', 'Other'].map(function (m) {
        return '<option' + (m === e.mode ? ' selected' : '') + '>' + m + '</option>';
      }).join('') + '</select></div>' +
      '<div class="field"><label for="e-due">Payment due on (optional)</label><input id="e-due" type="date" value="' + esc(e.due || '') + '">' +
      '<span class="hint">Leave blank to age the entry from its own date.</span></div>' +
      '<div class="field full"><label for="e-note">Note</label><input id="e-note" value="' + esc(e.note) + '" placeholder="2 kg sugar, 1 L oil \u00b7 bill 14"></div>' +
      '<div class="field full modal-actions"><button type="button" class="btn btn-quiet" data-act="close-modal">Cancel</button>' +
      '<button type="submit" class="btn btn-gold">' + (entry ? 'Save entry' : 'Record entry') + '</button></div>' +
      '</form>';
    openModal(entry ? 'Edit entry' : 'New entry', html);
    $$('input[name="e-type"]').forEach(function (r) {
      r.addEventListener('change', function () {
        $$('.radio').forEach(function (l) { l.classList.remove('on'); });
        r.closest('.radio').classList.add('on');
      });
    });
    $('#entryForm').addEventListener('submit', function (ev) {
      ev.preventDefault();
      var cid2 = $('#e-customer').value;
      var amt = Number($('#e-amount').value);
      if (!cid2) { alert('Choose a customer first.'); return; }
      if (!(amt > 0)) { alert('Enter an amount greater than zero.'); return; }
      var typeEl = $('input[name="e-type"]:checked');
      var data = {
        customerId: cid2,
        date: $('#e-date').value || todayISO(),
        type: typeEl ? typeEl.value : 'gave',
        amount: round2(amt),
        mode: $('#e-mode').value,
        due: $('#e-due').value || '',
        note: $('#e-note').value.trim()
      };
      if (entry) {
        Object.assign(entry, data);
      } else {
        data.id = newId('e');
        data.seq = state.entries.length;
        state.entries.push(data);
      }
      save(); closeModal(); toast(entry ? 'Entry updated' : 'Entry recorded');
      if (ui.view === 'ledger') ui.customerId = cid2;
      render();
    });
  }

  /* ---------- print ---------- */
  function printHtml(inner, title) {
    var s = state.shop;
    var head = '<div class="p-head"><div><div class="p-shop">' + esc(s.name || 'Shop') + '</div>' +
      '<div class="p-meta">' + esc([s.address, s.phone, s.gstin ? 'GSTIN ' + s.gstin : ''].filter(Boolean).join(' \u00b7 ')) + '</div>' +
      (s.upi ? '<div class="p-meta">UPI: ' + esc(s.upi) + '</div>' : '') + '</div>' +
      '<div class="p-title">' + esc(title) + '</div></div>';
    var foot = '<div class="p-foot">' + esc(s.footer || '') + ' \u00b7 Printed ' + esc(fmtDate(todayISO())) +
      ' \u00b7 KhataLedger Pro</div>';
    var area = $('#printArea');
    area.innerHTML = head + inner + foot;
    document.body.classList.add('printing');
    window.print();
    setTimeout(function () { document.body.classList.remove('printing'); }, 400);
  }

  function printStatement() {
    var c = customerById(ui.customerId);
    if (!c) return;
    var rows = statementRows(state, c.id);
    var bal = balanceOf(state, c.id);
    var html = '<div class="p-cust"><strong>' + esc(c.name) + '</strong><div class="p-meta">' +
      esc([c.phone, c.address].filter(Boolean).join(' \u00b7 ')) + '</div></div>' +
      '<table class="p-tbl"><thead><tr><th>Date</th><th>Particulars</th><th class="num">You gave</th><th class="num">You got</th><th class="num">Balance</th></tr></thead><tbody>';
    rows.forEach(function (r) {
      html += '<tr><td>' + esc(fmtDate(r.date) || '\u2014') + '</td><td>' + esc(r.type === 'opening' ? 'Opening balance' : (r.note || (r.type === 'got' ? 'Payment received (' + (r.mode || 'cash') + ')' : 'Goods on credit'))) + '</td>' +
        '<td class="num">' + (r.gave ? inr(r.gave) : '') + '</td><td class="num">' + (r.got ? inr(r.got) : '') + '</td>' +
        '<td class="num">' + inr(r.balance) + '</td></tr>';
    });
    html += '</tbody></table>' +
      '<div class="p-total">Balance payable: <strong>' + money(bal) + '</strong></div>' +
      '<div class="p-words">Rupees in words: ' + esc(amountInWords(bal)) + '</div>' +
      '<div class="p-sign"><div>Customer signature</div><div>For ' + esc(state.shop.name || 'the shop') + '</div></div>';
    printHtml(html, 'Khata Statement');
  }

  function printAgeing() {
    var asOf = todayISO();
    var rows = state.customers.map(function (c) {
      return { c: c, a: ageingOf(state, c.id, asOf), bal: balanceOf(state, c.id), days: oldestOverdueDays(state, c.id, asOf) };
    }).filter(function (x) { return x.bal !== 0; }).sort(function (a, b) { return b.bal - a.bal; });
    var t = totals(state, asOf);
    var html = '<div class="p-meta">Ageing report as on ' + esc(fmtDate(asOf)) + '</div>' +
      '<table class="p-tbl"><thead><tr><th>Customer</th><th class="num">Balance</th><th class="num">Not due</th><th class="num">1\u201330</th><th class="num">31\u201360</th><th class="num">61\u201390</th><th class="num">90+</th><th class="num">Oldest</th></tr></thead><tbody>';
    rows.forEach(function (x) {
      html += '<tr><td>' + esc(x.c.name) + '</td><td class="num">' + inr(x.bal) + '</td>' +
        '<td class="num">' + (x.a.current ? inr(x.a.current) : '') + '</td>' +
        '<td class="num">' + (x.a.d30 ? inr(x.a.d30) : '') + '</td>' +
        '<td class="num">' + (x.a.d60 ? inr(x.a.d60) : '') + '</td>' +
        '<td class="num">' + (x.a.d90 ? inr(x.a.d90) : '') + '</td>' +
        '<td class="num">' + (x.a.over90 ? inr(x.a.over90) : '') + '</td>' +
        '<td class="num">' + (x.days ? x.days + ' d' : '') + '</td></tr>';
    });
    html += '<tr class="p-total-row"><td>Total</td><td class="num">' + inr(t.receivable) + '</td>' +
      '<td class="num">' + inr(t.buckets.current) + '</td><td class="num">' + inr(t.buckets.d30) + '</td>' +
      '<td class="num">' + inr(t.buckets.d60) + '</td><td class="num">' + inr(t.buckets.d90) + '</td>' +
      '<td class="num">' + inr(t.buckets.over90) + '</td><td></td></tr>';
    html += '</tbody></table>';
    printHtml(html, 'Ageing Report');
  }

  function printReminders() {
    var asOf = todayISO();
    var rows = state.customers.map(function (c) {
      return { c: c, bal: balanceOf(state, c.id), days: oldestOverdueDays(state, c.id, asOf) };
    }).filter(function (x) { return x.bal > 0; }).sort(function (a, b) { return b.days - a.days; });
    var html = '<div class="p-meta">Reminder list \u00b7 ' + rows.length + ' customers \u00b7 as on ' + esc(fmtDate(asOf)) + '</div>' +
      '<table class="p-tbl"><thead><tr><th>#</th><th>Customer</th><th>Phone</th><th class="num">Balance</th><th class="num">Oldest</th><th>Called</th></tr></thead><tbody>';
    rows.forEach(function (x, i) {
      html += '<tr><td>' + (i + 1) + '</td><td>' + esc(x.c.name) + '</td><td>' + esc(x.c.phone || '') + '</td>' +
        '<td class="num">' + inr(x.bal) + '</td><td class="num">' + (x.days ? x.days + ' d' : '\u2014') + '</td><td class="tick"></td></tr>';
    });
    html += '</tbody></table><p class="p-meta" style="margin-top:14px">Tick each row as you send the message. Total: ' +
      money(rows.reduce(function (s, x) { return s + x.bal; }, 0)) + '</p>';
    printHtml(html, 'Reminder List');
  }

  /* ---------- files ---------- */
  function download(filename, text, mime) {
    var blob = new Blob([text], { type: mime || 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 800);
  }

  function stamp() { return todayISO().replace(/-/g, ''); }

  function backup() {
    var payload = {
      app: 'KhataLedger Pro', version: APP_VERSION, exportedAt: new Date().toISOString(),
      shop: state.shop, customers: state.customers, entries: state.entries
    };
    download('khata-backup-' + stamp() + '.json', JSON.stringify(payload, null, 2), 'application/json');
    toast('Backup downloaded');
  }

  function restore(file) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var d = JSON.parse(reader.result);
        if (!d || !Array.isArray(d.customers) || !Array.isArray(d.entries)) throw new Error('This file is not a KhataLedger backup.');
        if (!confirm('Replace the current book with ' + d.customers.length + ' customers and ' + d.entries.length + ' entries from this backup?')) return;
        state.shop = Object.assign(defaultShop(), d.shop || {});
        state.customers = d.customers;
        state.entries = d.entries;
        save(); render(); toast('Backup restored');
      } catch (err) {
        alert('Could not restore: ' + err.message);
      }
    };
    reader.readAsText(file);
  }

  function demoBook() {
    var base = todayISO();
    function ago(n) {
      var d = parseISO(base); d.setDate(d.getDate() - n); return todayISO(d);
    }
    var shop = {
      name: 'Sharma General Store (EXAMPLE)', owner: 'Rakesh Sharma', phone: '9811044521',
      address: 'Shop 4, Lajpat Nagar II, New Delhi 110024', upi: 'sharmastore@okhdfcbank',
      gstin: '07ABCDE1234F1Z5', footer: 'Goods once sold will not be taken back. Please check your bill.'
    };
    var cs = [
      ['Meena Devi', '9810022331', 'Lajpat Nagar I', 0, 2000],
      ['Imran Khan', '9899011223', 'Amar Colony', 1250, 4000],
      ['Sunita Verma', '9911223344', 'Ring Road', 0, 3000],
      ['Harpreet Singh', '9871234567', 'Defence Colony', 3200, 10000],
      ['Ravi Yadav', '9765432109', 'Kotla Mubarakpur', 0, 1500],
      ['Anjali Gupta', '9822110099', 'Jangpura', 0, 2500]
    ];
    var customers = cs.map(function (r, i) {
      return {
        id: 'c_ex' + i, name: r[0] + ' (EXAMPLE)', phone: r[1], address: r[2],
        opening: r[3], openingDate: ago(75), limit: r[4], note: 'Sample record', created: ago(90)
      };
    });
    var entries = [
      { customerId: 'c_ex0', date: ago(52), type: 'gave', amount: 840, mode: 'Cash', note: 'Monthly grocery, bill 112', due: ago(45) },
      { customerId: 'c_ex0', date: ago(20), type: 'got', amount: 400, mode: 'UPI', note: 'Part payment' },
      { customerId: 'c_ex1', date: ago(64), type: 'gave', amount: 2100, mode: 'Cash', note: 'Rice 10 kg, oil 5 L', due: ago(58) },
      { customerId: 'c_ex1', date: ago(9), type: 'got', amount: 500, mode: 'Cash', note: 'Part payment' },
      { customerId: 'c_ex2', date: ago(38), type: 'gave', amount: 1560, mode: 'UPI', note: 'Festival stock', due: ago(30) },
      { customerId: 'c_ex3', date: ago(110), type: 'gave', amount: 4800, mode: 'Cash', note: 'Bulk order, shop account', due: ago(100) },
      { customerId: 'c_ex3', date: ago(60), type: 'got', amount: 1600, mode: 'Cheque', note: 'Cheque 441122' },
      { customerId: 'c_ex4', date: ago(12), type: 'gave', amount: 620, mode: 'Cash', note: 'Daily items', due: ago(-8) },
      { customerId: 'c_ex5', date: ago(30), type: 'gave', amount: 980, mode: 'UPI', note: 'Snacks and cold drinks', due: ago(20) },
      { customerId: 'c_ex5', date: ago(5), type: 'got', amount: 980, mode: 'UPI', note: 'Settled in full' }
    ].map(function (e, i) { e.id = 'e_ex' + i; e.seq = i; return e; });
    state.shop = shop; state.customers = customers; state.entries = entries;
    save(); toast('Sample book loaded \u2014 replace it with your own data'); go('dashboard');
  }

  /* ---------- events ---------- */
  function remind(id) {
    var c = customerById(id);
    if (!c) return;
    var bal = balanceOf(state, c.id);
    var text = reminderText(state.shop, c, bal, oldestOverdueDays(state, c.id, todayISO()), todayISO());
    if (!c.phone) {
      copyText(text);
      toast('No phone saved \u2014 message copied to clipboard');
      return;
    }
    window.open(waLink(c.phone, text), '_blank', 'noopener');
  }

  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { toast('Copied'); }, function () { fallbackCopy(text); });
    } else fallbackCopy(text);
  }

  function fallbackCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.left = '-9999px';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('Copied'); } catch (e) { alert('Copy failed. Select the text and copy manually.'); }
    ta.remove();
  }

  function handleAction(act, el) {
    if (act === 'new-customer') customerForm(null);
    else if (act === 'new-entry') entryForm(ui.customerId || '');
    else if (act === 'entry-for') entryForm(ui.customerId);
    else if (act === 'edit-customer') customerForm(customerById(ui.customerId));
    else if (act === 'close-modal') closeModal();
    else if (act === 'print-statement') printStatement();
    else if (act === 'print-ageing') printAgeing();
    else if (act === 'print-reminders') printReminders();
    else if (act === 'remind') remind(ui.customerId);
    else if (act === 'save-shop') {
      state.shop = {
        name: $('#s-name').value.trim() || 'Your Shop', owner: $('#s-owner').value.trim(),
        phone: $('#s-phone').value.trim(), upi: $('#s-upi').value.trim(),
        gstin: $('#s-gstin').value.trim(), address: $('#s-address').value.trim(),
        footer: $('#s-footer').value.trim()
      };
      save(); toast('Shop profile saved'); render();
    }
    else if (act === 'backup') backup();
    else if (act === 'demo') {
      if (state.customers.length && !confirm('This replaces the current book with the sample book. Continue?')) return;
      demoBook();
    }
    else if (act === 'wipe') {
      if (!confirm('Erase every customer and entry from this browser? Download a backup first if you need one.')) return;
      if (!confirm('Really erase? This cannot be undone.')) return;
      state.customers = []; state.entries = []; save(); toast('All data erased'); go('dashboard');
    }
    else if (act === 'export-customers') {
      download('khata-customers-' + stamp() + '.csv', customersCsv(state, todayISO()), 'text/csv;charset=utf-8');
    }
    else if (act === 'export-entries') {
      download('khata-entries-' + stamp() + '.csv', entriesCsv(state), 'text/csv;charset=utf-8');
    }
    else if (act === 'copy-all') {
      var asOf = todayISO();
      var lines = state.customers.map(function (c) {
        var b = balanceOf(state, c.id);
        return b > 0 ? c.name + '\t' + money(b) + '\t' + (c.phone || '') + '\t' + oldestOverdueDays(state, c.id, asOf) + ' days' : '';
      }).filter(Boolean);
      copyText('Pending khata \u2014 ' + fmtDate(asOf) + '\n' + lines.join('\n'));
    }
    else if (act === 'clear-dates') { ui.from = ''; ui.to = ''; render(); }
  }

  function bind() {
    document.addEventListener('click', function (ev) {
      var t = ev.target.closest('[data-act],[data-view],[data-ledger],[data-remind],[data-edit-entry],[data-del-entry],[data-copy]');
      if (!t) return;
      if (t.hasAttribute('data-act')) { handleAction(t.getAttribute('data-act'), t); return; }
      if (t.hasAttribute('data-view')) { go(t.getAttribute('data-view')); return; }
      if (t.hasAttribute('data-ledger')) { go('ledger', t.getAttribute('data-ledger')); return; }
      if (t.hasAttribute('data-remind')) { remind(t.getAttribute('data-remind')); return; }
      if (t.hasAttribute('data-copy')) {
        var c = customerById(t.getAttribute('data-copy'));
        if (c) copyText(reminderText(state.shop, c, balanceOf(state, c.id), oldestOverdueDays(state, c.id, todayISO()), todayISO()));
        return;
      }
      if (t.hasAttribute('data-edit-entry')) { entryForm(null, t.getAttribute('data-edit-entry')); return; }
      if (t.hasAttribute('data-del-entry')) {
        var id = t.getAttribute('data-del-entry');
        if (!confirm('Delete this entry? The balance will change.')) return;
        state.entries = state.entries.filter(function (e) { return e.id !== id; });
        save(); toast('Entry deleted'); render();
      }
    });

    document.addEventListener('input', function (ev) {
      if (ev.target.id === 'custSearch') {
        ui.search = ev.target.value;
        var pos = ev.target.selectionStart;
        render();
        var again = $('#custSearch');
        if (again) { again.focus(); try { again.setSelectionRange(pos, pos); } catch (e) { } }
      }
      if (ev.target.id === 'fromDate') { ui.from = ev.target.value; render(); }
      if (ev.target.id === 'toDate') { ui.to = ev.target.value; render(); }
    });

    document.addEventListener('change', function (ev) {
      if (ev.target.id === 'custSort') { ui.sort = ev.target.value; render(); }
      if (ev.target.id === 'restoreFile' && ev.target.files && ev.target.files[0]) restore(ev.target.files[0]);
    });

    $('#modal').addEventListener('click', function (ev) {
      if (ev.target.id === 'modal') closeModal();
    });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape') closeModal();
      if (ev.key === 'n' && (ev.ctrlKey || ev.metaKey)) { ev.preventDefault(); entryForm(ui.customerId || ''); }
    });

    $$('.nav-item').forEach(function (b) {
      b.addEventListener('click', function () { go(b.getAttribute('data-view')); });
    });
    var burger = $('#burger');
    if (burger) burger.addEventListener('click', function () { document.body.classList.toggle('nav-open'); });
  }

  function boot() {
    if (!load()) state.shop = defaultShop();
    bind();
    go('dashboard');
    if (!state.customers.length) {
      /* first run: nothing to say beyond the empty state */
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

})(typeof window !== 'undefined' ? window : this);
